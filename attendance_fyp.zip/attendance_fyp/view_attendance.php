<?php
session_start();
include "connection.php";

if(!isset($_SESSION['name']) || $_SESSION['role'] != 'lecturer'){
    header("Location: login.php");
    exit();
}

$lecturer = $_SESSION['name'];

$search = $_GET['search'] ?? '';
$date   = $_GET['date'] ?? '';
$time   = $_GET['time'] ?? '';
$class  = $_GET['class'] ?? '';

$sql = "
SELECT 
    attendance.*,
    users.name,
    subjects.subject_name
FROM attendance

LEFT JOIN students
    ON attendance.student_id = students.student_id

LEFT JOIN users
    ON students.id = users.id

LEFT JOIN subjects
    ON attendance.subject_id = subjects.subject_id

WHERE subjects.lecturer = '$lecturer'
";

/* Filters */
if($search != ''){
    $sql .= "
    AND (
        attendance.student_id LIKE '%$search%' OR
        users.name LIKE '%$search%'
    )";
}

if($date != ''){
    $sql .= " AND attendance.attend_date = '$date'";
}

if($time != ''){
    $sql .= " AND attendance.attend_time LIKE '$time%'";
}

if($class != ''){
    $sql .= " AND attendance.subject_id LIKE '%$class%'";
}

$sql .= "
ORDER BY attendance.attend_date DESC,
attendance.attend_time DESC
";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>View Attendance</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    display:flex;
    background:#f5f8fc;
}

/* SIDEBAR */
.sidebar{
    width:260px;
    min-height:100vh;
    background:white;
    padding:25px;
    position:fixed;
    left:0;
    top:0;
}

.sidebar a{
    display:flex;
    align-items:center;
    gap:12px;
    padding:14px 16px;
    margin-bottom:10px;
    border-radius:12px;
    text-decoration:none;
    color:black;
    transition:0.2s;
    font-size:15px;
}

.sidebar a.active{
    background:#2563eb;
    color:white;
}

/* MAIN */

.main{
    margin-left:260px;
    width:calc(100% - 260px);
    padding:35px;
}

/* HEADER */

.top{
    background:white;
    border-radius:25px;
    padding:28px 40px;
    display:flex;
    justify-content:space-between;
    align-items:flex-start;
    box-shadow:0 8px 25px rgba(0,0,0,.05);
    margin-bottom:30px;
}

.top-content{
    flex:1;
}

.top h1{
    color:#0b1652;
    font-size:28px;
    margin-bottom:8px;
}

.top p{
    color:#475569;
    margin-bottom:0;
}

.back-btn{
    border:2px solid #d9e2f2;
    padding:12px 22px;
    border-radius:16px;
    text-decoration:none;
    color:#2563eb;
    font-weight:600;
    font-weight:bold;
}

/* SEARCH CARD */

.box{
    background:white;
    border-radius:25px;
    padding:28px 40px;
    box-shadow:0 8px 25px rgba(0,0,0,.05);
}

.box h2{
    color:#0d1b57;
    margin-bottom:10px;
}

.line{
    width:45px;
    height:5px;
    background:#2563eb;
    border-radius:20px;
    margin:15px 0 35px;
}

/* FORM */

.search-row{
    display:flex;
    gap:20px;
    align-items:center;
    flex-wrap:wrap;
}

.search-row input{
     width:260px;
    padding:13px 15px;
    border:1px solid #dbe2ea;
    border-radius:16px;
    background:#fff;
    font-size:14px;
    outline:none;
}

.filter-btn{
    background:#2962ff;
    color:white;
    border:none;
    padding:13px 22px;
    border-radius:16px;
    font-size:14px;
    font-weight:bold;
    cursor:pointer;
}

.reset-btn{
    background:#eef2f7;
    color:#111827;
    padding:13px 20px;
    border-radius:16px;
    text-decoration:none;
    font-size:14px;
    font-weight:bold;
}
/* RESULT TABLE */

table{
    width:100%;
    border-collapse:collapse;
    margin-top:30px;
    overflow:hidden;
    border-radius:18px;
}

th{
    background:#2563eb;
    color:white;
    padding:15px;
}

td{
    padding:15px;
    text-align:center;
    border-bottom:1px solid #e2e8f0;
}

.present{
    color:green;
    font-weight:bold;
}

.absent{
    color:red;
    font-weight:bold;
}
</style>
</head>

<body>

<!-- Sidebar -->
<div class="sidebar">
    <h2>Lecturer Panel</h2>
    <a href="attendance_lecturer.php">Overview</a>
    <a href="subject_lecturer.php">Subject</a>
    <a href="attendance_lecturer.php" class="active">Attendance</a>
    <a href="timetable_lecturer.php">Timetable</a>
</div>

<!-- Main -->
<div class="main">
    <div class="top">
        <div class="top-content">
            <h1>Attendance Records</h1>
            <p>View and search attendance history.</p>
        </div>
        <a href="attendance_lecturer.php" class="back-btn">
            ← Back
        </a>
    </div>

    <div class="box">

        <!-- Filter Form -->
        <form method="GET">
            <div class="search-row">
                <input type="date" name="date" value="<?php echo $date; ?>">
                <input type="time" name="time" value="<?php echo $time; ?>">
                <input type="text" name="class" placeholder="Class" value="<?php echo $class; ?>">
                <input type="text" name="search" placeholder="Search Student" value="<?php echo $search; ?>">
                <button type="submit" class="filter-btn">Filter</button>
                <a href="view_attendance.php" class="reset-btn">Reset</a>
            </div>
        </form>

        <!-- Table -->
        <table>
            <tr>
                <th>Student ID</th>
                <th>Name</th>
                <th>Time</th>
                <th>Status</th>
                <th>Class</th>
                <th>Date</th>
            </tr>

            <?php if($result->num_rows > 0){ ?>

                <?php while($row = $result->fetch_assoc()){ ?>

                <tr>
                    <td><?php echo $row['student_id']; ?></td>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['attend_time']; ?></td>
                    <td>
                        <span class="<?php echo strtolower($row['status']); ?>">
                            <?php echo $row['status']; ?>
                        </span>
                    </td>

                    <td>
                        <?php echo $row['subject_id']; ?>
                        <br>
                        <small><?php echo $row['subject_name']; ?></small>
                    </td>

                    <td><?php echo $row['attend_date']; ?></td>
                </tr>

                <?php } ?>

            <?php } else { ?>

                <tr>
                    <td colspan="6">No attendance record found.</td>
                </tr>

            <?php } ?>

        </table>

    </div>

</div>

</body>
</html>