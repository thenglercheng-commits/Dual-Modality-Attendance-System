<?php
include "connection.php";
date_default_timezone_set("Asia/Kuala_Lumpur");

$image      = $_POST['image']      ?? '';
$subject_id = $_POST['subject_id'] ?? '';
$date       = $_POST['date']       ?? '';
$time       = $_POST['time']       ?? '';

if ($image == '') {
    exit("No image.");
}

/* =========================
   TIME VALIDATION CHECK
========================= */

if ($subject_id != '') {

    $res = $conn->query("
    SELECT start_time, end_time
    FROM timetable
    WHERE subject_id='$subject_id'
    AND class_date = CURDATE()
    LIMIT 1
    ");

    if ($res && $res->num_rows > 0) {

        $row   = $res->fetch_assoc();
        $today = date("Y-m-d");
        $now   = strtotime(date("Y-m-d H:i:s"));
        $start = strtotime($today . " " . $row['start_time']);
        $end   = strtotime($today . " " . $row['end_time']);

        if ($now < $start || $now > $end) {
            exit("QR Code expired. Attendance only allowed during class time.");
        }
    }
}

/* =========================
   CALL FLASK FACE API
   POST image + subject_id + date
   Returns JSON: { status, message, student_id }
========================= */

$api_url = "http://127.0.0.1:5001/verify";

$ch = curl_init($api_url);
curl_setopt($ch, CURLOPT_POST,           true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT,        30);
curl_setopt($ch, CURLOPT_POSTFIELDS, [
    "image"      => $image,
    "subject_id" => $subject_id,
    "date"       => $date,
]);

$response = curl_exec($ch);
$curl_err  = curl_error($ch);
curl_close($ch);

if ($curl_err || !$response) {
    exit("Face API unavailable. Please try again.");
}

$data   = json_decode($response, true);
$status = strtoupper($data['status'] ?? '');
$face_accuracy = $data['score'] ?? 0;
$face_accuracy = round($face_accuracy * 100, 2);

/* =========================
   HANDLE API RESULT
========================= */

switch ($status) {

    case 'UNKNOWN':
        exit("Face not recognized.");

    case 'NOT_LIVE':
        exit("Liveness check failed.");

    case 'ALREADY':
        exit("Attendance already taken.");

    case 'NOT_ENROLLED':
        exit("
        <div style='color:red;font-weight:bold'>
        You are not enrolled in this subject.
        </div>
        ");

    case 'ERROR':
        exit($data['message'] ?? "An error occurred. Please try again.");

    case 'SUCCESS':
        // API already saved attendance + image path to DB
        echo "Attendance Success: " . 
        htmlspecialchars($data['student_id']).
        "<br>Face Accuracy: " .round($face_accuracy, 2) . "%";
        exit();

    default:
        exit("Unexpected response. Please try again.");
}
?>