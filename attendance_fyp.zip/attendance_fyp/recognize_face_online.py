import os
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"

import cv2
import json
import sys
import math
import time
import random
import numpy as np
import mediapipe as mp
import mysql.connector
from datetime import datetime
from mtcnn import MTCNN
from keras_facenet import FaceNet
import warnings
warnings.filterwarnings("ignore")

# ==========================================
# SETTINGS
# ==========================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SAVE_FILE = os.path.join(BASE_DIR, "face_database.json")

THRESHOLD = 0.50
CAM_W = 1280
CAM_H = 720
PROCESS_EVERY = 2
AUTO_CLOSE_SEC = 2

# ==========================================
# MODELS
# ==========================================
print("Loading models...")
detector = MTCNN()
embedder = FaceNet()
print("Models loaded.")

# ==========================================
# MEDIAPIPE
# ==========================================
mp_face = mp.solutions.face_mesh
face_mesh = mp_face.FaceMesh(
    max_num_faces=1,
    refine_landmarks=True,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

LEFT_EYE = 33
RIGHT_EYE = 263
NOSE = 1

# ==========================================
# LOAD DATABASE
# ==========================================
def load_database():
    if not os.path.exists(SAVE_FILE):
        return []

    with open(SAVE_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

# ==========================================
# COSINE
# ==========================================
def cosine(a, b):
    a = np.array(a, dtype=np.float32)
    b = np.array(b, dtype=np.float32)

    na = np.linalg.norm(a)
    nb = np.linalg.norm(b)

    if na == 0 or nb == 0:
        return -1

    return float(np.dot(a, b) / (na * nb))

# ==========================================
# MATCH
# ==========================================
def match_face(emb, db):
    best_score = -1
    best_person = None

    for person in db:
        ref = np.array(person["average_embedding"], dtype=np.float32)
        score = cosine(emb, ref)

        if score > best_score:
            best_score = score
            best_person = person

    return best_person, best_score

# ==========================================
# DB SAVE
# NOTE: Online mode - Python handles the full
# attendance INSERT (unlike physical mode where
# PHP does the INSERT after Python returns the ID).
# Enrollment check MUST be here before INSERT.
# ==========================================
def save_attendance(student_id, subject_id, date, mode, accuracy):
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="attendance_fyp"
        )
        cur = conn.cursor()

        # =========================
        # CHECK SUBJECT ENROLLMENT
        # =========================

        cur.execute("""
            SELECT id
            FROM student_subject
            WHERE student_id=%s
            AND subject_id=%s
        """, (student_id, subject_id))

        if not cur.fetchone():

            cur.close()
            conn.close()

            return "NOT_ENROLLED"

        # =========================
        # CHECK DUPLICATE ATTENDANCE
        # =========================

        cur.execute("""
            SELECT id FROM attendance
            WHERE student_id=%s
            AND subject_id=%s
            AND attend_date=%s
        """, (student_id, subject_id, date))

        if cur.fetchone():
            cur.close()
            conn.close()
            return "ALREADY"

        # =========================
        # INSERT ATTENDANCE
        # =========================

        now = datetime.now().strftime("%H:%M:%S")

        cur.execute("""
            INSERT INTO attendance
            (student_id, subject_id, attend_date, attend_time, status, mode, face_accuracy)
            VALUES (%s,%s,%s,%s,%s,%s)
        """, (
            student_id,
            subject_id,
            date,
            now,
            "Present",
            mode
        ))

        conn.commit()
        cur.close()
        conn.close()
        return "SUCCESS"

    except Exception as e:
        return "DB_ERROR:" + str(e)

# ==========================================
# EMBEDDING FROM IMAGE
# ==========================================
def get_embedding_from_frame(frame):
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    try:
        faces = detector.detect_faces(rgb)
    except:
        return None, None

    if len(faces) == 0:
        return None, None

    face = max(faces, key=lambda f: f["confidence"])

    if face.get("confidence", 0) < 0.90:
        return None, None

    x, y, w, h = face["box"]
    x = max(0, x)
    y = max(0, y)

    crop = frame[y:y+h, x:x+w]
    if crop.size == 0:
        return None, None

    try:
        face_rgb = cv2.cvtColor(crop, cv2.COLOR_BGR2RGB)
        face_rgb = cv2.resize(face_rgb, (160, 160))
        face_rgb = np.expand_dims(face_rgb, axis=0)

        emb = embedder.embeddings(face_rgb)[0]
        emb = emb / np.linalg.norm(emb)
        return emb, (x, y, w, h)

    except:
        return None, None

# ==========================================
# ADVANCED LIVENESS (anti-spoofing detection)
# ==========================================

def check_liveness(frame):
    # For single image mode, use static analysis
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    result = face_mesh.process(rgb)

    if not result.multi_face_landmarks:
        return False

    h, w, _ = frame.shape
    lm = result.multi_face_landmarks[0].landmark

    # Key facial landmarks
    le = (int(lm[LEFT_EYE].x*w), int(lm[LEFT_EYE].y*h))
    re = (int(lm[RIGHT_EYE].x*w), int(lm[RIGHT_EYE].y*h))
    no = (int(lm[NOSE].x*w), int(lm[NOSE].y*h))

    checks_passed = 0
    total_checks = 0

    # Check 1: Face symmetry and proportions
    eye_distance = math.hypot(re[0]-le[0], re[1]-le[1])
    nose_to_left = math.hypot(no[0]-le[0], no[1]-le[1])
    nose_to_right = math.hypot(no[0]-re[0], no[1]-re[1])
    symmetry_ratio = nose_to_left / (nose_to_right + 1e-6)

    total_checks += 1
    if 0.7 <= symmetry_ratio <= 1.4:  # Natural face symmetry
        checks_passed += 1

    # Check 2: Texture analysis using Laplacian variance
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Extract face region
    face_x = max(0, min(le[0], re[0]) - int(eye_distance * 0.2))
    face_y = max(0, min(le[1], re[1]) - int(eye_distance * 0.3))
    face_w = min(w - face_x, int(eye_distance * 2.5))
    face_h = min(h - face_y, int(eye_distance * 3))

    if face_w > 20 and face_h > 20:
        face_region = gray[face_y:face_y+face_h, face_x:face_x+face_w]
        laplacian_var = cv2.Laplacian(face_region, cv2.CV_64F).var()

        total_checks += 1
        # Real faces have more texture variance than photos
        if 30 <= laplacian_var <= 800:
            checks_passed += 1

    # Check 3: Edge density analysis
    edges = cv2.Canny(gray, 50, 150)
    edge_density = np.sum(edges > 0) / (w * h)

    total_checks += 1
    # Photos often have unnatural edge patterns
    if 0.01 <= edge_density <= 0.12:
        checks_passed += 1

    # Check 4: Color distribution and saturation
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    saturation = np.mean(hsv[:, :, 1])
    brightness = np.mean(hsv[:, :, 2])

    total_checks += 1
    # Real faces have natural color ranges
    if 20 <= saturation <= 220 and 40 <= brightness <= 220:
        checks_passed += 1

    # Check 5: Eye brightness analysis (detect eye reflections)
    left_eye_region = gray[max(0, le[1]-8):le[1]+8, max(0, le[0]-8):le[0]+8]
    right_eye_region = gray[max(0, re[1]-8):re[1]+8, max(0, re[0]-8):re[0]+8]

    if left_eye_region.size > 0 and right_eye_region.size > 0:
        left_max = np.max(left_eye_region)
        right_max = np.max(right_eye_region)
        face_avg = np.mean(gray[max(0, face_y):face_y+face_h, max(0, face_x):face_x+face_w])

        total_checks += 1
        # Real eyes should have bright spots (reflections)
        if max(left_max, right_max) > face_avg + 25:
            checks_passed += 1

    # Check 6: Gradient analysis for skin texture
    if face_w > 20 and face_h > 20:
        sobel_x = cv2.Sobel(face_region, cv2.CV_64F, 1, 0, ksize=3)
        sobel_y = cv2.Sobel(face_region, cv2.CV_64F, 0, 1, ksize=3)
        gradient_magnitude = np.sqrt(sobel_x**2 + sobel_y**2)
        gradient_std = np.std(gradient_magnitude)

        total_checks += 1
        # Real skin has natural gradient variations
        if 8 <= gradient_std <= 60:
            checks_passed += 1

    # Check 7: Frequency domain analysis (detect compression artifacts)
    if face_w > 20 and face_h > 20:
        try:
            f_transform = np.fft.fft2(face_region)
            magnitude_spectrum = np.abs(f_transform)

            # Analyze frequency distribution
            high_freq = magnitude_spectrum[magnitude_spectrum > np.percentile(magnitude_spectrum, 85)]
            total_freq = np.sum(magnitude_spectrum)
            high_freq_ratio = np.sum(high_freq) / (total_freq + 1e-6)

            total_checks += 1
            # Photos have different frequency characteristics
            if 0.03 <= high_freq_ratio <= 0.30:
                checks_passed += 1
        except:
            pass

    # Check 8: Reflection detection (screens have uniform reflections)
    v_channel = hsv[:, :, 2]
    _, binary = cv2.threshold(v_channel, np.percentile(v_channel, 90), 255, cv2.THRESH_BINARY)
    contours, _ = cv2.findContours(binary.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    large_reflections = sum(1 for contour in contours if cv2.contourArea(contour) > (w * h) * 0.015)

    total_checks += 1
    # Too many large reflections indicate screen/photo
    if large_reflections <= 3:
        checks_passed += 1

    # Require at least 70% of checks to pass
    return checks_passed >= (total_checks * 0.7)

# ==========================================
# IMAGE MODE (for mobile QR - Online)
# Usage:
# python recognize_face_online.py image img.jpg subject date
# ==========================================
def run_image_mode(img_path, subject_id, date):
    db = load_database()

    frame = cv2.imread(img_path)
    if frame is None:
        print("UNKNOWN")
        return

    emb, box = get_embedding_from_frame(frame)
    if emb is None:
        print("UNKNOWN")
        return

    if not check_liveness(frame):
        print("NOT_LIVE")
        return

    person, score = match_face(emb, db)
    accuracy = round(score * 100, 2)

    if person and score >= THRESHOLD:
        sid = person["student_id"]

        # save_attendance handles enrollment check,
        # duplicate check, and INSERT in one place
        result = save_attendance(sid, subject_id, date, "Online")

        if result == "SUCCESS":
            # PHP (verify_face.php) receives the student ID
            # and saves the image path to DB
            print(f"{sid}|{accuracy}")
        elif result == "ALREADY":
            print("ALREADY")
        elif result == "NOT_ENROLLED":
            print("NOT_ENROLLED")
        else:
            print("ERROR")
    else:
        print("UNKNOWN")


# ==========================================
# WEBCAM MODE
# Usage:
# python recognize_face_online.py subject date
# ==========================================
def run_webcam_mode(subject_id, date):
    db = load_database()

    cap = cv2.VideoCapture(0)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, CAM_W)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, CAM_H)

    if not cap.isOpened():
        print("Cannot open camera.")
        return

    marked = False
    success_time = None

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        frame = cv2.flip(frame, 1)

        emb, box = get_embedding_from_frame(frame)

        label = "Show Face"
        color = (0,0,255)

        if emb is not None:
            person, score = match_face(emb, db)

            if person and score >= THRESHOLD:
                sid = person["student_id"]
                name = person["student_name"]

                if check_liveness(frame):
                    label = f"{name} {score:.2f}"
                    color = (0,255,0)

                    if not marked:
                        result = save_attendance(sid, subject_id, date, "Online")
                        marked = True
                        success_time = time.time()

                else:
                    label = f"{name} Verify Live"
                    color = (0,165,255)
            else:
                label = f"Unknown {score:.2f}"

        if box:
            x,y,w,h = box
            cv2.rectangle(frame,(x,y),(x+w,y+h),color,3)
            cv2.putText(frame,label,(x,y-10),
                        cv2.FONT_HERSHEY_SIMPLEX,0.75,color,2)

        cv2.imshow("Attendance Camera", frame)

        if success_time and time.time() - success_time > AUTO_CLOSE_SEC:
            break

        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

    cap.release()
    cv2.destroyAllWindows()

# ==========================================
# MAIN
# ==========================================
def main():
    args = sys.argv

    if len(args) >= 5 and args[1].lower() == "image":
        img_path = args[2]
        subject_id = args[3]
        date = args[4]
        run_image_mode(img_path, subject_id, date)

    elif len(args) >= 3:
        subject_id = args[1]
        date = args[2]
        run_webcam_mode(subject_id, date)

    else:
        print("Usage:")
        print("Webcam : python recognize_face_online.py SUBJECT DATE")
        print("Image  : python recognize_face_online.py image IMG SUBJECT DATE")

if __name__ == "__main__":
    main()