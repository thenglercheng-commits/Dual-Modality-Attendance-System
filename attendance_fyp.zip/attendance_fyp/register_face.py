import cv2
import json
import os
import time
import sys
import numpy as np
from mtcnn import MTCNN
from keras_facenet import FaceNet

# =========================
# CONFIG (FAST VERSION)
# =========================
base_dir = os.path.dirname(os.path.abspath(__file__))
save_file = os.path.join(base_dir, "face_database.json")

max_embeddings = 6              
capture_interval = 0.3          # faster capture
min_face_size = 60              # allow smaller face
process_every_n_frames = 2      # faster

# =========================
# INIT MODELS
# =========================
print("Loading models...")
detector = MTCNN()
embedder = FaceNet()
print("Models loaded.")

# =========================
# FUNCTIONS
# =========================
def load_database():
    if not os.path.exists(save_file):
        return []
    with open(save_file, "r", encoding="utf-8") as f:
        return json.load(f)

def save_database(data):
    with open(save_file, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

def get_embedding(frame):
    frame_small = cv2.resize(frame, (320, 240))
    rgb = cv2.cvtColor(frame_small, cv2.COLOR_BGR2RGB)

    faces = detector.detect_faces(rgb)

    if len(faces) != 1:
        return None

    x, y, w, h = faces[0]["box"]

    if w < min_face_size or h < min_face_size:
        return None

    x = max(0, x)
    y = max(0, y)

    face = rgb[y:y+h, x:x+w]

    if face.size == 0:
        return None

    face = cv2.resize(face, (160,160))
    face = np.expand_dims(face, axis=0)

    embedding = embedder.embeddings(face)[0]

    norm = np.linalg.norm(embedding)
    if norm == 0:
        return None

    return embedding / norm

# =========================
# MAIN
# =========================
def main():

    if len(sys.argv) >= 3:
        student_id = sys.argv[1]
        student_name = sys.argv[2]
    else:
        print("Missing arguments")
        return

    db = load_database()

    for p in db:
        if p["student_id"] == student_id:
            print("Student already exists")
            return

    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)

    if not cap.isOpened():
        print("Cannot open camera")
        return

    embeddings = []
    last_capture = 0
    frame_count = 0

    # 🔥 timeout protection (IMPORTANT)
    start_time = time.time()

    print("Look at camera...")

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        frame_count += 1
        now = time.time()

        # 🔥 STOP if too slow (30 sec)
        if now - start_time > 30:
            print("Timeout reached")
            break

        if frame_count % process_every_n_frames == 0:
            emb = get_embedding(frame)
        else:
            emb = None

        if emb is not None and (now - last_capture) > capture_interval:
            embeddings.append(emb.tolist())
            last_capture = now
            print(f"Captured {len(embeddings)}/{max_embeddings}")

        cv2.putText(frame, f"{len(embeddings)}/{max_embeddings}", (20,40),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,0), 2)

        cv2.imshow("Register Face", frame)

        if len(embeddings) >= max_embeddings:
            break

        if cv2.waitKey(1) & 0xFF == 27:
            break

    cap.release()
    cv2.destroyAllWindows()

    if len(embeddings) == 0:
        print("Failed")
        return

    avg = np.mean(np.array(embeddings), axis=0)
    avg = avg / np.linalg.norm(avg)

    db.append({
        "student_id": student_id,
        "student_name": student_name,
        "embeddings": embeddings,
        "average_embedding": avg.tolist()
    })

    save_database(db)

    print("Registration SUCCESS")

# =========================
if __name__ == "__main__":
    main()