<?php
session_start();
include "connection.php";

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}

$student_id = $_SESSION['student_id'];

/* =========================
   ATTENDANCE SUMMARY
========================= */

// $total_query = mysqli_query($conn,
// "SELECT COUNT(*) as total
//  FROM attendance
//  WHERE student_id='$student_id'");

// $total_row = mysqli_fetch_assoc($total_query);
// $total = $total_row['total'];

// $present_query = mysqli_query($conn,
// "SELECT COUNT(*) as total
//  FROM attendance
//  WHERE student_id='$student_id'
//  AND status='Present'");

// $present_row = mysqli_fetch_assoc($present_query);
// $present = $present_row['total'];

// $late_query = mysqli_query($conn,
// "SELECT COUNT(*) as total
//  FROM attendance
//  WHERE student_id='$student_id'
//  AND status='Late'");

// $late_row = mysqli_fetch_assoc($late_query);
// $late = $late_row['total'];

// $absent = $total - ($present + $late);

// $attendance_rate = 0;

// if($total > 0){
//     $attendance_rate = round(($present / $total) * 100);
// }

/* =========================
   TODAY'S ATTENDANCE SUMMARY
   Based on today's timetable
   sessions for enrolled subjects
========================= */

// Total classes scheduled TODAY for this student
$total_query = mysqli_query($conn,
"SELECT COUNT(*) as total
 FROM timetable t
 JOIN student_subject ss
   ON t.subject_id = ss.subject_id
 WHERE ss.student_id = '$student_id'
 AND t.class_date = CURDATE()");

$total_row    = mysqli_fetch_assoc($total_query);
$total        = $total_row['total'];

// Classes student ATTENDED today
$present_query = mysqli_query($conn,
"SELECT COUNT(*) as total
 FROM attendance
 WHERE student_id = '$student_id'
 AND status = 'Present'
 AND attend_date = CURDATE()");

$present_row  = mysqli_fetch_assoc($present_query);
$present      = $present_row['total'];

// Late today
$late_query = mysqli_query($conn,
"SELECT COUNT(*) as total
 FROM attendance
 WHERE student_id = '$student_id'
 AND status = 'Late'
 AND attend_date = CURDATE()");

$late_row     = mysqli_fetch_assoc($late_query);
$late         = $late_row['total'];

// Absent = total scheduled today - attended - late
$absent       = $total - ($present + $late);
if($absent < 0) $absent = 0;

// Today's attendance rate
$attendance_rate = 0;
if($total > 0){
    $attendance_rate = round((($present + $late) / $total) * 100, 2);
}

/* =========================
   ATTENDANCE RECORDS
========================= */

$attendance_query = mysqli_query($conn,
"SELECT *
 FROM attendance
 WHERE student_id='$student_id'
 ORDER BY attend_date DESC, attend_time DESC");
?>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>My Attendance</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'Poppins',sans-serif;
    background:#f4f8ff;
    display:flex;
}

/* =========================
   SIDEBAR
========================= */

.sidebar{
    width:260px;
    min-height:100vh;
    background:white;
    padding:25px;
    position:fixed;
    left:0;
    top:0;
    border-right:1px solid #eee;
}

.brand{
    font-size:28px;
    font-weight:700;
    margin-bottom:40px;
    color:#2563eb;
}

.menu a{
    display:flex;
    align-items:center;
    gap:12px;
    padding:15px;
    margin-bottom:12px;
    border-radius:16px;
    text-decoration:none;
    color:#334155;
    font-weight:500;
    transition:.3s;
    font-size:15px;
}

.menu a:hover,
.menu a.active{
    background:#2563eb;
    color:white;
}

/* =========================
   MAIN
========================= */

.main{
    margin-left:260px;
    width:100%;
    padding:30px;
}

/* =========================
   TOP
========================= */

.top{
    background:white;
    padding:30px;
    border-radius:24px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    box-shadow:0 8px 20px rgba(0,0,0,.05);
}

.top h1{
    font-size:28px;
    margin-bottom:10px;
}

.top p{
    color:#64748b;
    font-size:14px;
}

.realtime{
    text-align:right;
    font-size:14px;
}

.realtime span{
    color:green;
    font-weight:600;
}

/* =========================
   CARDS
========================= */

.cards{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:20px;
    margin-top:25px;
}

.card{
    background:white;
    border-radius:22px;
    padding:25px;
    box-shadow:0 8px 20px rgba(0,0,0,.05);
}

.card h3{
    color:#64748b;
    margin-bottom:12px;
    font-size:16px;
}

.card p{
    font-size:24px;
    font-weight:700;
}

.blue{
    color:#2563eb;
}

.green{
    color:#16a34a;
}

.orange{
    color:#f59e0b;
}

.red{
    color:#ef4444;
}

/* =========================
   SECTION
========================= */

.section{
    margin-top:25px;
    background:white;
    padding:25px;
    border-radius:24px;
    box-shadow:0 8px 20px rgba(0,0,0,.05);
}

.section-title{
    margin-bottom:20px;
}

.section-title h2{
    margin-bottom:8px;
    font-size:24px;
}

.section-title p{
    color:#64748b;
    font-size:14px;
}

/* =========================
   FILTER SECTION
========================= */

.filter-section{
    display:flex;
    gap:15px;
    align-items:center;
    margin-bottom:25px;
    flex-wrap:wrap;
}

.filter-input{
    padding:14px 18px;
    border:1px solid #ddd;
    border-radius:14px;
    background:white;
    min-width:180px;
    outline:none;
    font-family:'Poppins',sans-serif;
}

.search{
    padding:14px 18px;
    border:1px solid #ddd;
    border-radius:14px;
    background:white;
    min-width:250px;
    margin-left:auto;
    outline:none;
    font-family:'Poppins',sans-serif;
}

.filter-btn{
    background:#2563eb;
    color:white;
    border:none;
    padding:14px 22px;
    border-radius:14px;
    cursor:pointer;
    font-weight:600;
}

.reset-btn{
    background:#f1f5f9;
    border:none;
    padding:14px 22px;
    border-radius:14px;
    cursor:pointer;
    font-weight:600;
}

/* =========================
   TABLE
========================= */

table{
    width:100%;
    border-collapse:collapse;
    overflow:hidden;
    border-radius:18px;
    font-size:14px;
}

thead{
    background:#2563eb;
    color:white;
}

th{
    padding:18px;
    text-align:left;
}

td{
    padding:18px;
    border-bottom:1px solid #eee;
}

/* tr:hover{
    background:#f8fbff;
} */

.badge{
    padding:7px 14px;
    border-radius:999px;
    font-size:13px;
    font-weight:600;
}

.present{
    background:#dcfce7;
    color:#15803d;
}

.late{
    background:#fef3c7;
    color:#b45309;
}

.absent{
    background:#fee2e2;
    color:#b91c1c;
}

.right-top{
    display:flex;
    align-items:center;
    gap:15px;
}

.logout-btn{
    background:#2563eb;
    color:white;
    padding:12px 20px;
    border-radius:12px;
    text-decoration:none;
    font-weight:600;
}

.profile{
    width:50px;
    height:50px;
    border-radius:50%;
    background:#2563eb;
    color:white;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:24px;
    text-decoration:none;
}
/* =========================
   RESPONSIVE
========================= */

@media(max-width:900px){

    .sidebar{
        width:180px;
        padding:20px 15px;
    }

    .main{
        margin-left:180px;
        width:calc(100% - 180px);
        padding:20px;
    }

    .cards{
        grid-template-columns:1fr;
    }

    .top{
        flex-direction:column;
        align-items:flex-start;
        gap:20px;
    }

    .top h1{
        font-size:24px;
    }

    .search{
        margin-left:0;
        width:100%;
    }

}

</style>
</head>
<script>

function filterTable(){

    let dateValue =
        document.getElementById("filterDate").value;

    let timeValue =
        document.getElementById("filterTime").value;

    let classValue =
        document.getElementById("classSearch")
        .value
        .toLowerCase();

    let rows =
        document.querySelectorAll("tbody tr");

    rows.forEach(row => {

        let date =
            row.cells[5].innerText;

        let time =
            row.cells[2].innerText;

        let subject =
            row.cells[1].innerText
            .toLowerCase();

        let show = true;

        /* DATE FILTER */
        if(dateValue){

            let formattedDate =
                dateValue;

            if(date !== formattedDate){
                show = false;
            }

        }

        /* TIME FILTER */
        if(timeValue){

            if(!time.includes(timeValue)){
                show = false;
            }

        }

        /* CLASS FILTER */
        if(classValue){

            if(!subject.includes(classValue)){
                show = false;
            }

        }

        row.style.display =
            show ? "" : "none";

    });

}

/* RESET */

function resetFilter(){

    document.getElementById("filterDate").value = "";

    document.getElementById("filterTime").value = "";

    document.getElementById("classSearch").value = "";

    let rows =
        document.querySelectorAll("tbody tr");

    rows.forEach(row => {
        row.style.display = "";
    });

}

</script>
<body>

<!-- SIDEBAR -->
<div class="sidebar">

    <div class="brand">
        Student Panel
    </div>

    <div class="menu">
        <a href="student.php"> Overview</a>
        <a href="attendance_student.php" class="active"> Attendance</a>
        <a href="subject_student.php"> Subject</a>
        <a href="timetable_student.php"> Timetable</a>
    </div>

</div>

<!-- MAIN -->
<div class="main">

    <!-- TOP -->
    <div class="top">

        <div>
            <h1>My Attendance</h1>
            <p>View your attendance records only.</p>
        </div>
        
         <div class="right-top">

            <a href="logout.php" class="logout-btn">
                Logout
            </a>

            <a href="profile_student.php" class="profile">
                👤
            </a>

        </div>

    </div>

    <!-- CARDS -->
    <div class="cards">

       <div class="card">
    <h3>Today's Attendance Rate</h3>
    <p class="blue"><?php echo $attendance_rate; ?>%</p>
</div>

<div class="card">
    <h3>Present Today</h3>
    <p class="green"><?php echo $present; ?></p>
</div>

<div class="card">
    <h3>Absent Today</h3>
    <p class="red"><?php echo $absent; ?></p>
</div>

    </div>

    <!-- SECTION -->
    <div class="section">

        <div class="section-title">
            <h2>Attendance Records</h2>
            <p>Check your attendance history here.</p>
        </div>

        <!-- FILTER -->
        <div class="filter-section">

    <!-- DATE -->
    <input type="date"
           id="filterDate"
           class="filter-input">

    <!-- TIME -->
    <input type="time"
           id="filterTime"
           class="filter-input">

    <!-- CLASS SEARCH -->
    <input type="text"
           id="classSearch"
           class="filter-input"
           placeholder="Search class">

    <!-- FILTER BUTTON -->
    <button class="filter-btn"
            onclick="filterTable()">
        Filter
    </button>

    <!-- RESET BUTTON -->
    <button class="reset-btn"
            onclick="resetFilter()">
        Reset
    </button>

</div>
        <!-- TABLE -->
        <table>

            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Subject</th>
                    <th>Time</th>
                    <th>Status</th>
                    <th>Mode</th>
                    <th>Date</th>
                </tr>
            </thead>

            <tbody>

            <?php
            while($row = mysqli_fetch_assoc($attendance_query)){
            ?>

                <tr>

                    <td>
                        <?php echo $row['student_id']; ?>
                    </td>

                    <td>
                        <?php echo $row['subject_id']; ?>
                    </td>

                    <td>
                        <?php echo $row['attend_time']; ?>
                    </td>

                    <td>

                        <span class="badge <?php echo strtolower($row['status']); ?>">

                            <?php echo $row['status']; ?>

                        </span>

                    </td>

                    <td>
                        <?php echo $row['mode']; ?>
                    </td>

                    <td>
                        <?php echo $row['attend_date']; ?>
                    </td>

                </tr>

            <?php
            }
            ?>

            </tbody>

        </table>

    </div>

</div>

</body>
</html>