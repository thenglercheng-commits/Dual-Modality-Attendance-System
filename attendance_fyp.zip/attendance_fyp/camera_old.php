<?php
$subject_id = $_GET['subject_id'] ?? '';
$date       = $_GET['date'] ?? '';
$time       = $_GET['time'] ?? '';

$python = 'C:\\Users\\TUF\\AppData\\Local\\Programs\\Python\\Python310\\python.exe';
$script = 'C:\\xampp\\htdocs\\attendance_fyp\\recognize_face.py';
$folder = 'C:\\xampp\\htdocs\\attendance_fyp';

$cmd = 'cd /d "'.$folder.'" && start "" "'.$python.'" "'.$script.'" "'.
        $subject_id.'" "'.
        $date.'" "'.
        $time.'"';

pclose(popen($cmd, "r"));

echo "<script>
alert('Camera Started');
window.location='physical_attendance.php';
</script>";
?>