<?php
session_start();
include "connection.php";

/* SEARCH */
$keyword = "";

if(isset($_GET['search'])){
    $keyword = $_GET['keyword'];

    $sql = "
SELECT
s.*,
COUNT(ss.student_id) AS total_enroll
FROM subjects s
LEFT JOIN student_subject ss
ON s.subject_id = ss.subject_id
WHERE
s.subject_id LIKE '%$keyword%'
OR s.subject_name LIKE '%$keyword%'
OR s.faculty LIKE '%$keyword%'
OR s.lecturer LIKE '%$keyword%'
GROUP BY s.subject_id
";
}else{
    $sql = "
SELECT
s.*,
COUNT(ss.student_id) AS total_enroll
FROM subjects s
LEFT JOIN student_subject ss
ON s.subject_id = ss.subject_id
GROUP BY s.subject_id
";
}

$result = $conn->query($sql);

/* EDIT */
$edit = null;

if(isset($_GET['edit'])){
    $id = $_GET['edit'];

    $editQuery = $conn->query("
    SELECT * FROM subjects
    WHERE id='$id'
    ");

    $edit = $editQuery->fetch_assoc();
}

/* ADD SUBJECT */
if(isset($_POST['add_subject'])){

    $subject_id   = $_POST['subject_id'];
    $subject_name = $_POST['subject_name'];
    $faculty      = $_POST['faculty'];
    $lecturer     = $_POST['lecturer'];

    $conn->query("
    INSERT INTO subjects
    (subject_id, subject_name, faculty, lecturer)
    VALUES
    ('$subject_id','$subject_name','$faculty','$lecturer')
    ");

    header("Location: subject_admin.php");
    exit();
}

/* UPDATE SUBJECT */
if(isset($_POST['update_subject'])){

    $id           = $_POST['id'];
    $subject_id   = $_POST['subject_id'];
    $subject_name = $_POST['subject_name'];
    $faculty      = $_POST['faculty'];
    $lecturer     = $_POST['lecturer'];

    $conn->query("
    UPDATE subjects
    SET
    subject_id='$subject_id',
    subject_name='$subject_name',
    faculty='$faculty',
    lecturer='$lecturer'
    WHERE id='$id'
    ");

    header("Location: subject_admin.php");
    exit();
}

/* DELETE */
if(isset($_GET['delete'])){

    $id = $_GET['delete'];

    $conn->query("
    DELETE FROM subjects
    WHERE id='$id'
    ");

    header("Location: subject_admin.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Subject Management</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'Poppins',sans-serif;
    background:#edf4fb;
    display:flex;
}

/* SIDEBAR */

.sidebar{
    width:260px;
    background:white;
    min-height:100vh;
    padding:25px 20px;
    position:fixed;
    left:0;
    top:0;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
}

.sidebar h2{
    font-size:20px;
    margin-bottom:18px;
    font-weight:700;
    color:#111827;
}

.menu a{
    display:flex;
    align-items:center;
    gap:12px;
    padding:14px 16px;
    margin-bottom:10px;
    text-decoration:none;
    color:#1e293b;
    border-radius:16px;
    font-size:15px;
    transition:0.2s;
}

.menu a:hover,
.menu a.active{
    background:#2962ff;
    color:white;
}

/* MAIN */

.main{
    margin-left:260px;
    width:calc(100% - 260px);
    padding:22px 28px;
}

/* TOP CARD */

.top-box{
    background:white;
    border-radius:24px;
    padding:28px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:25px;
}

.top-box h1{
    font-size:24px;
    font-weight:700;
}

.top-box p{
    color:#64748b;
    font-size:14px;
}

.logout-btn{
    background:#2962ff;
    color:white;
    text-decoration:none;
    padding:13px 24px;
    border-radius:16px;
    font-weight:bold;
    font-size:14px;
}

/* CONTENT */

.content-box{
    background:white;
    border-radius:24px;
    padding:28px;
}

.content-box h2{
    font-size:22px;
    margin-bottom:6px;
}

.content-box p{
    color:#64748b;
    margin-bottom:20px;
    font-size:14px;
}

/* FORM */

form{
    width:100%;
}

.form-row{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:16px;
    margin-bottom:20px;
}

.form-row input{
    padding:13px 15px;
    border:1px solid #dbe2ea;
    border-radius:16px;
    font-size:14px;
    outline:none;
    font-family:'Poppins',sans-serif;
}

.form-row input:focus{
    border-color:#2962ff;
}

.form-row button{
    height:56px;
    width:220px;
    border:none;
    border-radius:18px;
    background:#2563eb;
    color:white;
    font-size:15px;
    font-weight:600;
    cursor:pointer;
    justify-self:start;
    font-family:'Poppins',sans-serif;
}

.cancel-btn{
    background:#e2e8f0;
    color:black;
    padding:13px 22px;
    border-radius:16px;
    text-decoration:none;
    font-size:14px;
    font-weight:bold;
}

/* SEARCH */

.search-box{
    margin-top:20px;
    margin-bottom:20px;
}

.filter-row{
    display:flex;
    gap:16px;
    align-items:center;
    flex-wrap:wrap;
}

.filter-row input{
    width:260px;
    padding:13px 15px;
    border:1px solid #dbe2ea;
    border-radius:16px;
    background:#fff;
    font-size:14px;
    outline:none;
    font-family:'Poppins',sans-serif;
}

.filter-row input:focus{
    border-color:#2563eb;
}

.search-btn{
    background:#2962ff;
    color:white;
    border:none;
    padding:13px 22px;
    border-radius:16px;
    font-size:14px;
    font-weight:bold;
    cursor:pointer;
    font-family:'Poppins',sans-serif;
}

.add-btn{
    background:#2962ff;
    color:white;
    border:none;
    padding:13px 22px;
    border-radius:16px;
    font-size:14px;
    font-weight:bold;
    cursor:pointer;
    font-family:'Poppins',sans-serif;
}

.reset-btn{
    background:#eef2f7;
    color:#111827;
    padding:13px 20px;
    border-radius:16px;
    text-decoration:none;
    font-size:14px;
    font-weight:bold;
}

/* TABLE */

.table-box{
    overflow-x:auto;
}

table{
    width:100%;
    border-collapse:collapse;
    overflow:hidden;
    border-radius:18px;
}

th{
    background:#2962ff;
    color:white;
    padding:14px;
    font-size:14px;
}

th:first-child{
    border-top-left-radius:20px;
}

th:last-child{
    border-top-right-radius:20px;
}

td{
    padding:14px;
    border-bottom:1px solid #edf2f7;
    text-align:center;
    font-size:14px;
}

tr:hover td{
    background:#f8fbff;
}

.action a{
    text-decoration:none;
    font-weight:bold;
    margin:0 5px;
}

.action a:first-child{
    color:#2563eb;
}

.delete{
    color:red;
}

</style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <div>
        <h2>Admin Panel</h2>
        <div class="menu">
            <a href="admin.php">Overview</a>
            <a href="attendance_admin.php">Attendance</a>
            <a href="student_admin.php">Student</a>
            <a href="lecturer_admin.php">Lecturer</a>
            <a href="subject_admin.php" class="active">Subject</a>
            <a href="timetable_admin.php">Timetable</a>
        </div>
    </div>
</div>

<!-- MAIN -->
<div class="main">

    <!-- TOP -->
    <div class="top-box">
        <div>
            <h1>Subject Management</h1>
            <p>Manage subject information here.</p>
        </div>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>

    <!-- CONTENT -->
    <div class="content-box">

        <h2>Subject Record</h2>
        <p>Add, edit, search and manage subject details.</p>

        <!-- FORM -->
        <form method="POST">
            <div class="form-row">

            <?php if($edit){ ?>

                <input type="hidden" name="id"
                    value="<?php echo $edit['id']; ?>">

                <input type="text" name="subject_id"
                    value="<?php echo $edit['subject_id']; ?>"
                    placeholder="Subject ID" required>

                <input type="text" name="subject_name"
                    value="<?php echo $edit['subject_name']; ?>"
                    placeholder="Subject Name" required>

                <input type="text" name="faculty"
                    value="<?php echo $edit['faculty']; ?>"
                    placeholder="Faculty" required>

                <input type="text" name="lecturer"
                    value="<?php echo $edit['lecturer']; ?>"
                    placeholder="Lecturer" required>

            </div>

            <button type="submit" name="update_subject">
                Update Subject
            </button>

            <a href="subject_admin.php" class="cancel-btn"
                style="margin-left:12px;">
                Cancel
            </a>

            <?php } else { ?>

                <input type="text" name="subject_id"
                    placeholder="Subject ID" required>

                <input type="text" name="subject_name"
                    placeholder="Subject Name" required>

                <input type="text" name="faculty"
                    placeholder="Faculty" required>

                <input type="text" name="lecturer"
                    placeholder="Lecturer" required>

            </div>

            <button type="submit" name="add_subject" class="add-btn">
                Add Subject
            </button>

            <?php } ?>

        </form>

        <!-- SEARCH -->
        <form method="GET" class="search-box">
            <div class="filter-row">

                <input type="text"
                    name="keyword"
                    placeholder="Search Subject"
                    value="<?php echo htmlspecialchars($keyword); ?>">

                <button type="submit" name="search" class="search-btn">
                    Search
                </button>

                <a href="subject_admin.php" class="reset-btn">
                    Reset
                </a>

            </div>
        </form>

        <!-- TABLE -->
        <div class="table-box">
            <table>
                <tr>
                    <th>Subject ID</th>
                    <th>Subject Name</th>
                    <th>Faculty</th>
                    <th>Lecturer</th>
                    <th>Total Enroll</th>
                    <th>Action</th>
                </tr>

                <?php while($row = $result->fetch_assoc()){ ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['subject_id']); ?></td>
                    <td><?php echo htmlspecialchars($row['subject_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['faculty']); ?></td>
                    <td><?php echo htmlspecialchars($row['lecturer']); ?></td>
                    <td><?php echo $row['total_enroll']; ?></td>
                    <td class="action">
                        <a href="subject_admin.php?edit=<?php echo $row['id']; ?>">
                            Edit
                        </a>
                        |
                        <a class="delete"
                            href="subject_admin.php?delete=<?php echo $row['id']; ?>"
                            onclick="return confirm('Delete this subject?')">
                            Delete
                        </a>
                    </td>
                </tr>
                <?php } ?>

            </table>
        </div>

    </div>
</div>

</body>
</html>