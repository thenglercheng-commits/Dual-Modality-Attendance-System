<?php
session_start();
include "connection.php";

/* =========================
   DELETE
========================= */

if(isset($_GET['delete'])){

    $id = $_GET['delete'];

    $conn->query("
        DELETE FROM timetable
        WHERE id='$id'
    ");

    header("Location: timetable_admin.php");
    exit();
}

/* =========================
   ADD TIMETABLE
========================= */

if(isset($_POST['add'])){

    $subject_id = $_POST['subject_id'];

    $from_date  = $_POST['start_date'];
    $to_date    = $_POST['end_date'];

    $start_time = $_POST['start_time'];
    $end_time   = $_POST['end_time'];

    $days = $_POST['days'] ?? [];

    if(!empty($days)){

        $begin = new DateTime($from_date);

        $finish = new DateTime($to_date);
        $finish->modify('+1 day');

        $period = new DatePeriod(
            $begin,
            new DateInterval('P1D'),
            $finish
        );

        foreach($period as $date){

            $dayName = $date->format('D');

            if(in_array($dayName,$days)){

                $class_date = $date->format('Y-m-d');

                $check = $conn->query("
                    SELECT id
                    FROM timetable
                    WHERE subject_id='$subject_id'
                    AND class_date='$class_date'
                    AND start_time='$start_time'
                ");

                if($check->num_rows == 0){

                    $conn->query("
                        INSERT INTO timetable
                        (subject_id,class_date,start_time,end_time)
                        VALUES
                        ('$subject_id','$class_date','$start_time','$end_time')
                    ");
                }
            }
        }
    }

    header("Location: timetable_admin.php");
    exit();
}

/* =========================
   EDIT
========================= */

$edit = null;

if(isset($_GET['edit'])){

    $id = $_GET['edit'];

    $editQuery = $conn->query("
        SELECT *
        FROM timetable
        WHERE id='$id'
    ");

    $edit = $editQuery->fetch_assoc();
}

/* =========================
   UPDATE
========================= */

if(isset($_POST['update'])){

    $id = $_POST['id'];

    $subject_id = $_POST['subject_id'];
    $class_date = $_POST['class_date'];
    $start_time = $_POST['start_time'];
    $end_time   = $_POST['end_time'];

    $conn->query("
        UPDATE timetable
        SET
        subject_id='$subject_id',
        class_date='$class_date',
        start_time='$start_time',
        end_time='$end_time'
        WHERE id='$id'
    ");

    header("Location: timetable_admin.php");
    exit();
}

/* =========================
   DISPLAY
========================= */

if(isset($_GET['filter']) &&
   $_GET['from_date'] != "" &&
   $_GET['to_date'] != ""){

    $from = $_GET['from_date'];
    $to   = $_GET['to_date'];

    $result = $conn->query("
        SELECT timetable.*, subjects.subject_name
        FROM timetable
        LEFT JOIN subjects
        ON timetable.subject_id = subjects.subject_id
        WHERE class_date BETWEEN '$from' AND '$to'
        ORDER BY class_date,start_time
    ");

}else{

    $result = $conn->query("
        SELECT timetable.*, subjects.subject_name
        FROM timetable
        LEFT JOIN subjects
        ON timetable.subject_id = subjects.subject_id
        WHERE YEARWEEK(class_date,1)=YEARWEEK(CURDATE(),1)
        ORDER BY class_date,start_time
    ");
}
?>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Timetable Management</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    background:#eef5ff;
    display:flex;
}

/* SIDEBAR */

.sidebar{
    width:260px;
    min-height:100vh;
    background:white;
    padding:25px;
    position:fixed;
    left:0;
    top:0;
}

.sidebar h2{
    font-size:20px;
    font-weight:700;
    margin-bottom:18px;
    color:#111827;
}

.sidebar a{
    display:flex;
    align-items:center;
    gap:12px;
    padding:14px 16px;
    margin-bottom:10px;
    border-radius:14px;
    text-decoration:none;
    color:#1e293b;
    font-size:15px;
    transition:.2s;
}

.sidebar a:hover,
.sidebar .active{
    background:#2563eb;
    color:white;
}

/* MAIN */

.main{
    margin-left:260px;
    width:calc(100% - 260px);
    padding:28px;
}

/* TOP */

.top-box{
    background:white;
    border-radius:24px;
    padding:28px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:22px;
    box-shadow:0 8px 25px rgba(0,0,0,.05);
}

.top-box h1{
    font-size:24px;
    margin-bottom:8px;
}

.top-box p{
    color:#64748b;
}

.logout-btn{
    background:#2563eb;
    color:white;
    text-decoration:none;
    padding:12px 22px;
    border-radius:14px;
    font-weight:600;
}

/* CONTENT */

.content-box{
    background:white;
    border-radius:24px;
    padding:28px;
}

.content-box h2{
    font-size:22px;
    margin-bottom:6px;
}

/* FORM */

.form-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:16px;
    margin-bottom:20px;
}

.form-grid input,
.form-grid select{
    padding:13px 15px;
    border:1px solid #dbe2ea;
    border-radius:16px;
    font-size:14px;
    outline:none;
}

.days-grid{
    display:grid;
    grid-template-columns:repeat(6,1fr);
    gap:18px;
    margin-bottom:30px;
}

.day-box{
    display:flex;
    align-items:center;
    gap:10px;
    font-size:15px;
}

/* BUTTONS */

.btn-primary{
    background:#2962ff;
    color:white;
    border:none;
    padding:13px 22px;
    border-radius:16px;
    font-size:14px;
    font-weight:bold;
    cursor:pointer;
}

.btn-secondary{
    height:56px;
    padding:0 30px;
    border:none;
    border-radius:18px;
    background:#64748b;
    color:white;
    font-size:15px;
    font-weight:600;
    cursor:pointer;
}
.btn-secondary{
    background:#eef2f7;
    color:#111827;
    padding:13px 20px;
    border-radius:16px;
    text-decoration:none;
    font-size:14px;
    font-weight:bold;
}
/* FILTER */

.filter-row{
    display:flex;
    gap:16px;
    margin-bottom:30px;
    flex-wrap:wrap;
}

.filter-row input{
    height:56px;
    padding:0 18px;
    border:1px solid #dbe4f0;
    border-radius:18px;
    font-size:15px;
}

/* TABLE */

.table-box{
    overflow-x:auto;
}

table{
    width:100%;
    border-collapse:collapse;
    overflow:hidden;
    border-radius:18px;
}

th{
    background:#2962ff;
    color:white;
    padding:14px;
    font-size:14px;
}

td{
    padding:14px;
    border-bottom:1px solid #edf2f7;
    text-align:center;
    font-size:14px;
}

tr:hover td{
    background:#f8fbff;
}

.action a{
    text-decoration:none;
    font-weight:bold;
    margin:0 5px;
}

.action a:first-child{
    color:#2563eb;
}

.delete{
    color:red;
}

</style>

</head>

<body>

<!-- SIDEBAR -->

<div class="sidebar">
<h2>Admin Panel</h2>
<a href="admin.php">Overview</a>
<a href="attendance_admin.php">Attendance</a>
<a href="student_admin.php">Student</a>
<a href="lecturer_admin.php">Lecturer</a>
<a href="subject_admin.php">Subject</a>
<a href="timetable_admin.php" class="active">Timetable</a>
</div>

<!-- MAIN -->

<div class="main">

<!-- TOP -->

<div class="top-box">

<div>
    <h1>Timetable Management</h1>
    <p>Manage timetable here.</p>
</div>

<a href="logout.php" class="logout-btn">
    Logout
</a>

</div>

<!-- GENERATE / EDIT -->

<div class="content-box">

<?php if($edit){ ?>

<h2>Edit Timetable</h2>

<form method="POST">

<input type="hidden"
       name="id"
       value="<?php echo $edit['id']; ?>">

<div class="form-grid">

<select name="subject_id" required>

<?php
$subjectQuery = $conn->query("SELECT * FROM subjects");

while($subject = $subjectQuery->fetch_assoc()){
?>

<option value="<?php echo $subject['subject_id']; ?>"
<?php if($edit['subject_id'] == $subject['subject_id']) echo "selected"; ?>>

<?php echo $subject['subject_id']; ?>
-
<?php echo $subject['subject_name']; ?>

</option>

<?php } ?>

</select>

<input type="date"
       name="start_date"
       value="<?php echo $edit['class_date']; ?>"
       required>

<input type="date"
       name="end_date"
       value="<?php echo $edit['class_date']; ?>"
       required>

<input type="time"
       name="start_time"
       value="<?php echo $edit['start_time']; ?>"
       required>

<input type="time"
       name="end_time"
       value="<?php echo $edit['end_time']; ?>"
       required>

</div>

<!-- SAME STYLE LIKE GENERATE -->

<div class="days-grid">

<label class="day-box">
<input type="checkbox" disabled> Mon
</label>

<label class="day-box">
<input type="checkbox" disabled> Tue
</label>

<label class="day-box">
<input type="checkbox" disabled> Wed
</label>

<label class="day-box">
<input type="checkbox" disabled> Thu
</label>

<label class="day-box">
<input type="checkbox" disabled> Fri
</label>

<label class="day-box">
<input type="checkbox" disabled> Sat
</label>

</div>

<div style="display:flex; gap:18px;">

<button type="submit"
        name="update"
        class="btn-primary">

    Update Timetable

</button>

<a href="timetable_admin.php"
   class="btn-secondary"
   style="
   text-decoration:none;
   display:flex;
   align-items:center;
   justify-content:center;
   ">

   Cancel

</a>

</div>

</form>

<?php } else { ?>

<h2>Generate Timetable</h2>

<form method="POST">

<div class="form-grid">

<select name="subject_id" required>

<option value="">Select Subject</option>

<?php
$subjectQuery = $conn->query("SELECT * FROM subjects");

while($subject = $subjectQuery->fetch_assoc()){
?>

<option value="<?php echo $subject['subject_id']; ?>">

<?php echo $subject['subject_id']; ?>
-
<?php echo $subject['subject_name']; ?>

</option>

<?php } ?>

</select>

<input type="date" name="start_date" required>

<input type="date" name="end_date" required>

<input type="time" name="start_time" required>

<input type="time" name="end_time" required>

</div>

<div class="days-grid">

<label class="day-box">
<input type="checkbox" name="days[]" value="Mon"> Mon
</label>

<label class="day-box">
<input type="checkbox" name="days[]" value="Tue"> Tue
</label>

<label class="day-box">
<input type="checkbox" name="days[]" value="Wed"> Wed
</label>

<label class="day-box">
<input type="checkbox" name="days[]" value="Thu"> Thu
</label>

<label class="day-box">
<input type="checkbox" name="days[]" value="Fri"> Fri
</label>

<label class="day-box">
<input type="checkbox" name="days[]" value="Sat"> Sat
</label>

</div>

<button type="submit"
        name="add"
        class="btn-primary">

    Generate Timetable

</button>

</form>

<?php } ?>

</div>

<!-- VIEW -->

<div class="content-box">

<h2>View Timetable</h2>

<form method="GET">

<div class="filter-row">

<input type="date" name="from_date">

<input type="date" name="to_date">

<button type="submit" name="filter" class="btn-primary">
 View Range
</button>

<button type="submit" 
        name="this_week" 
        class="btn-secondary">

    This Week

</button>
</div>

</form>

<div class="table-box">

<table>

<tr>
    <th>Subject ID</th>
    <th>Subject Name</th>
    <th>Date</th>
    <th>Start</th>
    <th>End</th>
    <th>Action</th>
</tr>

<?php while($row = $result->fetch_assoc()){ ?>

<tr>

<td><?php echo $row['subject_id']; ?></td>

<td><?php echo $row['subject_name']; ?></td>

<td><?php echo $row['class_date']; ?></td>

<td><?php echo $row['start_time']; ?></td>

<td><?php echo $row['end_time']; ?></td>

<td class="action">

<a href="timetable_admin.php?edit=<?php echo $row['id']; ?>">
Edit
</a>

|

<a class="delete"
href="timetable_admin.php?delete=<?php echo $row['id']; ?>"
onclick="return confirm('Delete timetable?')">

Delete

</a>

</td>

</tr>

<?php } ?>

</table>

</div>

</div>

</div>

</body>
</html>