<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include "connection.php";
date_default_timezone_set("Asia/Kuala_Lumpur");

$subject_id = $_GET['subject_id'] ?? '';
$date = $_GET['date'] ?? date("Y-m-d");
$time = $_GET['time'] ?? '';

if($subject_id == ''){
    die("Invalid QR Code");
}

$res = $conn->query("
SELECT start_time, end_time
FROM timetable
WHERE subject_id='$subject_id'
AND class_date = CURDATE()
LIMIT 1
");

if(!$res || $res->num_rows == 0){
    die("No class found for today.");
}

$row = $res->fetch_assoc();
$today = date("Y-m-d");
$now   = strtotime(date("Y-m-d H:i:s"));
$start = strtotime($today . " " . $row['start_time']);
$end   = strtotime($today . " " . $row['end_time']);

if($now < $start || $now > $end){
    echo "<h2 style='text-align:center;margin-top:50px;font-family:Arial'>
    QR Code Expired<br>Attendance only allowed during class time<br>
    Valid: {$row['start_time']} - {$row['end_time']}
    </h2>";
    exit();
}

/* =========================
   QR SCAN GATE
   This page must only be reached via scan_qr_physical.php, which
   sets this session flag after validating the rotating token. A
   bookmarked or forwarded URL will not have this flag set in the
   visitor's own session, or it will be too old.
========================= */
$gate_key    = 'qr_gate_physical_' . $subject_id;
$gate_time   = $_SESSION[$gate_key] ?? 0;
$GATE_WINDOW = 30; // 30 seconds — matches the QR token's own validity window.
                   // The gate is only checked at page load; the liveness
                   // challenge itself can take as long as needed afterward.

if ((time() - $gate_time) > $GATE_WINDOW) {
    echo "<h2 style='text-align:center;margin-top:50px;font-family:Arial'>
    Please scan the QR code to access this page.
    </h2>";
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Physical Face Attendance</title>
<style>
*{ box-sizing:border-box; }
body{
    margin:0; font-family:Arial;
    background:#eaf6ff;
    display:flex; justify-content:center; align-items:center; min-height:100vh;
}
.box{
    background:white; width:92%; max-width:420px;
    padding:22px; border-radius:20px; text-align:center;
    box-shadow:0 4px 20px rgba(0,0,0,0.12);
}
h2{ margin:0 0 10px; font-size:20px; }
.video-wrap{ position:relative; width:100%; }
video{ width:100%; border-radius:12px; background:#000; display:block; }
canvas{ display:none; }
#blinkOverlay{
    position:absolute; top:8px; left:50%; transform:translateX(-50%);
    background:rgba(0,0,0,0.55); color:#fff;
    padding:6px 14px; border-radius:20px;
    font-size:13px; font-weight:bold;
    pointer-events:none; white-space:nowrap;
}
#blinkOverlay.done{ background:rgba(22,163,74,0.85); }
#challengeBox{
    margin-top:12px; padding:12px 16px;
    background:#fffbeb; border:2px solid #f59e0b;
    border-radius:12px; font-size:16px; font-weight:bold;
    display:block;
}
#challengeBox.done{
    background:#f0fdf4; border-color:#16a34a; color:#15803d;
}
button{
    margin-top:14px; padding:13px 22px; border:none;
    border-radius:10px; background:#2563eb; color:white;
    font-size:16px; cursor:pointer; width:100%;
}
button:disabled{ background:#93b4f5; cursor:not-allowed; }
#msg{ margin-top:13px; font-weight:bold; font-size:15px; min-height:22px; }
.progress-container{
    margin-top:12px; width:100%; background:#f0f0f0;
    border-radius:10px; padding:3px; display:none;
}
.progress-bar{
    width:0%; height:22px;
    background:linear-gradient(90deg,#2563eb,#16a34a);
    border-radius:8px; transition:width 0.3s ease;
    position:relative; overflow:hidden;
}
.progress-text{
    position:absolute; top:50%; left:50%;
    transform:translate(-50%,-50%);
    color:white; font-size:12px; font-weight:bold;
}
</style>
</head>
<body>
<div class="box">
    <h2>Physical Face Attendance</h2>

    <div class="video-wrap">
        <video id="video" autoplay playsinline muted></video>
        <div id="blinkOverlay">👁 Waiting for blink...</div>
    </div>
    <canvas id="canvas"></canvas>

    <div id="challengeBox">Loading challenge...</div>
    <div id="stepIndicator" style="margin-top:8px;font-size:13px;color:#888">
        Step <span id="stepNum">1</span> of 2
    </div>

    <button id="verifyBtn" onclick="verifyFace()" disabled>
        Complete challenge first...
    </button>
    <div id="msg">Opening camera...</div>

    <div class="progress-container" id="progressContainer">
        <div class="progress-bar" id="progressBar">
            <span class="progress-text" id="progressText">0%</span>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/face_mesh.js" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js" crossorigin="anonymous"></script>

<script>
const video  = document.getElementById("video");
const canvas = document.getElementById("canvas");
const ctx    = canvas.getContext("2d");
const msg    = document.getElementById("msg");
const verifyBtn    = document.getElementById("verifyBtn");
const challengeBox = document.getElementById("challengeBox");
const blinkOverlay = document.getElementById("blinkOverlay");

let userLat = "";
let userLng = "";

// ─── Landmark indices ─────────────────────────────────────────────────────────
const L_TOP=159,L_BOT=145,L_LEFT=33, L_RIGHT=133;
const R_TOP=386,R_BOT=374,R_LEFT=362,R_RIGHT=263;
const M_TOP=13, M_BOT=14, M_LEFT=78, M_RIGHT=308;
const NOSE_TIP=4, FACE_LEFT=234, FACE_RIGHT=454;

// ─── Challenge setup ──────────────────────────────────────────────────────────
const CHALLENGES = {
    BLINK:      { label:"👁  Blink once",            instruction:"👁 Please <strong>blink once</strong>" },
    OPEN_MOUTH: { label:"😮  Open your mouth wide",  instruction:"😮 Please <strong>open your mouth wide</strong>" },
    TURN_LEFT:  { label:"⬅️  Turn head LEFT",        instruction:"⬅️ Please <strong>turn your head to the LEFT</strong>" },
    TURN_RIGHT: { label:"➡️  Turn head RIGHT",       instruction:"➡️ Please <strong>turn your head to the RIGHT</strong>" }
};

function pickChallenges(){
    return Object.keys(CHALLENGES).sort(()=>Math.random()-0.5).slice(0,2);
}

let challenges = [], currentStep = 0, allDone = false;

// Frame captured at the EXACT moment the live challenge completes.
// verifyFace() sends THIS frame, not a new capture at click time,
// so a photo cannot be swapped in after the liveness check passes.
let capturedImage = null;

// ─── Calibration ──────────────────────────────────────────────────────────────
let earSamples=[],earBaseline=null,baselineReady=false;
let marSamples=[],marBaseline=null;
let noseSamples=[],noseBaseline=null;
const BASELINE_FRAMES=35;
let actionFrameCount=0;

// ─── Geometry ─────────────────────────────────────────────────────────────────
function dist(a,b){ return Math.hypot(a.x-b.x,a.y-b.y); }
function getEAR(lm){
    const l=dist(lm[L_TOP],lm[L_BOT])/(dist(lm[L_LEFT],lm[L_RIGHT])+1e-6);
    const r=dist(lm[R_TOP],lm[R_BOT])/(dist(lm[R_LEFT],lm[R_RIGHT])+1e-6);
    return (l+r)/2;
}
function getMAR(lm){ return dist(lm[M_TOP],lm[M_BOT])/(dist(lm[M_LEFT],lm[M_RIGHT])+1e-6); }
function getNoseX(lm){
    return (lm[NOSE_TIP].x-lm[FACE_LEFT].x)/(lm[FACE_RIGHT].x-lm[FACE_LEFT].x+1e-6);
}

// ─── Detection ────────────────────────────────────────────────────────────────
function detectAction(lm, challenge){
    if(!earBaseline) return false;
    if(challenge==="BLINK"){
        const ear=getEAR(lm), C=earBaseline*0.75, O=earBaseline*0.85;
        blinkOverlay.textContent=`EAR:${ear.toFixed(3)}`;
        if(ear<C){ actionFrameCount++; }
        else if(ear>O){ if(actionFrameCount>=1&&actionFrameCount<=25){ actionFrameCount=0; return true; } actionFrameCount=0; }
        return false;
    }
    if(challenge==="OPEN_MOUTH"){
        if(!marBaseline) return false;
        const mar=getMAR(lm);
        blinkOverlay.textContent=`MAR:${mar.toFixed(3)}`;
        if(mar > marBaseline*3.0){
            actionFrameCount++;
            if(actionFrameCount>=3) return true;
        } else { actionFrameCount=0; }
        return false;
    }
    if(challenge==="TURN_LEFT"){
        if(!noseBaseline) return false;
        const nx=getNoseX(lm);
        blinkOverlay.textContent=`NoseX:${nx.toFixed(3)}`;
        // mirrored: user turns LEFT = nose goes RIGHT in camera
        return nx > (noseBaseline+0.12);
    }
    if(challenge==="TURN_RIGHT"){
        if(!noseBaseline) return false;
        const nx=getNoseX(lm);
        blinkOverlay.textContent=`NoseX:${nx.toFixed(3)}`;
        // mirrored: user turns RIGHT = nose goes LEFT in camera
        return nx < (noseBaseline-0.12);
    }
    return false;
}

function onStepComplete(){
    actionFrameCount=0; currentStep++;
    if(currentStep>=challenges.length){
        // All challenges done — capture the frame RIGHT NOW, while the
        // live person who just performed the action is still in view.
        canvas.width=320; canvas.height=240;
        ctx.drawImage(video,0,0,320,240);
        capturedImage = canvas.toDataURL("image/jpeg",0.6);

        allDone=true;
        challengeBox.innerHTML="✅ Liveness verified! Press Verify Face.";
        challengeBox.className="done";
        blinkOverlay.textContent="✅ Live face confirmed";
        blinkOverlay.className="done";
        verifyBtn.disabled=false; verifyBtn.textContent="Verify Face";
        msg.innerHTML="All challenges passed. Press Verify Face.";
        document.getElementById("stepIndicator").style.display="none";
    } else { showCurrentChallenge(); }
}

function showCurrentChallenge(){
    const c=CHALLENGES[challenges[currentStep]];
    challengeBox.innerHTML=c.instruction; challengeBox.className="";
    document.getElementById("stepNum").textContent=currentStep+1;
    msg.innerHTML=`Step ${currentStep+1} of 2: ${c.label}`;
}

function processLandmarks(lm){
    const ear=getEAR(lm),mar=getMAR(lm),nx=getNoseX(lm);
    if(!baselineReady){
        earSamples.push(ear); marSamples.push(mar); noseSamples.push(nx);
        blinkOverlay.textContent=`Calibrating... ${Math.round(earSamples.length/BASELINE_FRAMES*100)}%`;
        if(earSamples.length>=BASELINE_FRAMES){
            const eS=[...earSamples].sort((a,b)=>b-a);
            earBaseline=eS.slice(0,21).reduce((s,v)=>s+v,0)/21;
            const mS=[...marSamples].sort((a,b)=>a-b);
            marBaseline=mS.slice(0,21).reduce((s,v)=>s+v,0)/21;
            const nS=[...noseSamples].sort((a,b)=>a-b);
            noseBaseline=nS[Math.floor(nS.length/2)];
            baselineReady=true; showCurrentChallenge();
        }
        return;
    }
    if(allDone) return;
    if(detectAction(lm,challenges[currentStep])) onStepComplete();
}

// ─── MediaPipe ────────────────────────────────────────────────────────────────
function initFaceMesh(){
    const fm=new FaceMesh({locateFile:f=>`https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/${f}`});
    fm.setOptions({maxNumFaces:1,refineLandmarks:true,minDetectionConfidence:0.4,minTrackingConfidence:0.4});
    fm.onResults(r=>{
        if(!r.multiFaceLandmarks||!r.multiFaceLandmarks.length){
            if(!allDone) blinkOverlay.textContent="👁 No face — move closer"; return;
        }
        if(!allDone) processLandmarks(r.multiFaceLandmarks[0]);
    });
    new Camera(video,{onFrame:async()=>{await fm.send({image:video});},width:640,height:480}).start();
    msg.innerHTML="Camera ready. Keep still for calibration...";
}

// ─── GPS ──────────────────────────────────────────────────────────────────────
navigator.geolocation.getCurrentPosition(
    pos=>{userLat=pos.coords.latitude;userLng=pos.coords.longitude;},
    ()=>{msg.innerHTML="Please allow location access.";},
    {enableHighAccuracy:true,timeout:10000,maximumAge:0}
);

// ─── Mobile check ─────────────────────────────────────────────────────────────
if(!/Android|iPhone|iPad|iPod|Opera Mini|IEMobile|WPDesktop/i.test(navigator.userAgent)){
    document.body.innerHTML=`<div style="font-family:Arial;text-align:center;padding:40px"><h2>Please scan QR using mobile phone</h2></div>`;
    throw new Error("Desktop blocked");
}

// ─── Camera ───────────────────────────────────────────────────────────────────
async function startCamera(){
    msg.innerHTML="Requesting camera access...";
    challenges=pickChallenges();
    try{
        const stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:"user",width:{ideal:640},height:{ideal:480}},audio:false});
        video.srcObject=stream; video.setAttribute("playsinline",true); await video.play();
        try{ initFaceMesh(); }
        catch(e){ console.warn(e); allDone=true; verifyBtn.disabled=false; verifyBtn.textContent="Verify Face"; }
    }catch(err){
        let m="Camera access failed.";
        if(err.name==='NotAllowedError') m="📱 Camera permission denied.";
        else if(err.name==='NotFoundError') m="📱 No camera found.";
        msg.innerHTML=m;
    }
}
window.addEventListener("load",()=>{setTimeout(startCamera,1000);});

// ─── Verify ───────────────────────────────────────────────────────────────────
function verifyFace(){
    if(!allDone){ msg.innerHTML="⚠ Please complete the challenge first."; return; }
    if(userLat===""||userLng===""){ alert("Waiting for GPS location..."); return; }

    const progressContainer=document.getElementById("progressContainer");
    verifyBtn.disabled=true; verifyBtn.textContent="Verifying...";
    progressContainer.style.display="block";

    let image;
    if(capturedImage){
        // Use the frame captured at the moment the liveness challenge
        // passed — NOT a new frame from the current camera view.
        image = capturedImage;
    } else {
        // Fallback only: MediaPipe was unavailable, no challenge ran,
        // so there is nothing to anchor to — capture live as before.
        canvas.width=320; canvas.height=240;
        ctx.drawImage(video,0,0,320,240);
        image = canvas.toDataURL("image/jpeg",0.6);
    }

    updateProgress(20,"Capturing image...");
    setTimeout(()=>{
        updateProgress(40,"Analyzing face...");
        setTimeout(()=>{
            updateProgress(60,"Checking liveness...");
            setTimeout(()=>{
                updateProgress(80,"Matching database...");
                fetch("verify_physical.php",{
                    method:"POST",
                    headers:{"Content-Type":"application/x-www-form-urlencoded"},
                    body:"image="+encodeURIComponent(image)+"&subject_id=<?php echo $subject_id; ?>&date=<?php echo $date; ?>&time=<?php echo $time; ?>&lat="+encodeURIComponent(userLat)+"&lng="+encodeURIComponent(userLng)
                })
                .then(r=>r.text())
                .then(data=>{
                    updateProgress(100,"Verification complete");
                    setTimeout(()=>{
                        progressContainer.style.display="none";
                        msg.innerHTML=data;

                        // Lock button permanently — success OR already taken
                        if(data.includes("Attendance Success") ||
                           data.includes("already taken")){
                            verifyBtn.disabled=true;
                            verifyBtn.textContent = data.includes("Attendance Success")
                                                    ? "Attendance Taken ✔"
                                                    : "Already Submitted ✔";
                            challengeBox.innerHTML = data.includes("Attendance Success")
                                                    ? "✅ Attendance recorded successfully."
                                                    : "✅ Attendance already taken for this class.";
                            challengeBox.className="done";
                            document.getElementById("stepIndicator").style.display="none";
                        } else {
                            // Genuine failure — reset for retry
                            allDone=false; currentStep=0; baselineReady=false;
                            capturedImage=null;
                            earSamples=[]; marSamples=[]; noseSamples=[]; actionFrameCount=0;
                            challenges=pickChallenges();
                            verifyBtn.disabled=true; verifyBtn.textContent="Complete challenge first...";
                            challengeBox.innerHTML="Please complete the challenge again to retry.";
                            challengeBox.className="";
                            blinkOverlay.className="";
                            document.getElementById("stepIndicator").style.display="";
                        }
                    },1000);
                })
                .catch(()=>{ progressContainer.style.display="none"; verifyBtn.disabled=false; verifyBtn.textContent="Verify Face"; msg.innerHTML="Error during verification."; });
            },800);
        },600);
    },400);
}

function updateProgress(pct,text){
    document.getElementById("progressContainer").style.display="block";
    document.getElementById("progressBar").style.width=pct+"%";
    document.getElementById("progressText").textContent=pct+"%";
    msg.innerHTML=text;
}
</script>
</body>
</html>