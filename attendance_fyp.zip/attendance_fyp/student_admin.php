<?php
session_start();
include "connection.php";

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}

/* SEARCH */
$search = $_GET['search'] ?? '';

/* DELETE */
if(isset($_GET['delete'])){

    $id = $_GET['delete'];

    $getStudent = $conn->query("
        SELECT student_id
        FROM students
        WHERE id='$id'
    ");

    $student = $getStudent->fetch_assoc();
    $student_id = $student['student_id'];

    $conn->query("DELETE FROM users WHERE id='$id'");
    $conn->query("DELETE FROM students WHERE id='$id'");
    $conn->query("DELETE FROM attendance WHERE student_id='$student_id'");

    header("Location: student_admin.php");
    exit();
}

/* EDIT */
$edit = null;

if(isset($_GET['edit'])){

    $id = $_GET['edit'];

    $editQuery = $conn->query("
        SELECT 
        students.id,
        students.student_id,
        students.faculty,
        students.batch,
        users.name,
        users.email,
        users.phone,
        users.address,
        users.password

        FROM students

        LEFT JOIN users
        ON students.id = users.id

        WHERE students.id='$id'
    ");

    $edit = $editQuery->fetch_assoc();
}

/* ADD STUDENT */
if(isset($_POST['add_student'])){

    $student_id = $_POST['student_id'];
    $name       = $_POST['name'];
    $email      = $_POST['email'];
    $phone      = $_POST['phone'];
    $address    = $_POST['address'];
    $faculty    = $_POST['faculty'];
    $batch      = $_POST['batch'];
    $password   = $_POST['password'];

    $conn->query("
        INSERT INTO users(name,email,phone,address,password,role)
        VALUES(
            '$name',
            '$email',
            '$phone',
            '$address',
            '$password',
            'student'
        )
    ");

    $user_id = $conn->insert_id;

    $conn->query("
        INSERT INTO students(student_id,faculty,batch,id)
        VALUES(
            '$student_id',
            '$faculty',
            '$batch',
            '$user_id'
        )
    ");

    header("Location: student_admin.php");
    exit();
}

/* UPDATE */
if(isset($_POST['update_student'])){

    $id         = $_POST['id'];
    $student_id = $_POST['student_id'];
    $name       = $_POST['name'];
    $email      = $_POST['email'];
    $phone      = $_POST['phone'];
    $address    = $_POST['address'];
    $faculty    = $_POST['faculty'];
    $batch      = $_POST['batch'];
    $password   = $_POST['password'];

    $conn->query("
        UPDATE users
        SET
        name='$name',
        email='$email',
        phone='$phone',
        address='$address',
        password='$password'
        WHERE id='$id'
    ");

    $conn->query("
        UPDATE students
        SET
        student_id='$student_id',
        faculty='$faculty',
        batch='$batch'
        WHERE id='$id'
    ");

    header("Location: student_admin.php");
    exit();
}

/* GET STUDENTS */
$sql = "
SELECT
students.id,
students.student_id,
students.faculty,
students.batch,
users.name,
users.email,
users.phone,
users.address

FROM students

LEFT JOIN users
ON students.id = users.id

WHERE 1
";

if($search != ''){
    $sql .= "
    AND (
        students.student_id LIKE '%$search%'
        OR users.name LIKE '%$search%'
        OR users.email LIKE '%$search%'
    )
    ";
}

$sql .= " ORDER BY students.id DESC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Student Management</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'Poppins',sans-serif;
    background:#edf4fb;
    display:flex;
}

/* SIDEBAR */

.sidebar{
    width:260px;
    background:white;
    min-height:100vh;
    padding:25px 20px;
    position:fixed;
    left:0;
    top:0;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
}

.logo{
    width:55px;
    height:55px;
    background:#2962ff;
    border-radius:18px;
    display:flex;
    align-items:center;
    justify-content:center;
    color:white;
    font-size:24px;
    margin-bottom:20px;
}

.sidebar h2{
    font-size:18px;
    margin-bottom:35px;
    color:#0f172a;
}

.menu a{
    display:flex;
    align-items:center;
    gap:12px;
    padding:14px 16px;
    margin-bottom:10px;
    text-decoration:none;
    color:#1e293b;
    border-radius:16px;
    font-size:15px;
    transition:0.2s;
}

.menu a:hover,
.menu a.active{
    background:#2962ff;
    color:white;
}

.profile-box{
    background:#f8fafc;
    border-radius:18px;
    padding:16px;
    display:flex;
    align-items:center;
    gap:12px;
    margin-top:40px;
}

.profile-circle{
    width:48px;
    height:48px;
    border-radius:50%;
    background:#2962ff;
    color:white;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:22px;
}

.profile-box h4{
    font-size:16px;
}

.profile-box p{
    font-size:13px;
    color:#64748b;
}

/* MAIN */

.main{
    margin-left:260px;
    width:calc(100% - 260px);
    padding:25px;
}

/* TOP */

.top-card{
    background:white;
    border-radius:24px;
    padding:28px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:25px;
}

.top-card h1{
    font-size:24px;
    margin-bottom:6px;
}

.top-card p{
    font-size:14px;
    color:#64748b;
}

.logout-btn{
    background:#2962ff;
    color:white;
    text-decoration:none;
    padding:13px 24px;
    border-radius:16px;
    font-weight:bold;
    font-size:14px;
}

/* SECTION */

.section{
    background:white;
    border-radius:24px;
    padding:28px;
}

.section h2{
    font-size:22px;
    margin-bottom:6px;
}

.section p{
    font-size:14px;
    color:#64748b;
    margin-bottom:20px;
}

/* FORM */

form{
    width:100%;
}

.form-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:16px;
    margin-bottom:20px;
}

.form-grid input{
    padding:13px 15px;
    border:1px solid #dbe2ea;
    border-radius:16px;
    font-size:14px;
    outline:none;
}

.form-grid input:focus{
    border-color:#2962ff;
}

.add-btn{
    background:#2962ff;
    color:white;
    border:none;
    padding:13px 22px;
    border-radius:16px;
    font-size:14px;
    font-weight:bold;
    cursor:pointer;
}

.cancel-btn{
    background:#e2e8f0;
    color:black;
    padding:13px 22px;
    border-radius:16px;
    text-decoration:none;
    font-size:14px;
    font-weight:bold;
}

/* SEARCH */

.search-box{
    margin-top:20px;
    margin-bottom:20px;
}

.filter-row{
    display:flex;
    gap:16px;
    align-items:center;
    flex-wrap:wrap;
}

.filter-row input{
    width:260px;
    padding:13px 15px;
    border:1px solid #dbe2ea;
    border-radius:16px;
    background:#fff;
    font-size:14px;
    outline:none;
}

.search-btn{
    background:#2962ff;
    color:white;
    border:none;
    padding:13px 22px;
    border-radius:16px;
    font-size:14px;
    font-weight:bold;
    cursor:pointer;
}

.reset-btn{
    background:#eef2f7;
    color:#111827;
    padding:13px 20px;
    border-radius:16px;
    text-decoration:none;
    font-size:14px;
    font-weight:bold;
}

/* TABLE */

.table-box{
    overflow-x:auto;
}

table{
    width:100%;
    border-collapse:collapse;
    overflow:hidden;
    border-radius:18px;
}

th{
    background:#2962ff;
    color:white;
    padding:14px;
    font-size:14px;
}

td{
    padding:14px;
    border-bottom:1px solid #edf2f7;
    text-align:center;
    font-size:14px;
}

tr:hover{
    background:#f8fbff;
}

.action-btn{
    text-decoration:none;
    font-weight:bold;
    margin:0 5px;
}

.edit-btn{
    color:#2962ff;
}

.delete-btn{
    color:red;
}

</style>
</head>

<body>

<!-- SIDEBAR -->

<div class="sidebar">

    <div>
        <h2>Admin Panel</h2>

        <div class="menu">
            <a href="admin.php"> Overview</a>
            <a href="attendance_admin.php"> Attendance</a>
            <a href="student_admin.php" class="active"> Student</a>
            <a href="lecturer_admin.php"> Lecturer</a>
            <a href="subject_admin.php"> Subject</a>
            <a href="timetable_admin.php"> Timetable</a>
        </div>

    </div>

</div>

<!-- MAIN -->

<div class="main">

    <!-- TOP -->

    <div class="top-card">

        <div>
            <h1>Student Management</h1>
            <p>Manage student information here.</p>
        </div>

        <a href="logout.php" class="logout-btn">Logout</a>

    </div>

    <!-- SECTION -->

    <div class="section">

        <h2>Student Record</h2>
        <p>Add, edit, search and manage student details.</p>

        <!-- FORM -->
        <form method="POST">

        <?php if($edit){ ?>

        <input type="hidden" name="id" value="<?php echo $edit['id']; ?>">

        <div class="form-grid">

            <input type="text" name="student_id" value="<?php echo $edit['student_id']; ?>" required>
            <input type="text" name="name" value="<?php echo $edit['name']; ?>" required>
            <input type="email" name="email" value="<?php echo $edit['email']; ?>" required>
            <input type="text" name="phone" value="<?php echo $edit['phone']; ?>" required>
            <input type="text" name="address" value="<?php echo $edit['address']; ?>" required>
            <input type="text" name="faculty" value="<?php echo $edit['faculty']; ?>" required>
            <input type="text" name="batch" value="<?php echo $edit['batch']; ?>" required>
            <input type="text" name="password" value="<?php echo $edit['password']; ?>" required>

        </div>

        <button type="submit" name="update_student" class="add-btn">
            Update
        </button>

        <a href="student_admin.php" class="cancel-btn">
            Cancel
        </a>

        <?php } else { ?>

        <div class="form-grid">

            <input type="text" name="student_id" placeholder="Student ID" required>
            <input type="text" name="name" placeholder="Student Name" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="text" name="phone" placeholder="Phone Number" required>
            <input type="text" name="address" placeholder="Address" required>
            <input type="text" name="faculty" placeholder="Faculty" required>
            <input type="text" name="batch" placeholder="Batch" required>
            <input type="text" name="password" placeholder="Password" required>

        </div>

        <button type="submit" name="add_student" class="add-btn">
            Add Student
        </button>

        <?php } ?>

        </form>

        <!-- SEARCH -->

        <div class="search-box">

            <form method="GET">

                <div class="filter-row">

                    <input
                    type="text"
                    name="search"
                    placeholder=" Search ID / Name / Email"
                    value="<?php echo $search; ?>">

                    <button type="submit" class="search-btn">
                         Search
                    </button>

                    <a href="student_admin.php" class="reset-btn">
                        Reset
                    </a>

                </div>

            </form>

        </div>

        <!-- TABLE -->

        <div class="table-box">

        <table>

            <tr>
                <th>Student ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Address</th>
                <th>Faculty</th>
                <th>Batch</th>
                <th>Action</th>
            </tr>

            <?php while($row = $result->fetch_assoc()){ ?>

            <tr>

                <td>
                    <a href="subject_view.php?student_id=<?php echo $row['student_id']; ?>" 
                    style="color:#2563eb;font-weight:600;text-decoration:none;">
                    <?php echo $row['student_id']; ?>
                    
                </td>

                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['email']; ?></td>
                <td><?php echo $row['phone']; ?></td>
                <td><?php echo $row['address']; ?></td>
                <td><?php echo $row['faculty']; ?></td>
                <td><?php echo $row['batch']; ?></td>

                <td>

                    <a
                    class="action-btn edit-btn"
                    href="student_admin.php?edit=<?php echo $row['id']; ?>">
                    Edit
                    </a>

                    |

                    <a
                    class="action-btn delete-btn"
                    href="student_admin.php?delete=<?php echo $row['id']; ?>"
                    onclick="return confirm('Delete this student?')">
                    Delete
                    </a>

                </td>

            </tr>

            <?php } ?>

        </table>

        </div>

    </div>

</div>

</body>
</html>