<?php
session_start();
include "connection.php";

if(!isset($_SESSION['name']) || $_SESSION['role'] != 'lecturer'){
    header("Location: login.php");
    exit();
}

$lecturer = $_SESSION['name'];
$result = null;

/* UPDATE CLASS */
if(isset($_POST['update_class'])){

    $id = $_POST['id'];
    $new_date = $_POST['new_date'];
    $new_start = $_POST['new_start'];
    $new_end = $_POST['new_end'];

    $sql = "
    UPDATE timetable
    SET class_date='$new_date',
        start_time='$new_start',
        end_time='$new_end'
    WHERE id='$id'
    ";

    $conn->query($sql);
}

/* SEARCH */
if(isset($_GET['search'])){

    $subject_id = $_GET['subject_id'] ?? '';
    $date       = $_GET['class_date'] ?? '';
    $time       = $_GET['start_time'] ?? '';

    $sql = "
    SELECT timetable.*, subjects.subject_name
    FROM timetable
    LEFT JOIN subjects
        ON timetable.subject_id = subjects.subject_id
    WHERE subjects.lecturer = '$lecturer'
    ";

    if($subject_id != ''){
        $sql .= " AND timetable.subject_id LIKE '%$subject_id%'";
    }

    if($date != ''){
        $sql .= " AND timetable.class_date = '$date'";
    }

    if($time != ''){
        $sql .= " AND timetable.start_time = '$time'";
    }

    $sql .= " ORDER BY timetable.class_date, timetable.start_time";

    $result = $conn->query($sql);
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Physical Attendance</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    display:flex;
    background:#f5f8fc;
}

/* SIDEBAR */
.sidebar{
    width:260px;
    min-height:100vh;
    background:white;
    padding:25px;
    position:fixed;
    left:0;
    top:0;
}

.sidebar a{
    display:flex;
    align-items:center;
    gap:12px;
    padding:14px 16px;
    margin-bottom:10px;
    border-radius:12px;
    text-decoration:none;
    color:black;
    transition:0.2s;
    font-size:15px;
}

.sidebar a.active{
    background:#2563eb;
    color:white;
}

/* MAIN */

.main{
    margin-left:260px;
    width:calc(100% - 260px);
    padding:35px;
}

/* HEADER */

.top{
    background:white;
    border-radius:25px;
    padding:28px 40px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    box-shadow:0 8px 25px rgba(0,0,0,.05);
    margin-bottom:30px;
}

.top h1{
    color:#0b1652;
    font-size:28px;
}

.top p{
    color:#475569;
    margin-top:8px;
}

.back-btn{
    border:2px solid #d9e2f2;
    padding:12px 22px;
    border-radius:16px;
    text-decoration:none;
    color:#2563eb;
    font-weight:600;
    font-weight:bold;
}

/* SEARCH CARD */

.box{
    background:white;
    border-radius:25px;
    padding:28px 40px;
    box-shadow:0 8px 25px rgba(0,0,0,.05);
}

.box h2{
    color:#0d1b57;
    margin-bottom:10px;
}

.line{
    width:45px;
    height:5px;
    background:#2563eb;
    border-radius:20px;
    margin:15px 0 35px;
}

/* FORM */

.search-row{
    display:flex;
    gap:20px;
    align-items:center;
    flex-wrap:wrap;
}

.search-row input{
     width:260px;
    padding:13px 15px;
    border:1px solid #dbe2ea;
    border-radius:16px;
    background:#fff;
    font-size:14px;
    outline:none;
}

.search-btn{
     background:#2962ff;
    color:white;
    border:none;
    padding:13px 22px;
    border-radius:16px;
    font-size:14px;
    font-weight:bold;
    cursor:pointer;
}

/* RESULT TABLE */

table{
    width:100%;
    border-collapse:collapse;
    margin-top:30px;
    overflow:hidden;
    border-radius:18px;
}

th{
    background:#2563eb;
    color:white;
    padding:15px;
}

td{
    padding:15px;
    text-align:center;
    border-bottom:1px solid #e2e8f0;
}

.generate{
    background:#16a34a;
    color:white;
    padding:10px 18px;
    border-radius:10px;
    text-decoration:none;
}

.savebtn{
    background:#2563eb;
    color:white;
    border:none;
    padding:10px 16px;
    border-radius:10px;
}

td input[type="date"],
td input[type="time"]{
    border:1px solid #dbe2ef;
    border-radius:12px !important;
    padding:8px 12px;
    height:42px;
    background:white;
}

</style>

<style>
/* ── Location Modal ── */
#locationModal{
    display:none; position:fixed; inset:0;
    background:rgba(0,0,0,0.45); z-index:9999;
    justify-content:center; align-items:center;
}
#locationModal.show{ display:flex; }
.modal-box{
    background:white; border-radius:18px; padding:30px 28px;
    width:100%; max-width:420px; box-shadow:0 12px 40px rgba(0,0,0,0.2);
}
.modal-box h3{ margin:0 0 4px; color:#0d1b57; font-size:18px; }
.modal-box .sub{ color:#6b7280; font-size:13px; margin-bottom:20px; }
.modal-tabs{ display:flex; border-radius:10px; overflow:hidden;
             border:1px solid #d1d5db; margin-bottom:18px; }
.modal-tab{ flex:1; padding:9px; font-size:13px; font-weight:bold;
            cursor:pointer; background:#f9fafb; color:#6b7280; border:none; }
.modal-tab.active{ background:#2563eb; color:white; }
.modal-section{ display:none; }
.modal-section.active{ display:block; }
.mfield{ margin-bottom:13px; text-align:left; }
.mfield label{ display:block; font-size:12px; font-weight:bold;
               color:#374151; margin-bottom:3px; }
.mfield input{ width:100%; padding:9px 12px; border:1px solid #d1d5db;
               border-radius:8px; font-size:14px; outline:none; }
.mfield input:focus{ border-color:#2563eb; }
.mfield .hint{ font-size:11px; color:#9ca3af; margin-top:2px; }
.radius-row{ display:flex; align-items:center; gap:8px; margin-bottom:14px; }
.radius-row label{ font-size:12px; font-weight:bold; color:#374151; white-space:nowrap; }
.radius-row input{ width:80px; padding:8px; border:1px solid #d1d5db;
                   border-radius:6px; font-size:13px; }
.modal-btn{ width:100%; padding:12px; border:none; border-radius:10px;
            font-size:15px; font-weight:bold; cursor:pointer; color:white;
            display:block; margin-top:8px; }
.modal-btn.blue{ background:#2563eb; margin-top:0; margin-bottom:0; }
.modal-btn.blue:disabled{ background:#93b4f5; cursor:not-allowed; }
.modal-btn.green{ background:#16a34a; margin-top:10px; }
.modal-btn.gray{ background:#6b7280; font-size:13px; padding:9px; margin-top:6px; }
.modal-btn.cancel{ background:#e5e7eb; color:#374151; margin-top:10px; }
.map-link-btn{ display:block; width:100%; padding:9px; margin-top:10px; margin-bottom:0;
               background:#f0fdf4; border:1px solid #16a34a; border-radius:8px;
               color:#15803d; font-size:12px; font-weight:bold; text-decoration:none;
               text-align:center; }
.gps-preview{ background:#f0fdf4; border:1px solid #16a34a; border-radius:8px;
              padding:12px; margin-top:10px; margin-bottom:0; font-size:12px;
              text-align:left; display:none; }
.gps-preview.bad{ background:#fef2f2; border-color:#dc2626; }
.prow{ display:flex; justify-content:space-between; margin-bottom:2px; }
.plbl{ color:#6b7280; }
.pval{ font-weight:bold; font-family:monospace; }
.acc-badge{ display:inline-block; padding:2px 7px; border-radius:8px;
            font-size:11px; font-weight:bold; margin-top:3px; }
.acc-good{ background:#dcfce7; color:#15803d; }
.acc-warn{ background:#fef9c3; color:#a16207; }
.acc-bad { background:#fee2e2; color:#991b1b; }
#modalMsg{ font-size:13px; font-weight:bold; margin-top:8px; min-height:16px;
           text-align:center; }
</style>

<!-- Location Modal -->
<div id="locationModal">
  <div class="modal-box">
    <h3>📍 Set Classroom Location</h3>
    <p class="sub" id="modalSubject">Subject: —</p>

    <div class="modal-tabs">
      <button class="modal-tab active" onclick="switchModalTab('auto')">📡 Auto GPS</button>
      <button class="modal-tab"        onclick="switchModalTab('manual')">✏️ Manual</button>
    </div>

    <!-- AUTO GPS -->
    <div class="modal-section active" id="mTabAuto">
      <button class="modal-btn blue" id="gpsBtn" onclick="captureModalGPS()">
        📡 Capture My Location
      </button>
      <div class="gps-preview" id="gpsPreview">
        <div class="prow"><span class="plbl">Latitude:</span>  <span class="pval" id="mGLat">—</span></div>
        <div class="prow"><span class="plbl">Longitude:</span> <span class="pval" id="mGLng">—</span></div>
        <div class="prow"><span class="plbl">Accuracy:</span>  <span class="pval" id="mGAcc">—</span></div>
        <div id="mGBadge"></div>
        <a id="mGMapLink" class="map-link-btn" target="_blank">
          🗺 Verify on Google Maps ↗
        </a>
        <div class="radius-row">
          <label>Radius:</label>
          <input type="number" id="gRadius" value="100" min="20" max="500">
          <span style="font-size:12px;color:#6b7280">meters</span>
        </div>
        <button class="modal-btn green" onclick="saveModalLocation('gps')">✅ Save & Generate QR</button>
        <button class="modal-btn gray"  onclick="captureModalGPS()">🔄 Retry GPS</button>
      </div>
    </div>

    <!-- MANUAL ENTRY -->
    <div class="modal-section" id="mTabManual">
      <a href="https://maps.google.com" target="_blank" class="map-link-btn">
        🗺 Open Google Maps to get coordinates ↗
      </a>
      <p style="font-size:11px;color:#6b7280;margin:0 0 12px;text-align:left">
        Long-press your classroom on Google Maps → copy the coordinates shown.
      </p>
      <div class="mfield">
        <label>Latitude</label>
        <input type="number" id="mMLat" placeholder="e.g. 3.056789" step="0.000001">
        <div class="hint">Malaysia: ~1 to 7</div>
      </div>
      <div class="mfield">
        <label>Longitude</label>
        <input type="number" id="mMLng" placeholder="e.g. 101.593456" step="0.000001">
        <div class="hint">Malaysia: ~99 to 119</div>
      </div>
      <div class="radius-row">
        <label>Radius:</label>
        <input type="number" id="mRadius" value="100" min="20" max="500">
        <span style="font-size:12px;color:#6b7280">meters</span>
      </div>
      <div id="mManualPreview" style="display:none">
        <a id="mMMapLink" class="map-link-btn" target="_blank">
          🗺 Verify coordinates on map ↗
        </a>
      </div>
      <button class="modal-btn green" onclick="saveModalLocation('manual')">✅ Save & Generate QR</button>
    </div>

    <div id="modalMsg"></div>
    <button class="modal-btn cancel" onclick="closeModal()">✕ Cancel</button>
  </div>
</div>

<script>
let _subject_id = '', _date = '', _time = '';
let _gpsLat = null, _gpsLng = null;

// Open modal when Generate clicked
function generateQR(subject_id, date, time){
    _subject_id = subject_id;
    _date       = date;
    _time       = time;
    document.getElementById('modalSubject').textContent = 'Subject: ' + subject_id;
    document.getElementById('modalMsg').textContent = '';
    document.getElementById('gpsPreview').style.display = 'none';
    _gpsLat = null; _gpsLng = null;
    switchModalTab('auto');
    document.getElementById('locationModal').classList.add('show');
}

function closeModal(){
    document.getElementById('locationModal').classList.remove('show');
}

function switchModalTab(tab){
    document.querySelectorAll('.modal-tab').forEach((t,i)=>{
        t.classList.toggle('active',(i===0&&tab==='auto')||(i===1&&tab==='manual'));
    });
    document.getElementById('mTabAuto').classList.toggle('active', tab==='auto');
    document.getElementById('mTabManual').classList.toggle('active', tab==='manual');
}

// Auto GPS capture
function captureModalGPS(){
    const msg     = document.getElementById('modalMsg');
    const btn     = document.getElementById('gpsBtn');
    const preview = document.getElementById('gpsPreview');
    msg.textContent = '📡 Getting GPS...';
    btn.disabled = true;
    preview.style.display = 'none';

    navigator.geolocation.getCurrentPosition(
        function(pos){
            _gpsLat = pos.coords.latitude;
            _gpsLng = pos.coords.longitude;
            const acc = pos.coords.accuracy;

            document.getElementById('mGLat').textContent = _gpsLat.toFixed(6);
            document.getElementById('mGLng').textContent = _gpsLng.toFixed(6);
            document.getElementById('mGAcc').textContent = acc.toFixed(1) + 'm';
            document.getElementById('mGMapLink').href =
                `https://maps.google.com/?q=${_gpsLat},${_gpsLng}`;

            let badge='', cls='gps-preview';
            if(acc <= 20){
                badge = `<span class="acc-badge acc-good">✓ Good (${acc.toFixed(0)}m)</span>`;
                msg.textContent = '✓ Good accuracy. Verify on map then save.';
            } else if(acc <= 100){
                badge = `<span class="acc-badge acc-warn">⚠ Fair (${acc.toFixed(0)}m)</span>`;
                msg.textContent = '⚠ Fair accuracy. Verify on map before saving.';
            } else {
                badge = `<span class="acc-badge acc-bad">✗ Poor (${acc.toFixed(0)}m) — use Manual tab</span>`;
                cls += ' bad';
                msg.textContent = '❌ Poor GPS. Switch to Manual tab.';
            }
            document.getElementById('mGBadge').innerHTML = badge;
            preview.className = cls;
            preview.style.display = 'block';
            btn.disabled = false;
        },
        function(err){
            msg.textContent = '❌ GPS failed. Use Manual tab.';
            btn.disabled = false;
        },
        { enableHighAccuracy:true, timeout:15000, maximumAge:0 }
    );
}

// Manual coord preview update
document.getElementById('mMLat').addEventListener('input', updateManualPreview);
document.getElementById('mMLng').addEventListener('input', updateManualPreview);
function updateManualPreview(){
    const lat = parseFloat(document.getElementById('mMLat').value);
    const lng = parseFloat(document.getElementById('mMLng').value);
    const p   = document.getElementById('mManualPreview');
    if(!isNaN(lat) && !isNaN(lng)){
        document.getElementById('mMMapLink').href = `https://maps.google.com/?q=${lat},${lng}`;
        p.style.display = 'block';
    } else {
        p.style.display = 'none';
    }
}

// Save location then redirect to QR
function saveModalLocation(source){
    const msg = document.getElementById('modalMsg');
    let lat, lng, radius;

    if(source === 'gps'){
        if(!_gpsLat || !_gpsLng){ msg.textContent='⚠ Capture GPS first.'; return; }
        lat    = _gpsLat;
        lng    = _gpsLng;
        radius = parseInt(document.getElementById('gRadius').value) || 100;
    } else {
        lat    = parseFloat(document.getElementById('mMLat').value);
        lng    = parseFloat(document.getElementById('mMLng').value);
        radius = parseInt(document.getElementById('mRadius').value) || 100;
        if(isNaN(lat)||isNaN(lng)){
            msg.textContent='⚠ Please enter valid latitude and longitude.'; return;
        }
        if(lat<1||lat>7||lng<99||lng>119){
            if(!confirm(`Coordinates (${lat}, ${lng}) look outside Malaysia. Save anyway?`)) return;
        }
    }

    msg.textContent = 'Saving location...';

    fetch('save_location.php',{
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body: 'subject_id=' + encodeURIComponent(_subject_id) +
              '&lat='       + encodeURIComponent(lat) +
              '&lng='       + encodeURIComponent(lng) +
              '&radius='    + encodeURIComponent(radius)
    })
    .then(r => r.text())
    .then(data => {
        msg.textContent = '✅ ' + data + ' Generating QR...';
        setTimeout(()=>{
            closeModal();
            window.location =
                'qr_code_physical.php' +
                '?subject_id=' + encodeURIComponent(_subject_id) +
                '&date='       + encodeURIComponent(_date) +
                '&time='       + encodeURIComponent(_time);
        }, 800);
    })
    .catch(()=>{ msg.textContent='❌ Save failed. Try again.'; });
}
</script>
</head>
<body>
<div class="sidebar">
    <h2>Lecturer Panel</h2>
    <a href="attendance_lecturer.php">Overview</a>
    <a href="subject_lecturer.php">Subject</a>
    <a href="attendance_lecturer.php" class="active">Attendance</a>
    <a href="timetable_lecturer.php">Timetable</a>
</div>

<div class="main">
<div class="top">
    <div>
        <h1>Physical Attendance</h1>
        <p>Search timetable and generate QR code.</p>
    </div>

    <a href="attendance_lecturer.php" class="back-btn">
        ← Back
    </a>

</div>

<div class="box">

    <h2>Search Timetable</h2>

    <div class="line"></div>

    <form method="GET">

        <div class="search-row">

            <input
                type="text"
                name="subject_id"
                placeholder="Subject ID">

            <input
                type="date"
                name="class_date">

            <input
                type="time"
                name="start_time">

            <button
                class="search-btn"
                type="submit"
                name="search">
                 Search
            </button>

        </div>

    </form>
<?php if($result){ ?>

<table>
<tr>
<th>Subject ID</th>
<th>Date</th>
<th>Start</th>
<th>End</th>
<th>QR Code</th>
<th>Edit Replacement</th>
</tr>

<?php
while($row = $result->fetch_assoc()){
?>

<tr>

<td><?= $row['subject_id']; ?></td>
<td><?= $row['class_date']; ?></td>
<td><?= $row['start_time']; ?></td>
<td><?= $row['end_time']; ?></td>

   <td>

                    <button
                    type="button"
                    class="generate"

                    onclick="generateQR(
                    '<?= $row['subject_id']; ?>',
                    '<?= $row['class_date']; ?>',
                    '<?= $row['start_time']; ?>'
                    )">

                        Generate

                    </button>

                </td>

<td>
<form method="POST" style="display:inline;">
<input type="hidden" name="id" value="<?= $row['id']; ?>">

<input type="date" name="new_date" required>
<input type="time" name="new_start" required>
<input type="time" name="new_end" required>

<button class="savebtn" name="update_class">
Save
</button>
</form>
</td>

</tr>

<?php } ?>

</table>

<?php } ?>

</div>
</div>
</body>
</html>