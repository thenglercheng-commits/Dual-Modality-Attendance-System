<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include "connection.php";
date_default_timezone_set("Asia/Kuala_Lumpur");

$subject_id = $_GET['subject_id'] ?? '';
$date       = $_GET['date'] ?? '';
$time       = $_GET['time'] ?? '';
$token      = $_GET['token'] ?? '';

if($subject_id == ''){
    die("
    <h2 style='text-align:center;margin-top:50px'>
    Invalid QR Code</h2>");
}

/* =========================
   TOKEN CHECK (QR expiry)
========================= */
$current_slot = floor(time()/10);
$v1 = md5("secret_salt".$current_slot);
$v2 = md5("secret_salt".($current_slot-1));
$v3 = md5("secret_salt".($current_slot+1));

if($token != $v1 && $token != $v2 && $token != $v3){
    die("<h2 style='text-align:center;margin-top:50px'>
    QR Expired. Scan Again.</h2>");
}

/* =========================
   CLASS CHECK (FIXED)
   USE TODAY DATE (IMPORTANT)
========================= */
$res = $conn->query("
SELECT start_time,end_time
FROM timetable
WHERE subject_id='$subject_id'
AND class_date = CURDATE()
LIMIT 1
");

if($date != '' && $date != date("Y-m-d")){
    die("
    <h2 style='text-align:center;margin-top:50px'>
    This QR code is not for today.
    </h2>
    ");
}

$row = $res->fetch_assoc();

/* =========================
   TIME CHECK (FULL DATETIME)
========================= */
$current_datetime = date("Y-m-d H:i:s");

$today = date("Y-m-d");

$start_datetime = $today . " " . $row['start_time'];
$end_datetime   = $today . " " . $row['end_time'];

$now   = strtotime($current_datetime);
$start = strtotime($start_datetime);
$end   = strtotime($end_datetime);

/* DEBUG (optional remove later) */
// echo "NOW: $current_datetime <br> START: $start_datetime <br> END: $end_datetime"; exit();

if($now < $start || $now > $end){
    echo "<h2 style='text-align:center;margin-top:50px'>
    Attendance only during class time<br>
    Allowed: {$row['start_time']} - {$row['end_time']}
    </h2>";
    exit();
}

/* =========================
   GO CAMERA PAGE
   Set a short-lived session gate so mobile_face.php
   can confirm this visit came from a real QR scan,
   not a bookmarked/forwarded URL.
========================= */
$_SESSION['qr_gate_online_' . $subject_id] = time();

header("Location: mobile_face.php?subject_id=$subject_id&date=$today&time=$time");
exit();
?><?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include "connection.php";
date_default_timezone_set("Asia/Kuala_Lumpur");

$subject_id = $_GET['subject_id'] ?? '';
$date       = $_GET['date'] ?? '';
$time       = $_GET['time'] ?? '';
$token      = $_GET['token'] ?? '';

if($subject_id == ''){
    die("
    <h2 style='text-align:center;margin-top:50px'>
    Invalid QR Code</h2>");
}

/* =========================
   TOKEN CHECK (QR expiry)
========================= */
$current_slot = floor(time()/10);
$v1 = md5("secret_salt".$current_slot);
$v2 = md5("secret_salt".($current_slot-1));
$v3 = md5("secret_salt".($current_slot+1));

if($token != $v1 && $token != $v2 && $token != $v3){
    die("<h2 style='text-align:center;margin-top:50px'>
    QR Expired. Scan Again.</h2>");
}

/* =========================
   CLASS CHECK (FIXED)
   USE TODAY DATE (IMPORTANT)
========================= */
$res = $conn->query("
SELECT start_time,end_time
FROM timetable
WHERE subject_id='$subject_id'
AND class_date = CURDATE()
LIMIT 1
");

if($date != '' && $date != date("Y-m-d")){
    die("
    <h2 style='text-align:center;margin-top:50px'>
    This QR code is not for today.
    </h2>
    ");
}

$row = $res->fetch_assoc();

/* =========================
   TIME CHECK (FULL DATETIME)
========================= */
$current_datetime = date("Y-m-d H:i:s");

$today = date("Y-m-d");

$start_datetime = $today . " " . $row['start_time'];
$end_datetime   = $today . " " . $row['end_time'];

$now   = strtotime($current_datetime);
$start = strtotime($start_datetime);
$end   = strtotime($end_datetime);

/* DEBUG (optional remove later) */
// echo "NOW: $current_datetime <br> START: $start_datetime <br> END: $end_datetime"; exit();

if($now < $start || $now > $end){
    echo "<h2 style='text-align:center;margin-top:50px'>
    Attendance only during class time<br>
    Allowed: {$row['start_time']} - {$row['end_time']}
    </h2>";
    exit();
}

/* =========================
   GO CAMERA PAGE
   Set a short-lived session gate so mobile_face.php
   can confirm this visit came from a real QR scan,
   not a bookmarked/forwarded URL.
========================= */
$_SESSION['qr_gate_online_' . $subject_id] = time();

header("Location: mobile_face.php?subject_id=$subject_id&date=$today&time=$time");
exit();
?>