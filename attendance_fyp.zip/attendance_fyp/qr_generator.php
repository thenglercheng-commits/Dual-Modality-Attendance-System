<?php
include "phpqrcode/qrlib.php";

$subject_id = $_GET['subject_id'] ?? '';
$date       = $_GET['date'] ?? '';
$time       = $_GET['time'] ?? '';
$token      = $_GET['token'] ?? '';

$base_url = "https://spyglass-womankind-prelaunch.ngrok-free.dev";

$link = $base_url . "/attendance_fyp/scan_qr.php?subject_id="
      . urlencode($subject_id)
      . "&date=" . urlencode($date)
      . "&time=" . urlencode($time)
      . "&token=" . urlencode($token);

header("Content-Type: image/png");
QRcode::png($link, false, QR_ECLEVEL_L, 8, 2);
exit;
?>