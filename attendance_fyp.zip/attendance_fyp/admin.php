<?php
session_start();
include "connection.php";

if(!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin'){
    header("Location: login.php");
    exit();
}

/* =========================
   TOTAL STUDENTS
========================= */

$student_total = $conn->query(
"SELECT COUNT(*) AS total FROM students"
)->fetch_assoc()['total'];

/* =========================
   TOTAL LECTURERS
========================= */

$lecturer_total = $conn->query(
"SELECT COUNT(*) AS total FROM lecturers"
)->fetch_assoc()['total'];

/* =========================
   TOTAL SUBJECTS
========================= */

$subject_total = $conn->query(
"SELECT COUNT(*) AS total FROM subjects"
)->fetch_assoc()['total'];

/* =========================
   TODAY ATTENDANCE
========================= */

$today = date("Y-m-d");

$present = $conn->query("
SELECT COUNT(*) AS total
FROM attendance
WHERE attend_date='$today'
AND status='Present'
")->fetch_assoc()['total'];

$total_today = $conn->query("
SELECT COUNT(*) AS total
FROM attendance
WHERE attend_date='$today'
")->fetch_assoc()['total'];

$attendance_rate = ($total_today > 0)
? round(($present / $total_today) * 100)
: 0;

/* =========================
   TOTAL TIMETABLE
========================= */

$timetable_total = $conn->query(
"SELECT COUNT(*) AS total FROM timetable"
)->fetch_assoc()['total'];

$total_records =
$student_total +
$lecturer_total +
$subject_total +
$timetable_total;

?>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Admin Dashboard</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'Poppins',sans-serif;
    display:flex;
    background:#eaf6ff;
}

/* =========================
   SIDEBAR
========================= */

.sidebar{
    width:260px;
    min-height:100vh;
    background:white;
    padding:25px;
    position:fixed;
    left:0;
    top:0;
}

.logo{
    width:55px;
    height:55px;
    background:#2563eb;
    border-radius:18px;
    display:flex;
    align-items:center;
    justify-content:center;
    color:white;
    font-size:24px;
    margin-bottom:20px;
}

.brand{
    font-size:20px;
    font-weight:bold;
    margin-bottom:35px;
}

.menu a{
    display:flex;
    align-items:center;
    gap:12px;
    padding:14px 16px;
    margin-bottom:10px;
    border-radius:12px;
    text-decoration:none;
    color:black;
    transition:0.2s;
    font-size:15px;
}

.menu a:hover,
.menu a.active{
    background:#2563eb;
    color:white;
}

/* =========================
   PROFILE CARD
========================= */

.profile-card{
    position:absolute;
    bottom:25px;
    left:25px;
    right:25px;
    background:#f8fbff;
    border-radius:16px;
    padding:14px;
    display:flex;
    align-items:center;
    gap:12px;
}

.profile-icon{
    width:50px;
    height:50px;
    border-radius:50%;
    background:#2563eb;
    color:white;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:22px;
}

.profile-card h4{
    font-size:15px;
}

.profile-card p{
    color:#64748b;
    font-size:13px;
}

/* =========================
   MAIN
========================= */

.main{
    margin-left:260px;
    padding:35px;
    width:calc(100% - 260px);
}

/* =========================
   TOP SECTION
========================= */

.top{
    background:white;
    border-radius:18px;
    padding:25px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    box-shadow:0 6px 15px rgba(0,0,0,.06);
}

.top h1{
    font-size:24px;
    margin-bottom:10px;
}

.top p{
    color:#64748b;
}

.top-right{
    display:flex;
    align-items:center;
    gap:18px;
}

.hero-icon{
    font-size:60px;
}

.logout-btn{
    background:#2563eb;
    color:white;
    text-decoration:none;
    padding:12px 22px;
    border-radius:12px;
    font-weight:600;
}

.logout-btn:hover{
    background:#1d4ed8;
}

/* =========================
   CARDS
========================= */

.cards{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
    gap:20px;
    margin-top:25px;
}

.card{
    background:white;
    padding:25px;
    border-radius:18px;
    box-shadow:0 6px 15px rgba(0,0,0,.06);
}

.card-top{
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.icon-box{
    width:55px;
    height:55px;
    border-radius:16px;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:24px;
}

.blue-bg{
    background:#dbeafe;
}

.green-bg{
    background:#dcfce7;
}

.purple-bg{
    background:#ede9fe;
}

.orange-bg{
    background:#ffedd5;
}

.card h3{
    color:#64748b;
    margin-top:20px;
    margin-bottom:12px;
    font-size:16px;
}

.card-number{
    font-size:35px;
    font-weight:bold;
    color:#0f172a;
}

.card-info{
    margin-top:10px;
    font-size:14px;
    color:#16a34a;
}

/* =========================
   SECTION
========================= */

.section{
    margin-top:25px;
    background:white;
    padding:25px;
    border-radius:18px;
    box-shadow:0 6px 15px rgba(0,0,0,.06);
}

.section h2{
    margin-bottom:10px;
}

.section p{
    color:#64748b;
}

/* =========================
   SUMMARY
========================= */

.summary{
    margin-top:25px;
    background:white;
    padding:25px;
    border-radius:18px;
    box-shadow:0 6px 15px rgba(0,0,0,.06);
}

.summary h3{
    margin-bottom:20px;
}

.summary-grid{
    display:grid;
    grid-template-columns:250px 1fr;
    gap:40px;
    align-items:center;
}

.circle{
    width:220px;
    height:220px;
    border-radius:50%;
    margin:auto;
    background:conic-gradient(
        #2563eb 0deg 120deg,
        #22c55e 120deg 200deg,
        #8b5cf6 200deg 280deg,
        #f59e0b 280deg 360deg
    );
    display:flex;
    align-items:center;
    justify-content:center;
}

.circle-inner{
    width:160px;
    height:160px;
    background:white;
    border-radius:50%;
    display:flex;
    flex-direction:column;
    align-items:center;
    justify-content:center;
}

.circle-inner h2{
    font-size:40px;
}

.circle-inner p{
    color:#64748b;
}

.summary-list div{
    display:flex;
    justify-content:space-between;
    margin-bottom:20px;
    padding-bottom:14px;
    border-bottom:1px solid #eee;
}

.summary-list span{
    display:flex;
    align-items:center;
    gap:10px;
}

.dot{
    width:12px;
    height:12px;
    border-radius:50%;
}

.blue{
    background:#2563eb;
}

.green{
    background:#22c55e;
}

.purple{
    background:#8b5cf6;
}

.orange{
    background:#f59e0b;
}

.live{
    margin-top:20px;
    color:#2563eb;
    font-size:14px;
}

/* =========================
   RESPONSIVE
========================= */

@media(max-width:900px){

    .sidebar{
        width:180px;
        padding:20px 15px;
    }

    .main{
        margin-left:180px;
        width:calc(100% - 180px);
        padding:20px;
    }

    .cards{
        grid-template-columns:1fr;
    }

    .top{
        flex-direction:column;
        align-items:flex-start;
        gap:20px;
    }

    .summary-grid{
        grid-template-columns:1fr;
    }

}

</style>

</head>

<body>

<!-- SIDEBAR -->

<div class="sidebar">

    <div class="brand">
        Admin Panel
    </div>

    <div class="menu">

        <a href="admin.php" class="active">
             Overview
        </a>

        <a href="attendance_admin.php">
             Attendance
        </a>

        <a href="student_admin.php">
             Student
        </a>

        <a href="lecturer_admin.php">
             Lecturer
        </a>

        <a href="subject_admin.php">
             Subject
        </a>

        <a href="timetable_admin.php">
             Timetable
        </a>

    </div>
</div>

<!-- MAIN -->

<div class="main">

    <!-- TOP -->

    <div class="top">

        <div>

            <h1>
                Welcome, Admin 
            </h1>

            <p>
                Manage your attendance system here.
            </p>

        </div>

        <div class="top-right">
            <a href="logout.php" class="logout-btn">
                Logout
            </a>

        </div>

    </div>

    <!-- CARDS -->

    <div class="cards">

        <div class="card">

            <div class="card-top">

            </div>

            <h3>Total Students</h3>

            <div class="card-number">
                <?php echo $student_total; ?>
            </div>

        </div>

        <div class="card">

            <div class="card-top">

            </div>

            <h3>Total Lecturers</h3>

            <div class="card-number">
                <?php echo $lecturer_total; ?>
            </div>

        </div>

        <div class="card">

            <div class="card-top">

        
            </div>

            <h3>Total Subjects</h3>

            <div class="card-number">
                <?php echo $subject_total; ?>
            </div>

        </div>

        <div class="card">

            <div class="card-top">


            </div>

            <h3>Today Attendance</h3>

            <div class="card-number">
                <?php echo $attendance_rate; ?>%
            </div>
        </div>

    </div>

    <!-- SUMMARY -->

    <div class="summary">

        <h3>System Summary</h3>

        <div class="summary-grid">

            <div class="circle">

                <div class="circle-inner">

                    <h2>
                        <?php echo $total_records; ?>
                    </h2>

                    <p>Total Records</p>

                </div>

            </div>

            <div class="summary-list">

                <div>

                    <span>
                        <div class="dot blue"></div>
                        Students
                    </span>

                    <strong>
                        <?php echo $student_total; ?>
                    </strong>

                </div>

                <div>

                    <span>
                        <div class="dot green"></div>
                        Lecturers
                    </span>

                    <strong>
                        <?php echo $lecturer_total; ?>
                    </strong>

                </div>

                <div>

                    <span>
                        <div class="dot purple"></div>
                        Subjects
                    </span>

                    <strong>
                        <?php echo $subject_total; ?>
                    </strong>

                </div>

                <div>

                    <span>
                        <div class="dot orange"></div>
                        Timetable
                    </span>

                    <strong>
                        <?php echo $timetable_total; ?>
                    </strong>

                </div>

            </div>

        </div>

        <div class="live">
            ⓘ Data updated in real-time
        </div>

    </div>

</div>

</body>
</html>