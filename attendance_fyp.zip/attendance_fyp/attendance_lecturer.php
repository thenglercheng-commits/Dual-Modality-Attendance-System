<?php
session_start();
include "connection.php";

if(!isset($_SESSION['name']) || $_SESSION['role'] != 'lecturer'){
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Attendance Management</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    background:#f5f8fc;
    display:flex;
}

/* SIDEBAR */

.sidebar{
    width:260px;
    min-height:100vh;
    background:white;
    padding:25px;
    position:fixed;
    left:0;
    top:0;
}

.brand{
    font-size:20px;
    font-weight:bold;
    margin-bottom:35px;
}

.brand h2{
    font-size:20px;
    color:#0f172a;
}

.menu a{
    display:flex;
    align-items:center;
    gap:12px;
    padding:14px 16px;
    margin-bottom:10px;
    border-radius:12px;
    text-decoration:none;
    color:black;
    transition:0.2s;
    font-size:15px;
}

.menu a.active{
    background:#2563eb;
    color:white;
}

/* .menu a:hover{
    background:#eff6ff;
} */

/* MAIN */

.main{
    margin-left:260px;
    width:calc(100% - 260px);
    padding:35px;
}

/* TOP */

.top-card{
    background:white;
    border-radius:25px;
    padding:28px 40px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    box-shadow:0 8px 25px rgba(0,0,0,.05);
}

.top-left{
    display:flex;
    align-items:center;
    gap:25px;
}

.wave{
    width:75px;
    height:75px;
    background:#f1f5f9;
    border-radius:50%;
    display:flex;
    justify-content:center;
    align-items:center;
    font-size:35px;
}

.top-left h1{
    color:#0b1652;
    font-size:28px;
}

.top-left p{
    color:#475569;
    margin-top:8px;
}

.top-right{
    display:flex;
    align-items:center;
    gap:25px;
}

.logout-btn{
    background:#2563eb;
    color:white;
    text-decoration:none;
    padding:12px 22px;
    border-radius:12px;
    font-weight:600;
}

/* CONTENT */

.grid{
    margin-top:25px;
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:25px;
}

.card{
    background:white;
    border-radius:25px;
    padding:35px;
    min-height:600px;
    box-shadow:0 8px 25px rgba(0,0,0,.05);
}

.header{
    display:flex;
    align-items:center;
    gap:25px;
    margin-bottom:25px;
}

.card h2{
    color:#0b1652;
    margin-bottom:5px;
}

.line{
    width:45px;
    height:5px;
    background:#2563eb;
    border-radius:20px;
    margin-top:10px;
}

.desc{
    color:#475569;
    font-size:16px;
    margin-bottom:30px;
}

/* ACTION BOX */

.action-box{
    background:#f8fafc;
    border:1px solid #e2e8f0;
    border-radius:20px;
    padding:25px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    text-decoration:none;
    margin-bottom:18px;
}

.action-left{
    display:flex;
    gap:20px;
    align-items:center;
}

.action-icon{
    width:60px;
    height:60px;
    border-radius:50%;
    background:#2563eb;
    color:white;
    display:flex;
    justify-content:center;
    align-items:center;
    font-size:26px;
}

.action-title{
    font-size:18px;
    font-weight:600;
    color:#0f172a;
}

.action-sub{
    color:#475569;
    margin-top:5px;
}

.arrow{
    font-size:32px;
    color:#2563eb;
}

</style>
</head>

<body>

<!-- SIDEBAR -->

<div class="sidebar">

    <div class="brand">
        <h2>Lecturer Panel</h2>
    </div>

    <div class="menu">
        <a href="lecturer.php">Overview</a>
        <a href="subject_lecturer.php">Subject</a>
        <a href="attendance_lecturer.php" class="active">Attendance</a>
        <a href="timetable_lecturer.php">Timetable</a>
    </div>

</div>

<!-- MAIN -->

<div class="main">

    <div class="top-card">

        <div class="top-left">

            <div>
                <h1>Attendance Management</h1>
                <p>Take and view attendance for your classes.</p>
            </div>

        </div>

        <div class="top-right">

            <a href="logout.php" class="logout-btn">Logout</a>
        </div>

    </div>

    <div class="grid">

        <!-- TAKE ATTENDANCE -->

        <div class="card">

            <div class="header">
                <div>
                    <h2>Take Attendance</h2>
                    <div class="line"></div>
                </div>

            </div>

            <p class="desc">
                Mark and record attendance for your students.
            </p>

            <a href="online_attendance.php" class="action-box">

                <div class="action-left">
                    <div>
                        <div class="action-title">
                            Online Attendance
                        </div>

                        <div class="action-sub">
                            Take attendance online.
                        </div>
                    </div>

                </div>

                <div class="arrow">›</div>

            </a>

            <a href="physical_attendance.php" class="action-box">

                <div class="action-left">

                    <div>
                        <div class="action-title">
                            Physical Attendance
                        </div>

                        <div class="action-sub">
                            Record attendance in class.
                        </div>
                    </div>

                </div>

                <div class="arrow">›</div>

            </a>

        </div>

        <!-- VIEW ATTENDANCE -->

        <div class="card">

            <div class="header">

                <div>
                    <h2>View Attendance</h2>
                    <div class="line"></div>
                </div>

            </div>

            <p class="desc">
                View and manage your attendance records.
            </p>

            <a href="view_attendance.php" class="action-box">

                <div class="action-left">

                    <div>
                        <div class="action-title">
                            Open Attendance Records
                        </div>

                        <div class="action-sub">
                            View attendance history and details.
                        </div>
                    </div>

                </div>

                <div class="arrow">›</div>

            </a>

        </div>

    </div>

</div>

</body>
</html>