<?php
include "connection.php";
$subject_id = $_GET['subject_id'] ?? 'TIA6213';

$existing = null;
$res = $conn->query("SELECT latitude, longitude, radius FROM classroom_location WHERE subject_id='$subject_id' LIMIT 1");
if($res && $res->num_rows > 0){
    $existing = $res->fetch_assoc();
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Start Attendance</title>
<style>
*{ box-sizing:border-box; }
body{ font-family:Arial; background:#f2f7ff; display:flex;
      justify-content:center; align-items:center; min-height:100vh; margin:0; padding:16px; }
.box{ background:white; padding:28px; border-radius:15px; width:100%; max-width:400px;
      text-align:center; box-shadow:0 4px 15px rgba(0,0,0,0.1); }
h2{ margin:0 0 6px; }
.subtitle{ color:#6b7280; font-size:13px; margin-bottom:20px; }

/* Tab switcher */
.tabs{ display:flex; border-radius:10px; overflow:hidden;
       border:1px solid #d1d5db; margin-bottom:20px; }
.tab{ flex:1; padding:10px; font-size:14px; font-weight:bold; cursor:pointer;
      background:#f9fafb; color:#6b7280; border:none; }
.tab.active{ background:#2563eb; color:white; }

/* Auto GPS section */
.section{ display:none; }
.section.active{ display:block; }

/* Manual entry */
.field{ margin-bottom:14px; text-align:left; }
.field label{ display:block; font-size:13px; font-weight:bold;
              color:#374151; margin-bottom:4px; }
.field input{ width:100%; padding:10px 12px; border:1px solid #d1d5db;
              border-radius:8px; font-size:15px; }
.field input:focus{ outline:none; border-color:#2563eb; }
.field .hint{ font-size:11px; color:#9ca3af; margin-top:3px; }

.map-btn{ display:block; width:100%; padding:10px; margin-bottom:14px;
          background:#f0fdf4; border:1px solid #16a34a; border-radius:8px;
          color:#15803d; font-size:13px; font-weight:bold; cursor:pointer;
          text-decoration:none; }

button.primary{ padding:13px; border:none; background:#2563eb; color:white;
        border-radius:8px; cursor:pointer; width:100%; font-size:16px;
        font-weight:bold; margin-top:4px; }
button.primary:disabled{ background:#93b4f5; cursor:not-allowed; }
button.retry{ padding:9px; border:none; background:#6b7280; color:white;
              border-radius:8px; cursor:pointer; width:100%; font-size:13px;
              margin-top:8px; }

.coords-preview{ background:#f0fdf4; border:1px solid #16a34a;
                 border-radius:8px; padding:12px; margin-bottom:14px;
                 font-size:13px; text-align:left; display:none; }
.coords-preview.bad{ background:#fef2f2; border-color:#dc2626; }
.row{ display:flex; justify-content:space-between; margin-bottom:3px; }
.lbl{ color:#6b7280; }
.val{ font-weight:bold; font-family:monospace; }
.badge{ display:inline-block; padding:2px 8px; border-radius:10px;
        font-size:11px; font-weight:bold; margin-top:4px; }
.good{ background:#dcfce7; color:#15803d; }
.warn{ background:#fef9c3; color:#a16207; }
.bad { background:#fee2e2; color:#991b1b; }

.existing-box{ margin-bottom:16px; padding:10px 12px; background:#eff6ff;
               border:1px solid #93c5fd; border-radius:8px; font-size:12px;
               text-align:left; color:#1e40af; }

#msg{ margin-top:12px; font-weight:bold; font-size:14px; min-height:18px; }

.radius-row{ display:flex; align-items:center; gap:8px; margin-bottom:14px; text-align:left; }
.radius-row label{ font-size:13px; color:#374151; white-space:nowrap; font-weight:bold; }
.radius-row input{ width:90px; padding:8px; border:1px solid #d1d5db;
                   border-radius:6px; font-size:14px; }
</style>
</head>
<body>
<div class="box">
    <h2>📍 Start Attendance</h2>
    <p class="subtitle">Set classroom location for <strong><?= htmlspecialchars($subject_id) ?></strong></p>

    <?php if($existing): ?>
    <div class="existing-box">
        📌 Last saved: <?= $existing['latitude'] ?>, <?= $existing['longitude'] ?>
        (radius <?= $existing['radius'] ?>m)
        — <a href="https://maps.google.com/?q=<?= $existing['latitude'] ?>,<?= $existing['longitude'] ?>"
             target="_blank" style="color:#2563eb">view map ↗</a>
    </div>
    <?php endif; ?>

    <!-- Tab switcher -->
    <div class="tabs">
        <button class="tab active" onclick="switchTab('auto')">📡 Auto GPS</button>
        <button class="tab"        onclick="switchTab('manual')">✏️ Manual Entry</button>
    </div>

    <!-- AUTO GPS TAB -->
    <div class="section active" id="tabAuto">
        <button class="primary" id="captureBtn" onclick="captureGPS()">
            📡 Capture My Location
        </button>

        <div class="coords-preview" id="gpsPreview">
            <div class="row"><span class="lbl">Latitude:</span>  <span class="val" id="gLat">—</span></div>
            <div class="row"><span class="lbl">Longitude:</span> <span class="val" id="gLng">—</span></div>
            <div class="row"><span class="lbl">Accuracy:</span>  <span class="val" id="gAcc">—</span></div>
            <div id="gBadge"></div>
            <a id="gMapLink" class="map-btn" target="_blank" style="margin-top:10px">
                🗺 Verify on Google Maps ↗
            </a>
            <div class="radius-row">
                <label>Radius:</label>
                <input type="number" id="gRadius" value="100" min="20" max="500">
                <span style="font-size:13px;color:#6b7280">meters</span>
            </div>
            <button class="primary" onclick="saveCoords('gps')">✅ Save This Location</button>
            <button class="retry"   onclick="captureGPS()">🔄 Retry GPS</button>
        </div>
    </div>

    <!-- MANUAL ENTRY TAB -->
    <div class="section" id="tabManual">

        <a href="https://maps.google.com" target="_blank" class="map-btn">
            🗺 Open Google Maps to find coordinates ↗
        </a>
        <p style="font-size:12px;color:#6b7280;margin:0 0 14px;text-align:left">
            On Google Maps: long-press your classroom → coordinates appear at the bottom. Copy them here.
        </p>

        <div class="field">
            <label>Latitude</label>
            <input type="number" id="mLat" placeholder="e.g. 3.056789"
                   step="0.000001" min="-90" max="90">
            <div class="hint">Positive = North (Malaysia is ~1 to 7)</div>
        </div>

        <div class="field">
            <label>Longitude</label>
            <input type="number" id="mLng" placeholder="e.g. 101.593456"
                   step="0.000001" min="-180" max="180">
            <div class="hint">Positive = East (Malaysia is ~99 to 119)</div>
        </div>

        <div class="radius-row">
            <label>Radius:</label>
            <input type="number" id="mRadius" value="100" min="20" max="500">
            <span style="font-size:13px;color:#6b7280">meters</span>
        </div>

        <div id="manualPreview" style="display:none">
            <a id="mMapLink" class="map-btn" target="_blank">
                🗺 Verify entered coordinates on map ↗
            </a>
        </div>

        <button class="primary" onclick="saveCoords('manual')">✅ Save Location</button>
    </div>

    <div id="msg"></div>
</div>

<script>
let gpsLat = null, gpsLng = null;

// ── Tab switch ────────────────────────────────────────────────────────────────
function switchTab(tab){
    document.querySelectorAll('.tab').forEach((t,i) => {
        t.classList.toggle('active', (i === 0 && tab==='auto') || (i===1 && tab==='manual'));
    });
    document.getElementById('tabAuto').classList.toggle('active', tab==='auto');
    document.getElementById('tabManual').classList.toggle('active', tab==='manual');
}

// ── Auto GPS ──────────────────────────────────────────────────────────────────
function captureGPS(){
    const msg = document.getElementById('msg');
    const btn = document.getElementById('captureBtn');
    const preview = document.getElementById('gpsPreview');
    msg.innerHTML = '📡 Getting GPS...';
    btn.disabled = true;
    preview.style.display = 'none';

    navigator.geolocation.getCurrentPosition(
        function(pos){
            gpsLat = pos.coords.latitude;
            gpsLng = pos.coords.longitude;
            const acc = pos.coords.accuracy;

            document.getElementById('gLat').textContent = gpsLat.toFixed(6);
            document.getElementById('gLng').textContent = gpsLng.toFixed(6);
            document.getElementById('gAcc').textContent = acc.toFixed(1) + 'm';
            document.getElementById('gMapLink').href =
                `https://maps.google.com/?q=${gpsLat},${gpsLng}`;

            let badge = '', cls = 'coords-preview';
            if(acc <= 20){
                badge = `<span class="badge good">✓ Good (${acc.toFixed(0)}m)</span>`;
                msg.innerHTML = '✓ Good accuracy. Verify on map then save.';
            } else if(acc <= 100){
                badge = `<span class="badge warn">⚠ Fair (${acc.toFixed(0)}m)</span>`;
                msg.innerHTML = '⚠ Fair accuracy. Verify on map before saving.';
            } else {
                badge = `<span class="badge bad">✗ Poor (${acc.toFixed(0)}m) — use Manual Entry</span>`;
                cls += ' bad';
                msg.innerHTML = '❌ Poor GPS accuracy. Switch to Manual Entry tab.';
            }
            document.getElementById('gBadge').innerHTML = badge;
            preview.className = cls;
            preview.style.display = 'block';
            btn.disabled = false;
        },
        function(err){
            msg.innerHTML = '❌ GPS failed. Use Manual Entry tab instead.';
            btn.disabled = false;
        },
        { enableHighAccuracy:true, timeout:15000, maximumAge:0 }
    );
}

// ── Manual preview update ─────────────────────────────────────────────────────
document.getElementById('mLat').addEventListener('input', updateManualPreview);
document.getElementById('mLng').addEventListener('input', updateManualPreview);
function updateManualPreview(){
    const lat = parseFloat(document.getElementById('mLat').value);
    const lng = parseFloat(document.getElementById('mLng').value);
    const preview = document.getElementById('manualPreview');
    if(!isNaN(lat) && !isNaN(lng)){
        document.getElementById('mMapLink').href =
            `https://maps.google.com/?q=${lat},${lng}`;
        preview.style.display = 'block';
    } else {
        preview.style.display = 'none';
    }
}

// ── Save ──────────────────────────────────────────────────────────────────────
function saveCoords(source){
    const msg = document.getElementById('msg');
    let lat, lng, radius;

    if(source === 'gps'){
        if(!gpsLat || !gpsLng){
            msg.innerHTML = '⚠ Capture GPS first.'; return;
        }
        lat    = gpsLat;
        lng    = gpsLng;
        radius = parseInt(document.getElementById('gRadius').value) || 100;
    } else {
        lat    = parseFloat(document.getElementById('mLat').value);
        lng    = parseFloat(document.getElementById('mLng').value);
        radius = parseInt(document.getElementById('mRadius').value) || 100;
        if(isNaN(lat) || isNaN(lng)){
            msg.innerHTML = '⚠ Please enter valid latitude and longitude.'; return;
        }
        if(lat < 1 || lat > 7 || lng < 99 || lng > 119){
            if(!confirm(`Coordinates (${lat}, ${lng}) look outside Malaysia. Save anyway?`)) return;
        }
    }

    msg.innerHTML = 'Saving...';
    fetch('save_location.php', {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: `subject_id=<?php echo $subject_id; ?>&lat=${lat}&lng=${lng}&radius=${radius}`
    })
    .then(r => r.text())
    .then(data => {
        msg.innerHTML = '✅ ' + data;
        setTimeout(() => {
            window.location = 'generate_qr.php?subject_id=<?php echo $subject_id; ?>';
        }, 1500);
    })
    .catch(() => { msg.innerHTML = 'Save failed. Try again.'; });
}
</script>
</body>
</html>