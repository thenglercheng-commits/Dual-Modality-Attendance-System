<?php
session_start();
include "connection.php";

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}

$id = $_SESSION['user_id'];

/* Get student data */
$sql = "
SELECT users.name, students.student_id
FROM users
JOIN students ON users.id = students.id
WHERE users.id = '$id'
";

$result = $conn->query($sql);
$row = $result->fetch_assoc();

$student_id = $row['student_id'];
$name       = $row['name'];

/* Run Python */
$cmd = "python register_face.py \"$student_id\" \"$name\" 2>&1";
$output = shell_exec($cmd);
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Face Registration</title>
<style>
body{
    font-family:Arial;
    background:#eaf6ff;
    padding:40px;
}
.box{
    max-width:700px;
    margin:auto;
    background:white;
    padding:30px;
    border-radius:20px;
}
pre{
    background:#111827;
    color:#22c55e;
    padding:20px;
    border-radius:12px;
    overflow:auto;
}
a{
    display:inline-block;
    margin-top:20px;
    background:#2563eb;
    color:white;
    text-decoration:none;
    padding:12px 18px;
    border-radius:10px;
}
</style>
</head>
<body>

<div class="box">
    <h1>Face Registration Result</h1>

    <p><b>Student:</b> <?php echo $name; ?></p>
    <p><b>ID:</b> <?php echo $student_id; ?></p>

    <pre><?php echo $output; ?></pre>

    <a href="profile_student.php">Back Profile</a>
</div>

</body>
</html>