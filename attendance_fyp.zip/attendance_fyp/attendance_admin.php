<?php
session_start();
include "connection.php";

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}

/* =========================
   FILTERS
========================= */

$student = $_GET['student'] ?? '';
$subject = $_GET['subject'] ?? '';
$date    = $_GET['date'] ?? '';

/* =========================
   STATISTICS
========================= */

$total_records = $conn->query("
SELECT COUNT(*) AS total
FROM attendance
")->fetch_assoc()['total'];

$total_students = $conn->query("
SELECT COUNT(DISTINCT student_id) AS total
FROM attendance
")->fetch_assoc()['total'];

$total_subjects = $conn->query("
SELECT COUNT(DISTINCT subject_id) AS total
FROM attendance
")->fetch_assoc()['total'];

$today = date("Y-m-d");

$today_present = $conn->query("
SELECT COUNT(*) AS total
FROM attendance
WHERE attend_date='$today'
AND status='Present'
")->fetch_assoc()['total'];

$today_total = $conn->query("
SELECT COUNT(*) AS total
FROM attendance
WHERE attend_date='$today'
")->fetch_assoc()['total'];

$attendance_rate = ($today_total > 0)
? round(($today_present / $today_total) * 100)
: 0;

/* =========================
   QUERY
========================= */

$sql = "
SELECT 
    attendance.id,
    attendance.student_id AS student_no,
    users.name,
    attendance.subject_id,
    subjects.subject_name,
    attendance.status,
    attendance.mode,
    attendance.attend_date,
    attendance.attend_time

FROM attendance

LEFT JOIN students
ON attendance.student_id = students.student_id

LEFT JOIN users
ON students.id = users.id

LEFT JOIN subjects
ON attendance.subject_id = subjects.subject_id

WHERE 1
";

/* FILTERS */

if($student != ''){
    $sql .= "
    AND (
        attendance.student_id LIKE '%$student%'
        OR users.name LIKE '%$student%'
    )";
}

if($subject != ''){
    $sql .= "
    AND (
        attendance.subject_id LIKE '%$subject%'
        OR subjects.subject_name LIKE '%$subject%'
    )";
}

if($date != ''){
    $sql .= "
    AND attendance.attend_date='$date'
    ";
}

/* ORDER */

$sql .= " ORDER BY attendance.id DESC";

$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Attendance Management</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'Poppins',sans-serif;
    background:#eef5ff;
    display:flex;
}

/* =========================
   SIDEBAR
========================= */

.sidebar{
    width:260px;
    min-height:100vh;
    background:white;
    padding:25px;
    position:fixed;
    left:0;
    top:0;
}

.logo{
    width:60px;
    height:60px;
    border-radius:18px;
    background:#2563eb;
    display:flex;
    align-items:center;
    justify-content:center;
    color:white;
    font-size:28px;
    margin-bottom:20px;
}

.brand{
    font-size:20px;
    font-weight:700;
    margin-bottom:35px;
}

.menu a{
    display:flex;
    align-items:center;
    gap:12px;
    padding:14px 16px;
    margin-bottom:10px;
    border-radius:14px;
    text-decoration:none;
    color:#1e293b;
    font-size:15px;
    transition:.2s;
}

.menu a:hover,
.menu a.active{
    background:#2563eb;
    color:white;
}

.profile-card{
    position:absolute;
    bottom:25px;
    left:25px;
    right:25px;
    background:#f8fbff;
    border-radius:16px;
    padding:14px;
    display:flex;
    align-items:center;
    gap:12px;
}

.profile-icon{
    width:50px;
    height:50px;
    border-radius:50%;
    background:#2563eb;
    color:white;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:22px;
}

/* =========================
   MAIN
========================= */

.main{
    margin-left:260px;
    width:calc(100% - 260px);
    padding:28px;
}

/* =========================
   TOP
========================= */

.top{
    background:white;
    border-radius:24px;
    padding:28px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:22px;
    box-shadow:0 8px 25px rgba(0,0,0,.05);
}

.top h1{
    font-size:24px;
    margin-bottom:8px;
}

.top p{
    color:#64748b;
}

.logout-btn{
    background:#2563eb;
    color:white;
    text-decoration:none;
    padding:12px 22px;
    border-radius:14px;
    font-weight:600;
}


/* =========================
   TABLE SECTION
========================= */

.table-section{
    background:white;
    border-radius:24px;
    padding:24px;
    box-shadow:0 8px 25px rgba(0,0,0,.05);
}

.table-section h2{
    margin-bottom:8px;
}

.table-section p{
    color:#64748b;
    margin-bottom:24px;
}

/* =========================
   FILTER
========================= */

.filter-bar{
    display:flex;
    gap:14px;
    flex-wrap:wrap;
    margin-bottom:24px;
}

.filter-bar input{
    padding:14px 16px;
    border:1px solid #dbe2ea;
    border-radius:14px;
    min-width:220px;
    font-family:'Poppins';
}

.filter-bar button{
    padding:14px 24px;
    border:none;
    border-radius:14px;
    font-weight:600;
    cursor:pointer;
    font-family:'Poppins';
}

.search-btn{
    background:#2563eb;
    color:white;
}

.reset-btn{
    background:#e2e8f0;
}

/* =========================
   TABLE
========================= */

.table-wrapper{
    overflow-x:auto;
}

table{
    width:100%;
    border-collapse:collapse;
}

thead{
    background:#2563eb;
    color:white;
}

thead th{
    padding:18px;
    font-size:14px;
}

thead th:first-child{
    border-top-left-radius:16px;
}

thead th:last-child{
    border-top-right-radius:16px;
}

tbody td{
    padding:18px;
    border-bottom:1px solid #eef2f7;
    text-align:center;
    font-size:14px;
}

tbody tr:hover{
    background:#f8fbff;
}

/* STATUS */

.status{
    padding:6px 14px;
    border-radius:30px;
    font-size:13px;
    font-weight:600;
}

.present{
    background:#dcfce7;
    color:#15803d;
}

.absent{
    background:#fee2e2;
    color:#dc2626;
}

/* MODE */

.mode{
    padding:6px 14px;
    border-radius:30px;
    font-size:13px;
    font-weight:600;
}

.online{
    background:#dbeafe;
    color:#2563eb;
}

.physical{
    background:#ede9fe;
    color:#7c3aed;
}

</style>

</head>

<body>

<!-- SIDEBAR -->

<div class="sidebar">
    <div class="brand">
        Admin Panel
    </div>

    <div class="menu">

        <a href="admin.php">
             Overview
        </a>

        <a href="attendance_admin.php" class="active">
             Attendance
        </a>

        <a href="student_admin.php">
             Student
        </a>

        <a href="lecturer_admin.php">
             Lecturer
        </a>

        <a href="subject_admin.php">
             Subject
        </a>

        <a href="timetable_admin.php">
             Timetable
        </a>

    </div>

</div>

<!-- MAIN -->

<div class="main">

    <!-- TOP -->

    <div class="top">

        <div>
            <h1>Attendance Management</h1>
            <p>Search and manage attendance records.</p>
        </div>

        <a href="logout.php" class="logout-btn">
            Logout
        </a>

    </div>

    <!-- TABLE SECTION -->

    <div class="table-section">

        <h2>Attendance Records</h2>

        <p>
            Search and monitor attendance records here.
        </p>

        <!-- FILTER -->

        <form method="GET">

            <div class="filter-bar">

                <input
                type="text"
                name="student"
                placeholder="Student ID / Name"
                value="<?php echo $student; ?>">

                <input
                type="text"
                name="subject"
                placeholder="Subject Code"
                value="<?php echo $subject; ?>">

                <input
                type="date"
                name="date"
                value="<?php echo $date; ?>">

                <button type="submit" class="search-btn">
                    Search
                </button>

                <button
                type="button"
                class="reset-btn"
                onclick="window.location='attendance_admin.php'">
                    Reset
                </button>

            </div>

        </form>

        <!-- TABLE -->

        <div class="table-wrapper">

            <table>

                <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Name</th>
                    <th>Subject ID</th>
                    <th>Subject Name</th>
                    <th>Status</th>
                    <th>Mode</th>
                    <th>Date</th>
                    <th>Time</th>
                </tr>
                </thead>

                <tbody>

                <?php if($result && $result->num_rows > 0){ ?>

                    <?php while($row = $result->fetch_assoc()){ ?>

                    <tr>

                        <td>
                            <?php echo $row['student_no']; ?>
                        </td>

                        <td>
                            <?php echo $row['name']; ?>
                        </td>

                        <td>
                            <?php echo $row['subject_id']; ?>
                        </td>

                        <td>
                            <?php echo $row['subject_name']; ?>
                        </td>

                        <td>
                            <span class="status present">
                                <?php echo $row['status']; ?>
                            </span>
                        </td>

                        <td>

                            <?php if($row['mode'] == 'Online'){ ?>

                                <span class="mode online">
                                    Online
                                </span>

                            <?php } else { ?>

                                <span class="mode physical">
                                    Physical
                                </span>

                            <?php } ?>

                        </td>

                        <td>
                            <?php echo $row['attend_date']; ?>
                        </td>

                        <td>
                            <?php echo $row['attend_time']; ?>
                        </td>

                    </tr>

                    <?php } ?>

                <?php } else { ?>

                    <tr>

                        <td colspan="8">
                            No attendance record found.
                        </td>

                    </tr>

                <?php } ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

</body>
</html>