<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include "connection.php";
date_default_timezone_set("Asia/Kuala_Lumpur");

$subject_id = $_GET['subject_id'] ?? '';
$date = $_GET['date'] ?? date("Y-m-d");
$time = $_GET['time'] ?? '';

if($subject_id == ''){
    die("Invalid QR Code");
}

$res = $conn->query("
SELECT start_time, end_time
FROM timetable
WHERE subject_id='$subject_id'
AND class_date = CURDATE()
LIMIT 1
");

if(!$res || $res->num_rows == 0){
    die("No class found for today.");
}

$row = $res->fetch_assoc();
$today = date("Y-m-d");
$now   = strtotime(date("Y-m-d H:i:s"));
$start = strtotime($today . " " . $row['start_time']);
$end   = strtotime($today . " " . $row['end_time']);

if($now < $start || $now > $end){
    echo "<h2 style='text-align:center;margin-top:50px;font-family:Arial'>
    QR Code Expired<br>Attendance only allowed during class time<br>
    Valid: {$row['start_time']} - {$row['end_time']}
    </h2>";
    exit();
}

/* =========================
   QR SCAN GATE
   This page must only be reached via scan_qr.php, which sets
   this session flag after validating the rotating token. A
   bookmarked or forwarded URL will not have this flag set in
   the visitor's own session, or it will be too old.
========================= */
$gate_key    = 'qr_gate_online_' . $subject_id;
$gate_time   = $_SESSION[$gate_key] ?? 0;
$GATE_WINDOW = 30; // 30 seconds — matches the QR token's own validity window.
                   // The gate is only checked at page load; the liveness
                   // challenge itself can take as long as needed afterward.

if ((time() - $gate_time) > $GATE_WINDOW) {
    echo "<h2 style='text-align:center;margin-top:50px;font-family:Arial'>
    Please scan the QR code to access this page.
    </h2>";
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Face Attendance</title>
<style>
*{ box-sizing:border-box; }
body{
    margin:0; font-family:Arial;
    background:#eaf6ff;
    display:flex; justify-content:center; align-items:center; min-height:100vh;
}
.box{
    background:white; width:92%; max-width:420px;
    padding:22px; border-radius:20px; text-align:center;
    box-shadow:0 4px 20px rgba(0,0,0,0.12);
}
h2{ margin:0 0 10px; font-size:20px; }
.video-wrap{ position:relative; width:100%; }
video{ width:100%; border-radius:12px; background:#000; display:block; }
canvas{ display:none; }

/* blink overlay on top of video */
#blinkOverlay{
    position:absolute; top:8px; left:50%; transform:translateX(-50%);
    background:rgba(0,0,0,0.55); color:#fff;
    padding:6px 14px; border-radius:20px;
    font-size:13px; font-weight:bold;
    pointer-events:none; white-space:nowrap;
}
#blinkOverlay.done{
    background:rgba(22,163,74,0.85);
}

/* challenge box */
#challengeBox{
    margin-top:12px; padding:12px 16px;
    background:#fffbeb; border:2px solid #f59e0b;
    border-radius:12px; font-size:16px; font-weight:bold;
    display:block;
}
#challengeBox.done{
    background:#f0fdf4; border-color:#16a34a; color:#15803d;
}

button{
    margin-top:14px; padding:13px 22px; border:none;
    border-radius:10px; background:#2563eb; color:white;
    font-size:16px; cursor:pointer; width:100%;
}
button:disabled{ background:#93b4f5; cursor:not-allowed; }
#msg{ margin-top:13px; font-weight:bold; font-size:15px; min-height:22px; }

.progress-container{
    margin-top:12px; width:100%; background:#f0f0f0;
    border-radius:10px; padding:3px; display:none;
}
.progress-bar{
    width:0%; height:22px;
    background:linear-gradient(90deg,#2563eb,#16a34a);
    border-radius:8px; transition:width 0.3s ease;
    position:relative; overflow:hidden;
}
.progress-text{
    position:absolute; top:50%; left:50%;
    transform:translate(-50%,-50%);
    color:white; font-size:12px; font-weight:bold;
}
</style>
</head>
<body>
<div class="box">
    <h2>Online Face Attendance</h2>

    <div class="video-wrap">
        <video id="video" autoplay playsinline muted></video>
        <div id="blinkOverlay">Waiting...</div>
    </div>
    <canvas id="canvas"></canvas>

    <!-- Challenge instruction -->
    <div id="challengeBox">
        Loading challenge...
    </div>

    <!-- Progress dots for 2-step challenge -->
    <div id="stepIndicator" style="margin-top:8px;font-size:13px;color:#888">
        Step <span id="stepNum">1</span> of 2
    </div>

    <button id="verifyBtn" onclick="verifyFace()" disabled>
        Complete challenge first...
    </button>
    <div id="msg">Opening camera...</div>

    <div class="progress-container" id="progressContainer">
        <div class="progress-bar" id="progressBar">
            <span class="progress-text" id="progressText">0%</span>
        </div>
    </div>
</div>

<!-- MediaPipe FaceMesh -->
<script src="https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/face_mesh.js" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js" crossorigin="anonymous"></script>

<script>
const video        = document.getElementById("video");
const canvas       = document.getElementById("canvas");
const ctx          = canvas.getContext("2d");
const msg          = document.getElementById("msg");
const verifyBtn    = document.getElementById("verifyBtn");
const challengeBox = document.getElementById("challengeBox");
const blinkOverlay = document.getElementById("blinkOverlay");

// ─── Landmark indices ─────────────────────────────────────────────────────────
const L_TOP=159,L_BOT=145,L_LEFT=33, L_RIGHT=133;   // left eye
const R_TOP=386,R_BOT=374,R_LEFT=362,R_RIGHT=263;   // right eye
const M_TOP=13, M_BOT=14, M_LEFT=78, M_RIGHT=308;   // mouth
const NOSE_TIP=4, FACE_LEFT=234, FACE_RIGHT=454;     // head turn

// ─── Challenge setup ──────────────────────────────────────────────────────────
const CHALLENGES = {
    BLINK: {
        label: "👁  Blink once",
        instruction: "👁 Please <strong>blink once</strong>"
    },
    OPEN_MOUTH: {
        label: "😮  Open your mouth wide",
        instruction: "😮 Please <strong>open your mouth wide</strong>"
    },
    TURN_LEFT: {
        label: "⬅️  Turn your head LEFT",
        instruction: "⬅️ Please <strong>turn your head to the LEFT</strong>"
    },
    TURN_RIGHT: {
        label: "➡️  Turn your head RIGHT",
        instruction: "➡️ Please <strong>turn your head to the RIGHT</strong>"
    }
};

// Pick 2 random challenges from 4 — 1/12 chance of guessing correctly
function pickChallenges(){
    const keys = Object.keys(CHALLENGES).sort(()=>Math.random()-0.5);
    return keys.slice(0,2);
}

let challenges      = [];   // e.g. ["TURN_LEFT","BLINK"]
let currentStep     = 0;    // 0 or 1
let allDone         = false;

// Frame captured at the EXACT moment the live challenge completes.
// verifyFace() sends THIS frame, not a new capture at click time,
// so a photo cannot be swapped in after the liveness check passes.
let capturedImage   = null;

// ─── Calibration state ────────────────────────────────────────────────────────
let earSamples    = [], earBaseline  = null, baselineReady = false;
let marSamples    = [], marBaseline  = null;
let noseSamples   = [], noseBaseline = null;
const BASELINE_FRAMES = 35;

// Per-challenge detection state
let actionFrameCount = 0;
const MIN_ACTION_FRAMES = 1;
const MAX_ACTION_FRAMES = 25;

// ─── Geometry helpers ─────────────────────────────────────────────────────────
function dist(a,b){ return Math.hypot(a.x-b.x, a.y-b.y); }

function getEAR(lm){
    const l = (dist(lm[L_TOP],lm[L_BOT]))/(dist(lm[L_LEFT],lm[L_RIGHT])+1e-6);
    const r = (dist(lm[R_TOP],lm[R_BOT]))/(dist(lm[R_LEFT],lm[R_RIGHT])+1e-6);
    return (l+r)/2;
}

function getMAR(lm){
    // Mouth Aspect Ratio — vertical / horizontal
    return dist(lm[M_TOP],lm[M_BOT]) / (dist(lm[M_LEFT],lm[M_RIGHT])+1e-6);
}

function getNoseX(lm){
    // Nose tip x relative to face width (0=left edge, 1=right edge)
    const faceW = dist(lm[FACE_LEFT], lm[FACE_RIGHT]);
    if(faceW < 1e-6) return 0.5;
    return (lm[NOSE_TIP].x - lm[FACE_LEFT].x) / (lm[FACE_RIGHT].x - lm[FACE_LEFT].x + 1e-6);
}

// ─── Challenge detection ──────────────────────────────────────────────────────
function detectAction(lm, challenge){
    if(!earBaseline) return false;

    if(challenge === "BLINK"){
        const ear = getEAR(lm);
        const EAR_CLOSE = earBaseline * 0.75;
        const EAR_OPEN  = earBaseline * 0.85;
        blinkOverlay.textContent = `EAR: ${ear.toFixed(3)} (close<${EAR_CLOSE.toFixed(3)})`;
        if(ear < EAR_CLOSE){
            actionFrameCount++;
        } else if(ear > EAR_OPEN){
            if(actionFrameCount >= MIN_ACTION_FRAMES && actionFrameCount <= MAX_ACTION_FRAMES){
                actionFrameCount = 0;
                return true;
            }
            actionFrameCount = 0;
        }
        return false;
    }

    if(challenge === "OPEN_MOUTH"){
        if(!marBaseline) return false;
        const mar = getMAR(lm);
        const MAR_OPEN = marBaseline * 3.0; // raised: must open mouth clearly (3× baseline)
        blinkOverlay.textContent = `MAR: ${mar.toFixed(3)} (need>${MAR_OPEN.toFixed(3)})`;
        // require sustained open mouth for 3 frames to avoid false trigger
        if(mar > MAR_OPEN){
            actionFrameCount++;
            if(actionFrameCount >= 3) return true;
        } else {
            actionFrameCount = 0;
        }
        return false;
    }

    if(challenge === "TURN_LEFT"){
        if(!noseBaseline) return false;
        const nx = getNoseX(lm);
        // Front camera is mirrored — user turns LEFT = nose moves RIGHT in camera coords
        blinkOverlay.textContent = `NoseX: ${nx.toFixed(3)} (need>${(noseBaseline+0.12).toFixed(3)})`;
        return nx > (noseBaseline + 0.12);
    }

    if(challenge === "TURN_RIGHT"){
        if(!noseBaseline) return false;
        const nx = getNoseX(lm);
        // Front camera is mirrored — user turns RIGHT = nose moves LEFT in camera coords
        blinkOverlay.textContent = `NoseX: ${nx.toFixed(3)} (need<${(noseBaseline-0.12).toFixed(3)})`;
        return nx < (noseBaseline - 0.12);
    }

    return false;
}

// ─── On challenge step complete ───────────────────────────────────────────────
function onStepComplete(){
    actionFrameCount = 0;
    currentStep++;

    if(currentStep >= challenges.length){
        // All challenges done — capture the frame RIGHT NOW, while the
        // live person who just performed the action is still in view.
        // This is the frame that will be sent for face recognition,
        // closing the window for a photo/video swap before clicking Verify.
        canvas.width  = 320;
        canvas.height = 240;
        ctx.drawImage(video, 0, 0, 320, 240);
        capturedImage = canvas.toDataURL("image/jpeg", 0.6);

        allDone = true;
        challengeBox.innerHTML = "✅ Liveness verified! Press Verify Face.";
        challengeBox.className = "done";
        blinkOverlay.textContent = "✅ Live face confirmed";
        blinkOverlay.className   = "done";
        verifyBtn.disabled       = false;
        verifyBtn.textContent    = "Verify Face";
        msg.innerHTML            = "All challenges passed. Press Verify Face.";
        document.getElementById("stepIndicator").style.display = "none";
    } else {
        // Next challenge
        showCurrentChallenge();
    }
}

function showCurrentChallenge(){
    const c = CHALLENGES[challenges[currentStep]];
    challengeBox.innerHTML = c.instruction;
    challengeBox.className = "";
    document.getElementById("stepNum").textContent = currentStep + 1;
    msg.innerHTML = `Step ${currentStep+1} of 2: ${c.label}`;
}

// ─── Calibration + frame processing ──────────────────────────────────────────
function processLandmarks(lm){
    const ear  = getEAR(lm);
    const mar  = getMAR(lm);
    const noseX = getNoseX(lm);

    // Calibration phase
    if(!baselineReady){
        earSamples.push(ear);
        marSamples.push(mar);
        noseSamples.push(noseX);

        const pct = Math.round((earSamples.length / BASELINE_FRAMES)*100);
        blinkOverlay.textContent = `Calibrating... ${pct}%`;

        if(earSamples.length >= BASELINE_FRAMES){
            // EAR baseline — top 60% (eyes open)
            const eSorted = [...earSamples].sort((a,b)=>b-a);
            earBaseline = eSorted.slice(0,21).reduce((s,v)=>s+v,0)/21;

            // MAR baseline — bottom 60% (mouth closed)
            const mSorted = [...marSamples].sort((a,b)=>a-b);
            marBaseline = mSorted.slice(0,21).reduce((s,v)=>s+v,0)/21;

            // Nose baseline — median (face forward)
            const nSorted = [...noseSamples].sort((a,b)=>a-b);
            noseBaseline = nSorted[Math.floor(nSorted.length/2)];

            baselineReady = true;
            showCurrentChallenge();
        }
        return;
    }

    if(allDone) return;

    // Detect current challenge
    if(detectAction(lm, challenges[currentStep])){
        onStepComplete();
    }
}

// ─── MediaPipe init ───────────────────────────────────────────────────────────
function initFaceMesh(){
    const faceMesh = new FaceMesh({
        locateFile: f => `https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/${f}`
    });
    faceMesh.setOptions({
        maxNumFaces:1, refineLandmarks:true,
        minDetectionConfidence:0.4, minTrackingConfidence:0.4
    });
    faceMesh.onResults(results => {
        if(!results.multiFaceLandmarks || !results.multiFaceLandmarks.length){
            if(!allDone) blinkOverlay.textContent = "👁 No face — move closer";
            return;
        }
        if(!allDone) processLandmarks(results.multiFaceLandmarks[0]);
    });
    const mpCam = new Camera(video, {
        onFrame: async () => { await faceMesh.send({image:video}); },
        width:640, height:480
    });
    mpCam.start();
    msg.innerHTML = "Camera ready. Keep still for calibration...";
}

// ─── Camera start ─────────────────────────────────────────────────────────────
async function startCamera(){
    msg.innerHTML = "Requesting camera access...";

    // Pick random challenges now (different every page load)
    challenges = pickChallenges();

    try{
        let stream = null;
        const constraints = [
            { video:{ facingMode:"user", width:{ideal:640}, height:{ideal:480} }, audio:false },
            { video:{ width:{ideal:640}, height:{ideal:480} }, audio:false },
            { video:true, audio:false }
        ];
        for(const c of constraints){
            try{ stream = await navigator.mediaDevices.getUserMedia(c); break; }
            catch(e){ continue; }
        }
        if(!stream) throw new Error("No camera");

        video.srcObject = stream;
        video.setAttribute('playsinline', true);
        await video.play();

        try{ initFaceMesh(); }
        catch(e){
            console.warn("MediaPipe unavailable:", e);
            allDone = true;
            verifyBtn.disabled    = false;
            verifyBtn.textContent = "Verify Face";
            msg.innerHTML = "Camera ready (challenge unavailable).";
        }
    } catch(err){
        let m = "Camera access failed.";
        if(err.name==='NotAllowedError') m = "📱 Camera permission denied. Allow camera and refresh.";
        else if(err.name==='NotFoundError') m = "📱 No camera found.";
        else if(err.name==='NotReadableError') m = "📱 Camera in use by another app.";
        msg.innerHTML = m;
    }
}

window.addEventListener('load', () => { setTimeout(startCamera, 1000); });

// ─── Verify face ──────────────────────────────────────────────────────────────
function verifyFace(){
    if(!allDone){
        msg.innerHTML = "⚠ Please complete the challenge first.";
        return;
    }

    const progressContainer = document.getElementById("progressContainer");
    verifyBtn.disabled      = true;
    verifyBtn.textContent   = "Verifying...";
    progressContainer.style.display = "block";

    let image;
    if(capturedImage){
        // Use the frame captured at the moment the liveness challenge
        // passed — NOT a new frame from the current camera view.
        image = capturedImage;
    } else {
        // Fallback only: MediaPipe was unavailable, no challenge ran,
        // so there is nothing to anchor to — capture live as before.
        canvas.width  = 320;
        canvas.height = 240;
        ctx.drawImage(video, 0, 0, 320, 240);
        image = canvas.toDataURL("image/jpeg", 0.6);
    }

    updateProgress(20, "Capturing image...");
    setTimeout(() => {
        updateProgress(40, "Analyzing face features...");
        setTimeout(() => {
            updateProgress(60, "Checking liveness detection...");
            setTimeout(() => {
                updateProgress(80, "Matching face with database...");
                fetch("verify_face.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/x-www-form-urlencoded" },
                    body:
                        "image="      + encodeURIComponent(image) +
                        "&subject_id=<?php echo $subject_id; ?>" +
                        "&date=<?php echo $date; ?>" +
                        "&time=<?php echo $time; ?>"
                })
                .then(res => res.text())
                .then(data => {
                    updateProgress(100, "Verification complete");
                    setTimeout(() => {
                        progressContainer.style.display = "none";
                        msg.innerHTML = data;

                        // Lock button permanently — success OR already taken
                        if(data.includes("Attendance Success") ||
                           data.includes("already taken")){
                            verifyBtn.disabled    = true;
                            verifyBtn.textContent = data.includes("Attendance Success")
                                                    ? "Attendance Taken ✔"
                                                    : "Already Submitted ✔";
                            challengeBox.innerHTML = data.includes("Attendance Success")
                                                    ? "✅ Attendance recorded successfully."
                                                    : "✅ Attendance already taken for this class.";
                            challengeBox.className = "done";
                            document.getElementById("stepIndicator").style.display = "none";
                        } else {
                            // Genuine failure — reset challenges for retry
                            allDone       = false;
                            currentStep   = 0;
                            baselineReady = false;
                            capturedImage = null;
                            earSamples    = []; marSamples = []; noseSamples = [];
                            actionFrameCount = 0;
                            challenges    = pickChallenges();
                            verifyBtn.disabled    = true;
                            verifyBtn.textContent = "Complete challenge first...";
                            challengeBox.innerHTML = "Please complete the challenge again to retry.";
                            challengeBox.className = "";
                            blinkOverlay.className = "";
                            document.getElementById("stepIndicator").style.display = "";
                        }
                    }, 1000);
                })
                .catch(() => {
                    progressContainer.style.display = "none";
                    verifyBtn.disabled    = false;
                    verifyBtn.textContent = "Verify Face";
                    msg.innerHTML = "Error during verification.";
                });
            }, 800);
        }, 600);
    }, 400);
}

function updateProgress(pct, text){
    document.getElementById("progressContainer").style.display = "block";
    document.getElementById("progressBar").style.width   = pct + "%";
    document.getElementById("progressText").textContent  = pct + "%";
    msg.innerHTML = text;
}
</script>
</body>
</html>