<?php
include "connection.php";

$subject_id = $_POST['subject_id'] ?? '';
$lat        = $_POST['lat']        ?? '';
$lng        = $_POST['lng']        ?? '';
$radius     = intval($_POST['radius'] ?? 100);

if($radius < 20)  $radius = 20;
if($radius > 500) $radius = 500;

if($subject_id == '' || $lat == '' || $lng == ''){
    echo "Missing data.";
    exit();
}

$conn->query("DELETE FROM classroom_location WHERE subject_id='$subject_id'");
$conn->query("
INSERT INTO classroom_location (subject_id, latitude, longitude, radius)
VALUES ('$subject_id','$lat','$lng','$radius')
");

echo "Location saved (radius: {$radius}m).";
?>