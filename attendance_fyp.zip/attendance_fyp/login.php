<?php
session_start();
include "connection.php";

if(isset($_POST['login'])){

    $userid   = trim($_POST['id']);
    $password = trim($_POST['password']);

    $sql = "
    SELECT users.*
    FROM users
    LEFT JOIN students ON users.id = students.id
    LEFT JOIN lecturers ON users.id = lecturers.id
    WHERE (
        users.id = ?
        OR students.student_id = ?
        OR lecturers.lecturer_id = ?
    )
    AND users.password = ?
    LIMIT 1
    ";

    $stmt = $conn->prepare($sql);

    if(!$stmt){
        die("Prepare Failed: " . $conn->error);
    }

    $stmt->bind_param("ssss", $userid, $userid, $userid, $password);
    $stmt->execute();

    $stmt->store_result();

    if($stmt->num_rows > 0){

        $stmt->bind_result($id,$name,$email,$phone,$address,$dbpass,$role);
        $stmt->fetch();

        $_SESSION['user_id'] = $id;
        $_SESSION['id']      = $id;
        $_SESSION['name']    = $name;
        $_SESSION['role']    = $role;

        if($role == 'student'){
            $_SESSION['student_id'] = $userid;
            header("Location: student.php");
        }
        elseif($role == 'lecturer'){
            header("Location: lecturer.php");
        }
        else{
            header("Location: admin.php");
        }

        exit();

    } else {
        echo "<script>alert('Invalid User ID or Password');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Log In</title>
<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI', sans-serif;
}

body{
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:#eef5ff;
}

.login-container{
    width:100%;
    display:flex;
    justify-content:center;
    align-items:center;
}

.login-card{
    width:900px;
    max-width:90%;
    background:white;
    padding:40px 60px;
    border-radius:25px;
    box-shadow:0 15px 30px rgba(0,0,0,0.08);
    text-align:center;
}

.logo{
    width:280px;
    margin-bottom:15px;
}

h1{
    font-size:32px;
    color:#10254d;
    margin-bottom:20px;
    font-weight:700;
}

/* .subtitle{
    color:#6b7c9f;
    font-size:28px;
    margin-bottom:40px;
} */

input[type="text"],
input[type="password"]{
    width:100%;
    padding:16px 20px;
    margin-bottom:18px;
    border:2px solid #dce6f5;
    border-radius:15px;
    background:#f6faff;
    font-size:20px;
}

.option-row{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin:10px 0 20px;
    font-size:18px;
}

.option-row label{
    display:flex;
    align-items:center;
    gap:10px;
    color:#23395d;
}

.option-row a{
    text-decoration:none;
    color:#2563eb;
}

button{
    width:100%;
    padding:14px;
    border:none;
    border-radius:15px;
    background:linear-gradient(90deg,#2563eb,#1d4ed8);
    color:white;
    font-size:22px;
    font-weight:600;
    cursor:pointer;
}

button:hover{
    transform:translateY(-2px);
}

input[type="checkbox"]{
    width:20px;
    height:20px;
}
</style>
</head>
<body>

<div class="login-container">

    <div class="login-card">

        <img src="img/logo_mmu.png" class="logo">

        <h1>Log In</h1>

        <form method="POST">

            <input type="text"
                   name="id"
                   placeholder="User ID"
                   required>

            <input type="password"
                   name="password"
                   placeholder="Password"
                   required>

            <div class="option-row">
                <label>
                    <input type="checkbox">
                    Remember me
                </label>

                <a href="#">Forgot Password?</a>
            </div>

            <button type="submit" name="login">
                Log In
            </button>

        </form>

    </div>

</div>

</body>
</html>