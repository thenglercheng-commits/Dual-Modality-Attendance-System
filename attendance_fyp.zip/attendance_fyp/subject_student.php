<?php
session_start();
include "connection.php";

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$search = $_GET['search'] ?? '';

/* =========================
   GET STUDENT INFO
========================= */

$student_query = $conn->query("
SELECT student_id
FROM students
WHERE id='$user_id'
LIMIT 1
");

$student = $student_query->fetch_assoc();
$student_id = $student['student_id'];

/* =========================
   GET STUDENT NAME
========================= */

$user_query = $conn->query("
SELECT name
FROM users
WHERE id='$user_id'
LIMIT 1
");

$user = $user_query->fetch_assoc();
$name = $user['name'];

/* =========================
   SUBJECT QUERY
========================= */

$sql = "
SELECT
subjects.subject_id,
subjects.subject_name,
subjects.faculty,
subjects.lecturer,
subjects.total_student_enroll

FROM student_subject

LEFT JOIN subjects
ON student_subject.subject_id = subjects.subject_id

WHERE student_subject.student_id='$student_id'
";

if($search != ''){

    $sql .= " AND (

        subjects.subject_id LIKE '%$search%' OR

        subjects.subject_name LIKE '%$search%' OR

        subjects.faculty LIKE '%$search%' OR

        subjects.lecturer LIKE '%$search%'

    )";

}

$sql .= " ORDER BY subjects.subject_id ASC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>My Subjects</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'Poppins',sans-serif;
    background:#f4f8ff;
    display:flex;
}

/* =========================
   SIDEBAR
========================= */

.sidebar{
    width:260px;
    min-height:100vh;
    background:white;
    padding:25px;
    position:fixed;
    left:0;
    top:0;
    border-right:1px solid #eee;
}

.brand{
    font-size:28px;
    font-weight:700;
    margin-bottom:40px;
    color:#2563eb;
}

.menu a{
    display:flex;
    align-items:center;
    gap:12px;
    padding:15px;
    margin-bottom:12px;
    border-radius:16px;
    text-decoration:none;
    color:#334155;
    font-weight:500;
    transition:.3s;
    font-size:15px;
}

.menu a:hover,
.menu a.active{
    background:#2563eb;
    color:white;
}

/* =========================
   MAIN
========================= */

.main{
    margin-left:260px;
    width:100%;
    padding:30px;
}

/* =========================
   TOP
========================= */

.top{
    background:white;
    padding:30px;
    border-radius:24px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    box-shadow:0 8px 20px rgba(0,0,0,.05);
}

.top h1{
    font-size:28px;
    margin-bottom:10px;
}

.top p{
    color:#64748b;
    font-size:14px;
}

.right-top{
    display:flex;
    align-items:center;
    gap:15px;
}

.logout-btn{
    background:#2563eb;
    color:white;
    text-decoration:none;
    padding:12px 20px;
    border-radius:12px;
    font-weight:600;
}

.profile{
    width:50px;
    height:50px;
    border-radius:50%;
    background:#2563eb;
    color:white;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:24px;
    text-decoration:none;
}

/* =========================
   CARDS
========================= */

.cards{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:20px;
    margin-top:25px;
}

.card{
    background:white;
    border-radius:22px;
    padding:25px;
    box-shadow:0 8px 20px rgba(0,0,0,.05);
}

.card h3{
    color:#64748b;
    margin-bottom:12px;
    font-size:16px;
}

.card p{
    font-size:24px;
    font-weight:700;
    color:#2563eb;
}

/* =========================
   SECTION
========================= */

.section{
    margin-top:25px;
    background:white;
    padding:25px;
    border-radius:24px;
    box-shadow:0 8px 20px rgba(0,0,0,.05);
}

.section-title{
    margin-bottom:20px;
}

.section-title h2{
    margin-bottom:8px;
    font-size:24px;
}

.section-title p{
    color:#64748b;
    font-size:14px;
}

/* =========================
   SEARCH
========================= */

.search-box{
    margin-bottom:25px;
}

.search{
    width:100%;
    max-width:350px;
    padding:14px 18px;
    border:1px solid #ddd;
    border-radius:14px;
    outline:none;
    font-family:'Poppins',sans-serif;
}

/* =========================
   TABLE
========================= */

table{
    width:100%;
    border-collapse:collapse;
    overflow:hidden;
    border-radius:18px;
    font-size:14px;
}

thead{
    background:#2563eb;
    color:white;
}

th{
    padding:18px;
    text-align:left;
}

td{
    padding:18px;
    border-bottom:1px solid #eee;
}

tbody tr:hover{
    background:#f8fbff;
}

/* =========================
   BADGE
========================= */

.badge{
    background:#dbeafe;
    color:#2563eb;
    padding:8px 14px;
    border-radius:999px;
    font-size:13px;
    font-weight:600;
}

/* =========================
   RESPONSIVE
========================= */

@media(max-width:900px){

    .sidebar{
        width:180px;
        padding:20px 15px;
    }

    .main{
        margin-left:180px;
        width:calc(100% - 180px);
        padding:20px;
    }

    .top{
        flex-direction:column;
        align-items:flex-start;
        gap:20px;
    }

}

</style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar">

    <div class="brand">
        Student Panel
    </div>

    <div class="menu">
        <a href="student.php"> Overview</a>
        <a href="attendance_student.php"> Attendance</a>
        <a href="subject_student.php" class="active"> Subject</a>
        <a href="timetable_student.php"> Timetable</a>
    </div>

</div>

<!-- MAIN -->
<div class="main">

    <!-- TOP -->
    <div class="top">

        <div>
            <h1>My Subjects</h1>
            <p>View your enrolled subjects here.</p>
        </div>

        <div class="right-top">

            <a href="logout.php" class="logout-btn">
                Logout
            </a>

            <a href="profile_student.php" class="profile">
                👤
            </a>

        </div>

    </div>

    <!-- CARDS -->
    <div class="cards">

        <div class="card">
            <h3>Total Subjects</h3>
            <p>
                <?php echo $result->num_rows; ?>
            </p>
        </div>

    </div>

    <!-- SECTION -->
    <div class="section">

        <div class="section-title">
            <h2>Subject Records</h2>
            <p>Check your enrolled subject information.</p>
        </div>

        <!-- SEARCH -->
        <div class="search-box">

            <form method="GET">

                <input type="text"
                       name="search"
                       class="search"
                       placeholder="Search subject..."
                       value="<?php echo htmlspecialchars($search); ?>">

            </form>

        </div>

        <!-- TABLE -->
        <table>

            <thead>

                <tr>
                    <th>Subject ID</th>
                    <th>Subject Name</th>
                    <th>Faculty</th>
                    <th>Lecturer</th>
                </tr>

            </thead>

            <tbody>

            <?php
            if($result->num_rows > 0){

                while($row = $result->fetch_assoc()){
            ?>

                <tr>

                    <td>
                        <?php echo $row['subject_id']; ?>
                    </td>

                    <td>
                        <?php echo $row['subject_name']; ?>
                    </td>

                    <td>

                        <span class="badge">
                            <?php echo $row['faculty']; ?>
                        </span>

                    </td>

                    <td>
                        <?php echo $row['lecturer']; ?>
                    </td>
                </tr>

            <?php
                }

            }else{
            ?>

                <tr>
                    <td colspan="5">
                        No subjects found.
                    </td>
                </tr>

            <?php
            }
            ?>

            </tbody>

        </table>

    </div>

</div>

</body>
</html>