<?php
session_start();
include "connection.php";

if(!isset($_SESSION['name']) || $_SESSION['role'] != 'lecturer'){
    header("Location: login.php");
    exit();
}

$lecturer = $_SESSION['name'];

/* =========================
   SEARCH
========================= */
$where = " WHERE s.lecturer='$lecturer' ";

if(isset($_GET['search']) && $_GET['keyword'] != ""){

    $keyword = $_GET['keyword'];

    $where .= " AND (
        s.subject_id LIKE '%$keyword%'
        OR s.subject_name LIKE '%$keyword%'
    )";
}

/* =========================
   DISPLAY DATA
========================= */
$result = $conn->query("
    SELECT
        s.subject_id,
        s.subject_name,
        COUNT(ss.student_id) AS total_students
    FROM subjects s
    LEFT JOIN student_subject ss
        ON s.subject_id = ss.subject_id
    $where
    GROUP BY s.subject_id, s.subject_name
    ORDER BY s.subject_id ASC
");
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Lecturer Subject</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}
body{
    font-family:'Poppins',sans-serif;
    display:flex;
    background:#f5f8fc;
}

/* Sidebar */
.sidebar{
    width:260px;
    min-height:100vh;
    background:white;
    padding:25px;
    position:fixed;
    left:0;
    top:0;
}
.brand{
    font-size:20px;
    font-weight:bold;
    margin-bottom:35px;
}
.menu a{
    display:flex;
    align-items:center;
    gap:12px;
    padding:14px 16px;
    margin-bottom:10px;
    border-radius:12px;
    text-decoration:none;
    color:black;
    transition:0.2s;
    font-size:15px;
}
.menu a:hover,
.menu a.active{
    background:#2563eb;
    color:white;
}

/* Toggle */
.toggle{
    position:fixed;
    top:20px;
    left:20px;
    background:#4da6ff;
    color:white;
    border:none;
    padding:10px 14px;
    border-radius:10px;
    cursor:pointer;
    z-index:1000;
}

/* Main */
.main{
    margin-left:260px;
    width:calc(100% - 260px);
    padding:35px;
}

/* Top Box */
.top{
    background:white;
    border-radius:18px;
    padding:25px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    box-shadow:0 6px 15px rgba(0,0,0,.06);
    margin-bottom:25px;
}

.top h1{
    color:#0b1652;
    font-size:28px;
}

.top p{
    color:#475569;
    margin-top:8px;
}

.top-flex{
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.top-right{
    display:flex;
    gap:18px;
    align-items:center;
}

.logout-btn{
    background:#2563eb;
    color:white;
    text-decoration:none;
    padding:12px 22px;
    border-radius:12px;
    font-weight:600;
}

.cards{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:20px;
    margin-top:25px;
}

.card{
    background:white;
    border-radius:22px;
    padding:25px;
    box-shadow:0 8px 20px rgba(0,0,0,.05);
}

.card h3{
    color:#64748b;
    margin-bottom:12px;
    font-size:16px;
}

.card p{
    font-size:24px;
    font-weight:700;
    color:#2563eb;
}

.section{
    margin-top:25px;
    background:white;
    padding:25px;
    border-radius:24px;
    box-shadow:0 8px 20px rgba(0,0,0,.05);
}

.section-title{
    margin-bottom:20px;
}

.section-title h2{
    margin-bottom:8px;
    font-size:24px;
}
/* Content Box */
.box{
    background:white;
    padding:25px;
    border-radius:18px;
    box-shadow:0 6px 15px rgba(0,0,0,.06);
}

input{
    padding:10px;
    width:220px;
    border:1px solid #ccc;
    border-radius:10px;
    margin:5px 5px 15px 0;
}
button{
    padding:10px 18px;
    border:none;
    border-radius:10px;
    background:#2563eb;
    color:white;
    cursor:pointer;
}

table{
    width:100%;
    border-collapse:collapse;
    overflow:hidden;
    border-radius:18px;
    font-size:14px;
}
th{
    background:#2563eb;
    color:white;
    padding:12px;
}
td{
    padding:12px;
    border:1px solid #ddd;
    text-align:center;
}
</style>
</head>

<body>

<div class="sidebar">

    <div class="brand">Lecturer Panel</div>

    <div class="menu">
        <a href="lecturer.php"> Overview</a>
        <a href="subject_lecturer.php" class="active"> Subject</a>
        <a href="attendance_lecturer.php">Attendance</a>
        <a href="timetable_lecturer.php"> Timetable</a>
    </div>

</div>

<div class="main">

    <!-- TOP HEADER -->

    <div class="top">

        <div>
            <h1>My Subjects</h1>
            <p>View the subjects you are assigned to teach.</p>
        </div>

        <div class="right-top">

            <a href="logout.php" class="logout-btn">Logout</a>
        </div>

    </div>

    <!-- CARD -->
    <div class="cards">
        <div class="card">
            <h3>Total Subjects</h3>
            <p><?php echo mysqli_num_rows($result); ?></p>
        </div>
    </div>

    <!-- SUBJECT TABLE -->

    <div class="section">
        <div class="section-title">
            <h2>Subject Records</h2>
        </div>

        <form method="GET">

            <input
                type="text"
                name="keyword"
                placeholder="Search subject..."
                value="<?php echo $_GET['keyword'] ?? ''; ?>">
            <button type="submit" name="search">Search</button>

        </form>

        <br>

        <table>
            <tr>
                <th>Subject ID</th>
                <th>Subject Name</th>
                <th>Total Students</th>
            </tr>

            <?php

            mysqli_data_seek($result,0);

            if($result->num_rows > 0){

                while($row = $result->fetch_assoc()){

            ?>

            <tr>
                <td><?php echo $row['subject_id']; ?></td>
                <td><?php echo $row['subject_name']; ?></td>
                <td><?php echo $row['total_students']; ?></td>
            </tr>

            <?php
                }
            }else{

            ?>

            <tr>
                <td colspan="3">No subject found.</td>
            </tr>

            <?php } ?>

        </table>

    </div>

</div>

</body>
</html>