<?php
$subject_id = $_GET['subject_id'] ?? '';
$date = $_GET['date'] ?? '';
$time = $_GET['time'] ?? '';

$current_slot = floor(time() / 10);
$token = md5("secret_salt".$current_slot);
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>QR Code Attendance</title>

<style>
body{
    font-family:Arial;
    background:#eaf6ff;
    display:flex;
    justify-content:center;
    align-items:center;
    min-height:100vh;
    margin:0;
}
.box{
    background:white;
    width:420px;
    padding:35px;
    border-radius:20px;
    text-align:center;
    box-shadow:0 8px 20px rgba(0,0,0,.08);
}
.qr img{
    width:260px;
    height:260px;
}
.timer{
    margin-top:15px;
    background:#2563eb;
    color:white;
    padding:12px;
    border-radius:12px;
    font-weight:bold;
}
.btn{
    display:inline-block;
    margin-top:20px;
    padding:12px 20px;
    background:#64748b;
    color:white;
    text-decoration:none;
    border-radius:10px;
}
</style>
</head>

<body>

<div class="box">
    <h1>Attendance QR</h1>

    <p><b>Subject:</b> <?php echo htmlspecialchars($subject_id); ?></p>
    <p><b>Date:</b> <?php echo htmlspecialchars($date); ?></p>
    <p><b>Time:</b> <?php echo htmlspecialchars($time); ?></p>

    <div class="qr">
        <img id="qrImage"
        src="qr_generator.php?subject_id=<?php echo urlencode($subject_id); ?>&date=<?php echo urlencode($date); ?>&time=<?php echo urlencode($time); ?>&token=<?php echo $token; ?>&t=<?php echo time(); ?>">
    </div>

    <div class="timer">
        Refresh New QR In <span id="countdown">10</span>s
    </div>

    <a href="online_attendance.php" class="btn">Back</a>
</div>

<script>
let seconds = 10;

setInterval(function(){
    seconds--;
    document.getElementById("countdown").innerText = seconds;

    if(seconds <= 0){
        location.reload();
    }
},1000);
</script>

</body>
</html>