<?php
session_start();
include "connection.php";

if(!isset($_SESSION['name']) || $_SESSION['role'] != 'lecturer'){
    header("Location: login.php");
    exit();
}

$lecturer = $_SESSION['name'];
$result = null;

/* UPDATE CLASS */
if(isset($_POST['update_class'])){

    $id = $_POST['id'];
    $new_date = $_POST['new_date'];
    $new_start = $_POST['new_start'];
    $new_end = $_POST['new_end'];

    $sql = "
    UPDATE timetable
    SET class_date='$new_date',
        start_time='$new_start',
        end_time='$new_end'
    WHERE id='$id'
    ";

    $conn->query($sql);
}

/* SEARCH */
if(isset($_GET['search'])){

    $subject_id = $_GET['subject_id'] ?? '';
    $date       = $_GET['class_date'] ?? '';
    $time       = $_GET['start_time'] ?? '';

    $sql = "
    SELECT timetable.*, subjects.subject_name
    FROM timetable
    LEFT JOIN subjects
        ON timetable.subject_id = subjects.subject_id
    WHERE subjects.lecturer = '$lecturer'
    ";

    if($subject_id != ''){
        $sql .= " AND timetable.subject_id LIKE '%$subject_id%'";
    }

    if($date != ''){
        $sql .= " AND timetable.class_date = '$date'";
    }

    if($time != ''){
        $sql .= " AND timetable.start_time = '$time'";
    }

    $sql .= " ORDER BY timetable.class_date, timetable.start_time";

    $result = $conn->query($sql);
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Online Attendance</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    display:flex;
    background:#f5f8fc;
}

/* SIDEBAR */
.sidebar{
    width:260px;
    min-height:100vh;
    background:white;
    padding:25px;
    position:fixed;
    left:0;
    top:0;
}

.sidebar a{
    display:flex;
    align-items:center;
    gap:12px;
    padding:14px 16px;
    margin-bottom:10px;
    border-radius:12px;
    text-decoration:none;
    color:black;
    transition:0.2s;
    font-size:15px;
}

.sidebar a.active{
    background:#2563eb;
    color:white;
}

/* MAIN */

.main{
    margin-left:260px;
    width:calc(100% - 260px);
    padding:35px;
}

/* HEADER */

.top{
    background:white;
    border-radius:25px;
    padding:28px 40px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    box-shadow:0 8px 25px rgba(0,0,0,.05);
    margin-bottom:30px;
}

.top h1{
    color:#0b1652;
    font-size:28px;
}

.top p{
    color:#475569;
    margin-top:8px;
}

.back-btn{
    border:2px solid #d9e2f2;
    padding:12px 22px;
    border-radius:16px;
    text-decoration:none;
    color:#2563eb;
    font-weight:600;
    font-weight:bold;
}

/* SEARCH CARD */

.box{
    background:white;
    border-radius:25px;
    padding:28px 40px;
    box-shadow:0 8px 25px rgba(0,0,0,.05);
}

.box h2{
    color:#0d1b57;
    margin-bottom:10px;
}

.line{
    width:45px;
    height:5px;
    background:#2563eb;
    border-radius:20px;
    margin:15px 0 35px;
}

/* FORM */

.search-row{
    display:flex;
    gap:20px;
    align-items:center;
    flex-wrap:wrap;
}

.search-row input{
     width:260px;
    padding:13px 15px;
    border:1px solid #dbe2ea;
    border-radius:16px;
    background:#fff;
    font-size:14px;
    outline:none;
}

.search-btn{
     background:#2962ff;
    color:white;
    border:none;
    padding:13px 22px;
    border-radius:16px;
    font-size:14px;
    font-weight:bold;
    cursor:pointer;
}

/* RESULT TABLE */

table{
    width:100%;
    border-collapse:collapse;
    margin-top:30px;
    overflow:hidden;
    border-radius:18px;
}

th{
    background:#2563eb;
    color:white;
    padding:15px;
}

td{
    padding:15px;
    text-align:center;
    border-bottom:1px solid #e2e8f0;
}

.generate{
    background:#16a34a;
    color:white;
    padding:10px 18px;
    border-radius:10px;
    text-decoration:none;
}

.savebtn{
    background:#2563eb;
    color:white;
    border:none;
    padding:10px 16px;
    border-radius:10px;
}

td input[type="date"],
td input[type="time"]{
    border:1px solid #dbe2ef;
    border-radius:12px !important;
    padding:8px 12px;
    height:42px;
    background:white;
}
</style>
</head>
<body>

<div class="sidebar">
    <h2>Lecturer Panel</h2>
    <a href="attendance_lecturer.php">Overview</a>
    <a href="subject_lecturer.php">Subject</a>
    <a href="attendance_lecturer.php" class="active">Attendance</a>
    <a href="timetable_lecturer.php">Timetable</a>
</div>

<div class="main">
<div class="top">
    <div>
        <h1>Online Attendance</h1>
        <p>Search timetable and generate QR code.</p>
    </div>

    <a href="attendance_lecturer.php" class="back-btn">
        ← Back
    </a>

</div>

<div class="box">

    <h2>Search Timetable</h2>

    <div class="line"></div>

    <form method="GET">

        <div class="search-row">

            <input
                type="text"
                name="subject_id"
                placeholder="Subject ID">

            <input
                type="date"
                name="class_date">

            <input
                type="time"
                name="start_time">

            <button
                class="search-btn"
                type="submit"
                name="search">
                 Search
            </button>

        </div>

    </form>
<?php if($result){ ?>

<table>
<tr>
<th>Subject ID</th>
<th>Date</th>
<th>Start</th>
<th>End</th>
<th>QR Code</th>
<th>Edit Replacement</th>
</tr>

<?php
while($row = $result->fetch_assoc()){
?>

<tr>

<td><?= $row['subject_id']; ?></td>
<td><?= $row['class_date']; ?></td>
<td><?= $row['start_time']; ?></td>
<td><?= $row['end_time']; ?></td>

<td>
<a class="generate"
href="qr_code.php?subject_id=<?= $row['subject_id']; ?>&date=<?= $row['class_date']; ?>&time=<?= $row['start_time']; ?>">
Generate
</a>
</td>

<td>
<form method="POST" style="display:inline;">
<input type="hidden" name="id" value="<?= $row['id']; ?>">

<input type="date" name="new_date" required>
<input type="time" name="new_start" required>
<input type="time" name="new_end" required>

<button class="savebtn" name="update_class">
Save
</button>
</form>
</td>

</tr>

<?php } ?>

</table>

<?php } ?>

</div>
</div>
</body>
</html>