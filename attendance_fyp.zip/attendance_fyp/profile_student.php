<?php
session_start();
include "connection.php";

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}

$id = $_SESSION['user_id'];

/* Register Face */
if(isset($_POST['register_face'])){

    $get = $conn->query("
        SELECT users.name, students.student_id
        FROM users
        JOIN students ON users.id = students.id
        WHERE users.id='$id'
    ");

    $data = $get->fetch_assoc();

    $student_id = $data['student_id'];
    $name       = $data['name'];

    $cmd = "python register_face.py \"$student_id\" \"$name\" 2>&1";
    $output = shell_exec($cmd);

    echo "<pre>$output</pre>";
    exit();
}

/* Change Password */
if(isset($_POST['change_password'])){

    $old = $_POST['old_password'];
    $new = $_POST['new_password'];

    $check = $conn->query("SELECT * FROM users WHERE id='$id' AND password='$old'");

    if($check->num_rows > 0){

        $conn->query("UPDATE users SET password='$new' WHERE id='$id'");
        echo "<script>alert('Password updated successfully');</script>";

    }else{
        echo "<script>alert('Current password is incorrect');</script>";
    }
}

/* Update Contact */
if(isset($_POST['update_contact'])){

    $phone   = $_POST['phone'];
    $address = $_POST['address'];

    $conn->query("
        UPDATE users
        SET phone='$phone',
            address='$address'
        WHERE id='$id'
    ");

    echo "<script>alert('Contact updated successfully');</script>";
}

/* Get Profile */
$sql = "
SELECT users.*, students.student_id, students.faculty, students.batch
FROM users
LEFT JOIN students ON users.id = students.id
WHERE users.id='$id'
";

$result = $conn->query($sql);
$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Profile</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:Arial, sans-serif;
    background:#eaf6ff;
    padding:40px;
}

.box{
    max-width:760px;
    margin:auto;
    background:white;
    padding:40px;
    border-radius:24px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
}

.profile-header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:35px;
}

h1{
    font-size:42px;
}

.back-btn{
    background:#2563eb;
    color:white;
    text-decoration:none;
    padding:12px 18px;
    border-radius:12px;
    font-weight:600;
}

.back-btn:hover{
    background:#1d4ed8;
}

.section{
    margin-top:35px;
}

.section-title{
    font-size:22px;
    font-weight:bold;
    margin-bottom:20px;
    color:#111827;
    border-bottom:2px solid #eef2ff;
    padding-bottom:8px;
}

.row{
    margin-bottom:22px;
}

label{
    display:block;
    font-weight:700;
    margin-bottom:8px;
    font-size:18px;
}

input{
    width:100%;
    padding:14px 16px;
    border:1px solid #d1d5db;
    border-radius:14px;
    font-size:16px;
}

.btn{
    background:#2563eb;
    color:white;
    border:none;
    padding:12px 22px;
    border-radius:12px;
    cursor:pointer;
    font-size:16px;
    font-weight:600;
    margin-top:8px;
}

.btn:hover{
    background:#1d4ed8;
}

.space{
    height:18px;
}
</style>
</head>

<body>

<div class="box">

    <div class="profile-header">
        <h1>Student Profile</h1>
        <a href="student.php" class="back-btn">← Back to Dashboard</a>
    </div>

    <!-- Basic Info -->
    <div class="section">
        <div class="section-title">Basic Information</div>

        <div class="row">
            <label>Student ID</label>
            <input value="<?php echo $row['student_id']; ?>" readonly>
        </div>

        <div class="row">
            <label>Name</label>
            <input value="<?php echo $row['name']; ?>" readonly>
        </div>

        <div class="row">
            <label>Email</label>
            <input value="<?php echo $row['email']; ?>" readonly>
        </div>

        <div class="row">
            <label>Faculty</label>
            <input value="<?php echo $row['faculty']; ?>" readonly>
        </div>

        <div class="row">
            <label>Batch</label>
            <input value="<?php echo $row['batch']; ?>" readonly>
        </div>
    </div>

    <!-- Contact -->
    <div class="section">
        <div class="section-title">Contact Information</div>

        <form method="POST">

            <div class="row">
                <label>Phone Number</label>
                <input type="text" name="phone" value="<?php echo $row['phone']; ?>" required>
            </div>

            <div class="row">
                <label>Address</label>
                <input type="text" name="address" value="<?php echo $row['address']; ?>" required>
            </div>

            <button type="submit" name="update_contact" class="btn">Save Contact</button>
        </form>
    </div>

    <!-- Password -->
    <div class="section">
        <div class="section-title">Reset Password</div>

        <form method="POST">

            <div class="row">
                <label>Current Password</label>
                <input type="password" name="old_password" placeholder="Enter current password" required>
            </div>

            <div class="row">
                <label>New Password</label>
                <input type="password" name="new_password" placeholder="Enter new password" required>
            </div>

            <button type="submit" name="change_password" class="btn">Update Password</button>
        </form>
    </div>

    <!-- Face -->
    <div class="section">
        <div class="section-title">Face Enrollment</div>

        <a href="register_face.php" class="btn" style="text-decoration:none;display:inline-block;">
            Register Face
        </a>
    </div> 
</div>

</body>
</html>