<?php
session_start();
include "connection.php";

$student_id = $_GET['student_id'] ?? '';

if($student_id == ''){
    die("Student ID missing");
}

/* =========================
   ADD SUBJECT
========================= */

if(isset($_POST['add_subject'])){

    if(isset($_POST['subject_ids'])){

        $subject_ids = $_POST['subject_ids'];

        foreach($subject_ids as $subject_id){

            $check = $conn->query("
            SELECT *
            FROM student_subject
            WHERE student_id='$student_id'
            AND subject_id='$subject_id'
            ");

            if($check->num_rows == 0){

                $conn->query("
                INSERT INTO student_subject(student_id,subject_id)
                VALUES('$student_id','$subject_id')
                ");

                // Auto-update total_student_enroll in subjects table
                $conn->query("
                UPDATE subjects
                SET total_student_enroll = (
                    SELECT COUNT(*) FROM student_subject
                    WHERE subject_id = '$subject_id'
                )
                WHERE subject_id = '$subject_id'
                ");
            }
        }
    }

    header("Location: subject_view.php?student_id=$student_id");
    exit();
}

/* =========================
   DELETE SUBJECT
========================= */

if(isset($_GET['remove'])){

    $remove = $_GET['remove'];

    $conn->query("
    DELETE FROM student_subject
    WHERE student_id='$student_id'
    AND subject_id='$remove'
    ");

    // Auto-update total_student_enroll in subjects table
    $conn->query("
    UPDATE subjects
    SET total_student_enroll = (
        SELECT COUNT(*) FROM student_subject
        WHERE subject_id = '$remove'
    )
    WHERE subject_id = '$remove'
    ");

    header("Location: subject_view.php?student_id=$student_id");
    exit();
}

/* =========================
   STUDENT INFO
========================= */

$student = $conn->query("
SELECT 
users.name,
students.student_id
FROM students
LEFT JOIN users
ON students.id = users.id
WHERE students.student_id='$student_id'
")->fetch_assoc();

/* =========================
   ALL SUBJECTS
========================= */

$subjects = $conn->query("
SELECT *
FROM subjects
ORDER BY subject_id ASC
");

/* =========================
   ENROLLED SUBJECTS
========================= */

$enrolled = $conn->query("
SELECT 
subjects.subject_id,
subjects.subject_name,
subjects.faculty,
subjects.lecturer
FROM student_subject
LEFT JOIN subjects
ON student_subject.subject_id = subjects.subject_id
WHERE student_subject.student_id='$student_id'
ORDER BY subjects.subject_id ASC
");
?>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Subject Enrollment</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'Poppins',sans-serif;
    background:#eef5ff;
    padding:22px;
    color:#0f172a;
}

.container{
    background:white;
    border-radius:22px;
    padding:26px;
    box-shadow:0 10px 30px rgba(0,0,0,.06);
}

/* TOP */

.top-bar{
    display:flex;
    justify-content:space-between;
    align-items:flex-start;
    margin-bottom:24px;
}

.top-bar h1{
    font-size:28px;
    font-weight:700;
    margin-bottom:8px;
}

.top-bar p{
    color:#64748b;
    font-size:16px;
}

.back-btn{
    background:#2563eb;
    color:white;
    text-decoration:none;
    padding:14px 22px;
    border-radius:14px;
    font-weight:600;
    transition:.2s;
}

.back-btn:hover{
    background:#1d4ed8;
}

/* SECTION */

.section{
    background:#f8fbff;
    border:1px solid #dbeafe;
    border-radius:20px;
    padding:20px;
    margin-bottom:24px;
}

.section-header{
    margin-bottom:20px;
}

.section-header h2{
    font-size:20px;
    margin-bottom:6px;
}

.section-header p{
    color:#64748b;
    font-size:14px;
}

/* SUBJECT CARD */

.subject-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(300px,1fr));
    gap:16px;
    margin-bottom:20px;
}

.subject-card{
    background:white;
    border:1px solid #e2e8f0;
    border-radius:18px;
    padding:18px;
    display:flex;
    align-items:center;
    gap:14px;
    transition:.2s;
}

.subject-card:hover{
    background:#f8fbff;
    border-color:#bfdbfe;
}

.subject-card input{
    width:20px;
    height:20px;
}

.subject-info h3{
    font-size:17px;
    margin-bottom:4px;
}

.subject-info p{
    color:#64748b;
    font-size:14px;
}

/* BUTTON */

.enroll-btn{
    background:#2563eb;
    color:white;
    border:none;
    padding:14px 24px;
    border-radius:14px;
    font-size:15px;
    font-weight:600;
    cursor:pointer;
    font-family:'Poppins',sans-serif;
}

.enroll-btn:hover{
    background:#1d4ed8;
}

/* TABLE */

.table-container{
    overflow-x:auto;
    border-radius:18px;
}

.subject-table{
    width:100%;
    border-collapse:collapse;
    overflow:hidden;
    border-radius:18px;
}

.subject-table thead tr{
    background:linear-gradient(135deg,#2563eb,#3b82f6);
}

.subject-table th{
    padding:18px;
    color:white;
    font-size:15px;
    font-weight:600;
    text-align:center;
}

.subject-table td{
    padding:18px;
    text-align:center;
    border-bottom:1px solid #edf2f7;
    font-size:15px;
    background:white;
}

.subject-table tbody tr:hover{
    background:#f8fbff;
}

.empty-row{
    color:#64748b;
}

.remove-btn{
    color:#ef4444;
    text-decoration:none;
    font-weight:600;
}

.remove-btn:hover{
    color:#dc2626;
}

/* RESPONSIVE */

@media(max-width:768px){

    .top-bar{
        flex-direction:column;
        gap:16px;
    }

    .subject-grid{
        grid-template-columns:1fr;
    }

}

</style>

</head>

<body>

<div class="container">

    <!-- TOP -->
    <div class="top-bar">

        <div>
            <h1><?php echo $student['name']; ?></h1>

            <p>
                Student ID:
                <span style="color:#2563eb;font-weight:600;">
                    <?php echo $student['student_id']; ?>
                </span>
            </p>
        </div>

        <a href="student_admin.php" class="back-btn">
            Back
        </a>

    </div>

    <!-- ENROLL SUBJECT -->
    <div class="section">

        <div class="section-header">
            <h2>Enroll in Subjects</h2>
            <p>Select the subjects you want to enroll in.</p>
        </div>

        <form method="POST">

            <div class="subject-grid">

            <?php while($row = $subjects->fetch_assoc()){ ?>

                <label class="subject-card">

                    <input
                        type="checkbox"
                        name="subject_ids[]"
                        value="<?php echo $row['subject_id']; ?>">

                    <div class="subject-info">
                        <h3><?php echo $row['subject_id']; ?></h3>
                        <p><?php echo $row['subject_name']; ?></p>
                    </div>

                </label>

            <?php } ?>

            </div>

            <button type="submit" name="add_subject" class="enroll-btn">
                Enroll Selected Subjects
            </button>

        </form>

    </div>

    <!-- ENROLLED SUBJECTS -->
    <div class="section">

        <div class="section-header">
            <h2>Enrolled Subjects</h2>
            <p>Manage your enrolled subjects below.</p>
        </div>

        <div class="table-container">

            <table class="subject-table">

                <thead>
                    <tr>
                        <th>Subject ID</th>
                        <th>Subject Name</th>
                        <th>Faculty</th>
                        <th>Lecturer</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>

                <?php if($enrolled && $enrolled->num_rows > 0){ ?>

                    <?php while($row = $enrolled->fetch_assoc()){ ?>
                    <tr>
                        <td><?php echo $row['subject_id']; ?></td>
                        <td><?php echo $row['subject_name']; ?></td>
                        <td><?php echo $row['faculty']; ?></td>
                        <td><?php echo $row['lecturer']; ?></td>
                        <td>
                            <a href="subject_view.php?student_id=<?php echo $student_id; ?>&remove=<?php echo $row['subject_id']; ?>"
                                class="remove-btn"
                                onclick="return confirm('Remove subject?')">
                                Remove
                            </a>
                        </td>
                    </tr>
                    <?php } ?>

                <?php } else { ?>

                    <tr>
                        <td colspan="5" class="empty-row">
                            No enrolled subjects.
                        </td>
                    </tr>

                <?php } ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

</body>
</html>