import os
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"

import cv2
import json
import math
import time
import numpy as np
import mediapipe as mp
import mysql.connector
import base64
import warnings
warnings.filterwarnings("ignore")

from datetime import datetime
from mtcnn import MTCNN
from keras_facenet import FaceNet
from flask import Flask, request, jsonify

# ==========================================
# FLASK APP
# ==========================================
app = Flask(__name__)

# ==========================================
# SETTINGS
# ==========================================
BASE_DIR      = os.path.dirname(os.path.abspath(__file__))
SAVE_FILE     = os.path.join(BASE_DIR, "face_database.json")
SPOOF_LOG     = os.path.join(BASE_DIR, "spoof_log.json")

THRESHOLD     = 0.50
DB_RELOAD_SEC = 30

# ==========================================
# SPOOF DETECTION THRESHOLDS
# Calibrated from 48 real phone-camera captures.
#
# To tighten (reject more):  lower BLUR_MIN / lower GLARE_MAX
# To loosen (reject less):   raise BLUR_MIN / raise GLARE_MAX
# ==========================================
# Layer 1 — Texture (flat printed photo)
# Fails ONLY if BOTH blur AND gradient are low together.
# Avoids blocking legitimately blurry selfies (motion/dim light).
BLUR_MIN       = 50.0    # Laplacian variance. Flat photo: ~25, real face: 13-639
GRAD_MIN       = 15.0    # Gradient mean. Flat photo: ~12, blurry real face: >15
LBP_STD_MIN    = 0.15    # kept for reference, not used in fail condition

# Layer 2 — Frequency domain (effectively disabled)
# Phone JPEG compression makes real faces score same range as spoofs.
# Setting very low so it never triggers false positives.
FREQ_RATIO_MIN = 0.10

# Layer 3 — Colour naturalness
SAT_MIN        = 15.0    # mean HSV saturation. Printed photo often <15
SAT_MAX        = 240.0
BRIGHT_MIN     = 40.0
BRIGHT_MAX     = 230.0

# Layer 4 — Glare / device detection
RECT_AREA_MIN  = 0.12    # quadrilateral occupying >12% → held device
GLARE_MAX      = 0.20    # >20% very bright pixels → ID/passport photo or screen
                         # Real face max observed: 0.15 | ID photo: 0.48

# How many layers must fail to mark as spoof
SPOOF_FLAG_THRESHOLD = 1   # ANY single layer fail → SPOOF

# ==========================================
# LOAD MODELS ONCE
# ==========================================
print("[startup] Loading MTCNN...")
detector = MTCNN()

print("[startup] Loading FaceNet...")
embedder = FaceNet()

print("[startup] Loading MediaPipe...")
mp_face   = mp.solutions.face_mesh
face_mesh = mp_face.FaceMesh(
    max_num_faces=1,
    refine_landmarks=True,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

LEFT_EYE  = 33
RIGHT_EYE = 263
NOSE      = 1

print("[startup] All models loaded. Server ready.")

# ==========================================
# FACE DATABASE
# ==========================================
_db_cache     = []
_db_matrix    = None
_db_ids       = []
_db_loaded_at = 0.0

def load_database():
    global _db_cache, _db_matrix, _db_ids, _db_loaded_at

    now = time.time()
    if now - _db_loaded_at < DB_RELOAD_SEC and _db_matrix is not None:
        return

    if not os.path.exists(SAVE_FILE):
        _db_cache, _db_matrix = [], np.empty((0, 512), dtype=np.float32)
        _db_ids, _db_loaded_at = [], now
        return

    with open(SAVE_FILE, "r", encoding="utf-8") as f:
        _db_cache = json.load(f)

    if not _db_cache:
        _db_matrix = np.empty((0, 512), dtype=np.float32)
        _db_ids, _db_loaded_at = [], now
        return

    vecs, ids = [], []
    for person in _db_cache:
        emb  = np.array(person["average_embedding"], dtype=np.float32)
        norm = np.linalg.norm(emb)
        if norm > 0:
            emb = emb / norm
        vecs.append(emb)
        ids.append(person["student_id"])

    _db_matrix    = np.stack(vecs, axis=0)
    _db_ids       = ids
    _db_loaded_at = now
    print(f"[db] Loaded {len(_db_ids)} faces.")


# ==========================================
# COSINE MATCH
# ==========================================
def match_face(emb):
    if _db_matrix is None or len(_db_ids) == 0:
        return None, -1
    scores     = _db_matrix @ emb
    best_idx   = int(np.argmax(scores))
    best_score = float(scores[best_idx])
    if best_score >= THRESHOLD:
        return _db_ids[best_idx], best_score
    return None, best_score


# ==========================================
# EMBEDDING
# ==========================================
def get_embedding(frame):
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    try:
        faces = detector.detect_faces(rgb)
    except Exception:
        return None
    if not faces:
        return None
    face = max(faces, key=lambda f: f["confidence"])
    if face.get("confidence", 0) < 0.90:
        return None
    x, y, w, h = face["box"]
    x, y = max(0, x), max(0, y)
    crop = frame[y:y+h, x:x+w]
    if crop.size == 0:
        return None
    try:
        face_rgb = cv2.cvtColor(crop, cv2.COLOR_BGR2RGB)
        face_rgb = cv2.resize(face_rgb, (160, 160))
        face_rgb = np.expand_dims(face_rgb, axis=0)
        emb  = embedder.embeddings(face_rgb)[0]
        norm = np.linalg.norm(emb)
        if norm == 0:
            return None
        return emb / norm
    except Exception:
        return None


# ==========================================
# LIVENESS CHECK  (original — unchanged)
# ==========================================
def check_liveness(frame):
    rgb    = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    result = face_mesh.process(rgb)
    if not result.multi_face_landmarks:
        return False

    h, w, _ = frame.shape
    lm = result.multi_face_landmarks[0].landmark
    le = (int(lm[LEFT_EYE].x*w),  int(lm[LEFT_EYE].y*h))
    re = (int(lm[RIGHT_EYE].x*w), int(lm[RIGHT_EYE].y*h))
    no = (int(lm[NOSE].x*w),      int(lm[NOSE].y*h))

    checks_passed = 0
    total_checks  = 0

    eye_distance   = math.hypot(re[0]-le[0], re[1]-le[1])
    nose_to_left   = math.hypot(no[0]-le[0], no[1]-le[1])
    nose_to_right  = math.hypot(no[0]-re[0], no[1]-re[1])
    symmetry_ratio = nose_to_left / (nose_to_right + 1e-6)

    total_checks += 1
    if 0.7 <= symmetry_ratio <= 1.4:
        checks_passed += 1

    gray   = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    face_x = max(0, min(le[0], re[0]) - int(eye_distance * 0.2))
    face_y = max(0, min(le[1], re[1]) - int(eye_distance * 0.3))
    face_w = min(w - face_x, int(eye_distance * 2.5))
    face_h = min(h - face_y, int(eye_distance * 3))

    face_region = None
    if face_w > 20 and face_h > 20:
        face_region   = gray[face_y:face_y+face_h, face_x:face_x+face_w]
        laplacian_var = cv2.Laplacian(face_region, cv2.CV_64F).var()
        total_checks += 1
        if 30 <= laplacian_var <= 800:
            checks_passed += 1

    edges        = cv2.Canny(gray, 50, 150)
    edge_density = np.sum(edges > 0) / (w * h)
    total_checks += 1
    if 0.01 <= edge_density <= 0.12:
        checks_passed += 1

    hsv        = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    saturation = np.mean(hsv[:, :, 1])
    brightness = np.mean(hsv[:, :, 2])
    total_checks += 1
    if 20 <= saturation <= 220 and 40 <= brightness <= 220:
        checks_passed += 1

    left_eye_region  = gray[max(0, le[1]-8):le[1]+8, max(0, le[0]-8):le[0]+8]
    right_eye_region = gray[max(0, re[1]-8):re[1]+8, max(0, re[0]-8):re[0]+8]
    if left_eye_region.size > 0 and right_eye_region.size > 0:
        left_max  = np.max(left_eye_region)
        right_max = np.max(right_eye_region)
        face_avg  = np.mean(gray[max(0, face_y):face_y+face_h,
                                  max(0, face_x):face_x+face_w])
        total_checks += 1
        if max(left_max, right_max) > face_avg + 25:
            checks_passed += 1

    if face_region is not None:
        sobel_x  = cv2.Sobel(face_region, cv2.CV_64F, 1, 0, ksize=3)
        sobel_y  = cv2.Sobel(face_region, cv2.CV_64F, 0, 1, ksize=3)
        grad_std = np.std(np.sqrt(sobel_x**2 + sobel_y**2))
        total_checks += 1
        if 8 <= grad_std <= 60:
            checks_passed += 1

        try:
            f_transform     = np.fft.fft2(face_region)
            mag             = np.abs(f_transform)
            high_freq       = mag[mag > np.percentile(mag, 85)]
            high_freq_ratio = np.sum(high_freq) / (np.sum(mag) + 1e-6)
            total_checks += 1
            if 0.03 <= high_freq_ratio <= 0.30:
                checks_passed += 1
        except Exception:
            pass

    v_channel  = hsv[:, :, 2]
    _, binary  = cv2.threshold(
        v_channel, np.percentile(v_channel, 90), 255, cv2.THRESH_BINARY
    )
    contours, _ = cv2.findContours(
        binary.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
    )
    large_reflections = sum(
        1 for c in contours if cv2.contourArea(c) > (w * h) * 0.015
    )
    total_checks += 1
    if large_reflections <= 3:
        checks_passed += 1

    return checks_passed >= (total_checks * 0.7)


# ==========================================
# SPOOF DETECTION  — 4-layer analysis
#
# Layer 1: Texture analysis (whole image)
#   Catches flat printed photos and low-quality
#   screen captures.
#
# Layer 2: Frequency domain
#   Catches uniform patterns from printed paper
#   and moire patterns from screen displays.
#
# Layer 3: Colour naturalness
#   Catches overly saturated screen displays or
#   washed-out print colours.
#
# Layer 4: Device/frame detection
#   Catches phone/tablet being held, screen glare.
#
# If >= SPOOF_FLAG_THRESHOLD layers fail → SPOOF
# ==========================================

def _layer1_texture(gray):
    """
    Texture check for flat printed photos / ID photos.
    Fails ONLY when BOTH Laplacian blur AND gradient mean are low.
    This avoids blocking legitimately blurry selfie captures while
    still catching flat passport-style photos and printed sheets.
    Returns (passed: bool, details: dict)
    """
    # 1a. Laplacian variance — overall sharpness
    lap = float(cv2.Laplacian(gray, cv2.CV_64F).var())

    # 1b. Mean gradient magnitude — edge strength
    sx        = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
    sy        = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
    grad_mean = float(np.mean(np.sqrt(sx**2 + sy**2)))

    # 1c. Local texture variance spread (kept for logging only)
    h, w   = gray.shape
    step   = 40
    stds   = []
    for y in range(0, h - step, step):
        for x in range(0, w - step, step):
            block = gray[y:y+step, x:x+step].astype(float)
            stds.append(float(np.std(block)))
    lbp_std = float(np.std(stds)) if stds else 0.0

    # Fail ONLY if BOTH blur AND gradient are below threshold
    # (flat photo: blur~25 grad~12 | blurry real face: blur~13 grad~25)
    passed = not (lap < BLUR_MIN and grad_mean < GRAD_MIN)

    return passed, {
        "laplacian": round(lap, 2),
        "grad_mean": round(grad_mean, 2),
        "lbp_std":   round(lbp_std, 4),
    }


def _layer2_frequency(gray):
    """
    Fourier high/low frequency energy ratio.
    Real faces have rich high-frequency content
    (skin pores, hair, micro-textures).
    Printed photos and screens are frequency-sparse.
    Returns (passed: bool, details: dict)
    """
    try:
        f      = np.fft.fft2(gray.astype(np.float32))
        fshift = np.fft.fftshift(f)
        mag    = np.abs(fshift)
        hh, ww = mag.shape
        cy, cx = hh // 2, ww // 2

        y_idx, x_idx = np.ogrid[:hh, :ww]
        dist = np.sqrt((x_idx - cx)**2 + (y_idx - cy)**2)

        low_energy  = float(np.sum(mag[dist < 30]))
        high_energy = float(np.sum(mag[dist > 80]))
        ratio       = high_energy / (low_energy + 1e-6)
        passed      = ratio >= FREQ_RATIO_MIN
    except Exception:
        ratio, passed = 0.0, False

    return passed, {"freq_ratio": round(ratio, 4)}


def _layer3_colour(frame):
    """
    Colour naturalness check in HSV space.
    Screens tend to be over-bright or oversaturated.
    Printed photos are often washed out or off-colour.
    Returns (passed: bool, details: dict)
    """
    hsv        = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    saturation = float(np.mean(hsv[:, :, 1]))
    brightness = float(np.mean(hsv[:, :, 2]))

    passed = (SAT_MIN <= saturation <= SAT_MAX and
              BRIGHT_MIN <= brightness <= BRIGHT_MAX)

    return passed, {
        "saturation": round(saturation, 2),
        "brightness": round(brightness, 2),
    }


def _layer4_device(gray, frame_h, frame_w):
    """
    Detect a held phone/tablet/printed photo frame
    and screen glare hotspots.
    Returns (passed: bool, details: dict)
    """
    # Glare
    glare_ratio = float(np.sum(gray > 240)) / gray.size

    # Rectangle contour (device outline)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    edges   = cv2.Canny(blurred, 50, 150)
    kernel  = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    edges   = cv2.dilate(edges, kernel, iterations=1)
    contours, _ = cv2.findContours(
        edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
    )
    best_rect = 0.0
    for cnt in contours:
        peri   = cv2.arcLength(cnt, True)
        approx = cv2.approxPolyDP(cnt, 0.02 * peri, True)
        if len(approx) == 4:
            x, y, rw, rh = cv2.boundingRect(approx)
            aspect = rw / rh if rh > 0 else 0
            area_f = (rw * rh) / (frame_h * frame_w)
            if 0.4 < aspect < 2.5 and area_f > RECT_AREA_MIN:
                best_rect = max(best_rect, area_f)

    passed = (glare_ratio <= GLARE_MAX and
              best_rect   <= RECT_AREA_MIN)

    return passed, {
        "glare_ratio": round(glare_ratio, 4),
        "rect_area":   round(best_rect,   4),
    }


def check_spoof(frame):
    """
    Run all 4 layers. Returns dict:
        is_spoof   : bool
        layers     : dict  per-layer pass/fail + raw scores
        flags      : list  of failed layer names
        message    : str
    """
    gray   = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    h, w   = gray.shape

    l1_ok, l1_scores = _layer1_texture(gray)
    l2_ok, l2_scores = _layer2_frequency(gray)
    l3_ok, l3_scores = _layer3_colour(frame)
    l4_ok, l4_scores = _layer4_device(gray, h, w)

    layers = {
        "texture":   {"passed": l1_ok, **l1_scores},
        "frequency": {"passed": l2_ok, **l2_scores},
        "colour":    {"passed": l3_ok, **l3_scores},
        "device":    {"passed": l4_ok, **l4_scores},
    }

    flags = [name for name, data in layers.items() if not data["passed"]]
    is_spoof = len(flags) >= SPOOF_FLAG_THRESHOLD

    if is_spoof:
        msg = f"Proxy attendance detected — failed layers: {', '.join(flags)}."
    else:
        msg = "Anti-spoof check passed."

    print(f"[spoof] layers={layers} flags={flags} is_spoof={is_spoof}")

    return {
        "is_spoof": is_spoof,
        "layers":   layers,
        "flags":    flags,
        "message":  msg,
    }


# ==========================================
# SPOOF LOG
# ==========================================
def log_spoof(student_id, subject_id, spoof_result, mode):
    entry = {
        "timestamp":  datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "student_id": student_id,
        "subject_id": subject_id,
        "mode":       mode,
        "flags":      spoof_result["flags"],
        "layers":     spoof_result["layers"],
        "message":    spoof_result["message"],
    }
    log = []
    if os.path.exists(SPOOF_LOG):
        with open(SPOOF_LOG, "r") as f:
            try:
                log = json.load(f)
            except Exception:
                log = []
    log.append(entry)
    with open(SPOOF_LOG, "w") as f:
        json.dump(log, f, indent=2)
    print(f"[spoof] Logged: student={student_id} flags={spoof_result['flags']}")


# ==========================================
# DB HELPERS
# ==========================================
def get_db_conn():
    return mysql.connector.connect(
        host="localhost", user="root",
        password="", database="attendance_fyp"
    )

def check_enrollment(student_id, subject_id):
    conn = get_db_conn()
    cur  = conn.cursor()
    cur.execute(
        "SELECT id FROM student_subject WHERE student_id=%s AND subject_id=%s",
        (student_id, subject_id)
    )
    found = cur.fetchone() is not None
    cur.close(); conn.close()
    return found

def check_duplicate(student_id, subject_id, date):
    conn = get_db_conn()
    cur  = conn.cursor()
    cur.execute(
        "SELECT id FROM attendance WHERE student_id=%s AND subject_id=%s AND attend_date=%s",
        (student_id, subject_id, date)
    )
    found = cur.fetchone() is not None
    cur.close(); conn.close()
    return found

def insert_attendance(student_id, subject_id, date, mode, accuracy):
    conn = get_db_conn()
    cur  = conn.cursor()
    now  = datetime.now().strftime("%H:%M:%S")
    cur.execute(
        """INSERT INTO attendance
           (student_id, subject_id, attend_date, attend_time, status, mode, face_accuracy)
           VALUES (%s,%s,%s,%s,%s,%s,%s)""",
        (student_id, subject_id, date, now, "Present", mode, round(accuracy * 100, 2))
    )
    conn.commit()
    cur.close(); conn.close()


# ==========================================
# IMAGE HELPERS
# ==========================================
def decode_image(b64_string):
    b64_string = b64_string.replace("data:image/jpeg;base64,", "")
    b64_string = b64_string.replace(" ", "+")
    raw = base64.b64decode(b64_string)
    arr = np.frombuffer(raw, dtype=np.uint8)
    return cv2.imdecode(arr, cv2.IMREAD_COLOR)

def save_image(frame, folder, student_id, suffix=""):
    if not os.path.isdir(folder):
        os.makedirs(folder, exist_ok=True)
    ts       = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = os.path.join(folder, f"{student_id}_{ts}{suffix}.jpg")
    cv2.imwrite(filename, frame)
    return filename


# ==========================================
# ROUTE: /verify  (Online)
# ==========================================
@app.route("/verify", methods=["POST"])
def verify_online():
    try:
        load_database()

        subject_id = request.form.get("subject_id", "")
        date       = request.form.get("date", "")
        image_b64  = request.form.get("image", "")

        if not image_b64:
            return jsonify({"status": "ERROR", "message": "No image."})

        frame = decode_image(image_b64)
        if frame is None:
            return jsonify({"status": "ERROR", "message": "Invalid image."})

        # ── 1. Face embedding ────────────────────────────────────────────
        emb = get_embedding(frame)
        if emb is None:
            return jsonify({"status": "UNKNOWN", "message": "Face not recognized."})

        # ── 2. Match ──────────────────────────────────────────────────────
        student_id, score = match_face(emb)
        if student_id is None:
            return jsonify({"status": "UNKNOWN", "message": "Face not recognized."})

        # ── 3. Enrollment ─────────────────────────────────────────────────
        if not check_enrollment(student_id, subject_id):
            return jsonify({"status": "NOT_ENROLLED",
                            "message": "You are not enrolled in this subject."})

        # ── 4. Duplicate ──────────────────────────────────────────────────
        if check_duplicate(student_id, subject_id, date):
            return jsonify({"status": "ALREADY", "message": "Attendance already taken."})

        # ── 5. Insert ─────────────────────────────────────────────────────
        try:
            insert_attendance(student_id, subject_id, date, "Online", score)
        except Exception as e:
            return jsonify({"status": "ERROR", "message": f"insert_attendance: {e}"})

        # ── 6. Save image ─────────────────────────────────────────────────
        img_path = save_image(frame, "uploads", student_id)
        try:
            conn = get_db_conn()
            cur  = conn.cursor()
            cur.execute(
                """UPDATE attendance SET face_image=%s
                   WHERE student_id=%s AND subject_id=%s AND attend_date=CURDATE()
                   ORDER BY id DESC LIMIT 1""",
                (img_path, student_id, subject_id)
            )
            conn.commit(); cur.close(); conn.close()
        except Exception:
            pass

        return jsonify({
            "status":     "SUCCESS",
            "student_id": student_id,
            "score":      round(score, 4),
            "message":    f"Attendance Success: {student_id}"
        })

    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"status": "ERROR", "message": f"/verify crashed: {e}"})




# ==========================================
# ROUTE: /verify_physical  (Physical)
# ==========================================
@app.route("/verify_physical", methods=["POST"])
def verify_physical():
    try:
        load_database()

        subject_id = request.form.get("subject_id", "")
        date       = request.form.get("date", "")
        image_b64  = request.form.get("image", "")

        if not image_b64:
            return jsonify({"status": "ERROR", "message": "No image."})

        frame = decode_image(image_b64)
        if frame is None:
            return jsonify({"status": "ERROR", "message": "Invalid image."})

        # ── 1. Face embedding ────────────────────────────────────────────
        emb = get_embedding(frame)
        if emb is None:
            return jsonify({"status": "UNKNOWN", "message": "Face not recognized."})

        # ── 2. Match ──────────────────────────────────────────────────────
        student_id, score = match_face(emb)
        if student_id is None:
            return jsonify({"status": "UNKNOWN", "message": "Face not recognized."})

        # ── 3. Enrollment ─────────────────────────────────────────────────
        if not check_enrollment(student_id, subject_id):
            return jsonify({"status": "NOT_ENROLLED",
                            "message": "You are not enrolled in this subject."})

        # ── 4. Duplicate ──────────────────────────────────────────────────
        if check_duplicate(student_id, subject_id, date):
            return jsonify({"status": "ALREADY", "message": "Attendance already taken."})

        # ── Return to PHP for INSERT (unchanged) ─────────────────────────
        return jsonify({
            "status":     "OK",
            "student_id": student_id,
            "score":      round(score, 4)
        })

    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"status": "ERROR", "message": f"/verify_physical crashed: {e}"})


# ==========================================
# ROUTE: /spoof_log  (admin review page)
# ==========================================
@app.route("/spoof_log", methods=["GET"])
def get_spoof_log():
    if not os.path.exists(SPOOF_LOG):
        return jsonify([]), 200
    with open(SPOOF_LOG, "r") as f:
        try:
            log = json.load(f)
        except Exception:
            log = []
    return jsonify(log[-50:][::-1]), 200


# ==========================================
# MAIN
# ==========================================
if __name__ == "__main__":
    load_database()
    app.run(host="127.0.0.1", port=5001, threaded=False)