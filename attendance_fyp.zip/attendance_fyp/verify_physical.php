<?php
include "connection.php";
date_default_timezone_set("Asia/Kuala_Lumpur");

$image      = $_POST['image']      ?? '';
$subject_id = $_POST['subject_id'] ?? '';
$lat        = $_POST['lat']        ?? '';
$lng        = $_POST['lng']        ?? '';

/* =========================
   VALIDATION
========================= */

if ($lat == '' || $lng == '') {
    exit("Location not detected.");
}

if ($image == '') {
    exit("No image.");
}

/* =========================
   TIME VALIDATION
========================= */

$res_time = $conn->query("
SELECT start_time, end_time
FROM timetable
WHERE subject_id='$subject_id'
AND class_date = CURDATE()
LIMIT 1
");

if ($res_time && $res_time->num_rows > 0) {

    $time_row = $res_time->fetch_assoc();
    $today    = date("Y-m-d");
    $now      = strtotime(date("Y-m-d H:i:s"));
    $start    = strtotime($today . " " . $time_row['start_time']);
    $end      = strtotime($today . " " . $time_row['end_time']);

    if ($now < $start || $now > $end) {
        exit("QR Code expired. Attendance only allowed during class time.");
    }

} else {
    exit("No timetable found.");
}

/* =========================
   GET CLASSROOM LOCATION
========================= */

$res = $conn->query("
SELECT latitude, longitude, radius
FROM classroom_location
WHERE subject_id='$subject_id'
ORDER BY id DESC
LIMIT 1
");

if (!$res || $res->num_rows == 0) {
    exit("Classroom location not found.");
}

$row            = $res->fetch_assoc();
$classroom_lat  = $row['latitude'];
$classroom_lng  = $row['longitude'];
$allowed_radius = $row['radius'];

/* =========================
   HAVERSINE FORMULA
========================= */

function distanceMeters($lat1, $lon1, $lat2, $lon2) {
    $earth = 6371000;
    $dLat  = deg2rad($lat2 - $lat1);
    $dLon  = deg2rad($lon2 - $lon1);
    $a     = sin($dLat/2)*sin($dLat/2)
           + cos(deg2rad($lat1))*cos(deg2rad($lat2))
           * sin($dLon/2)*sin($dLon/2);
    return $earth * 2 * atan2(sqrt($a), sqrt(1-$a));
}

/* =========================
   DISTANCE CHECK
========================= */

$distance = distanceMeters($lat, $lng, $classroom_lat, $classroom_lng);

if ($distance > $allowed_radius) {
    exit(
        "You are not inside classroom.<br>" .
        "Distance: " . round($distance, 2) . " meters"
    );
}

/* =========================
   CALL FLASK FACE API
   Returns JSON: { status, student_id, score }
   status OK means: enrolled + not duplicate + face matched
   PHP then does the INSERT (physical flow)
========================= */

$date    = date("Y-m-d");
$api_url = "http://127.0.0.1:5001/verify_physical";

$ch = curl_init($api_url);
curl_setopt($ch, CURLOPT_POST,           true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT,        30);
curl_setopt($ch, CURLOPT_POSTFIELDS, [
    "image"      => $image,
    "subject_id" => $subject_id,
    "date"       => $date,
]);

$response = curl_exec($ch);
$curl_err  = curl_error($ch);
curl_close($ch);

if ($curl_err || !$response) {
    exit("Face API unavailable. Please try again.");
}

$data   = json_decode($response, true);
$status = strtoupper($data['status'] ?? '');
$face_accuracy = $data['score'] ?? 0;
$face_accuracy = round($face_accuracy * 100, 2);

/* =========================
   HANDLE API RESULT
========================= */

switch ($status) {

    case 'UNKNOWN':
        exit("Face not recognized.");

    case 'NOT_LIVE':
        exit("Liveness check failed.");

    case 'ALREADY':
        exit("Attendance already taken.");

    case 'NOT_ENROLLED':
        exit("
        <div style='color:red;font-weight:bold'>
        You are not enrolled in this subject.
        </div>
        ");

    case 'ERROR':
        exit($data['message'] ?? "An error occurred. Please try again.");

    case 'OK':
        // Proceed to INSERT below
        $student_id = preg_replace("/[^a-zA-Z0-9]/", "", $data['student_id']);
        break;

    default:
        exit("Unexpected response. Please try again.");
}

/* =========================
   INSERT ATTENDANCE
========================= */

$current_time = date("H:i:s");

$conn->query("
INSERT INTO attendance
(student_id, subject_id, attend_date, attend_time, status, mode, face_accuracy)
VALUES
('$student_id', '$subject_id', CURDATE(), '$current_time', 'Present', 'Physical','$face_accuracy')
");

/* =========================
   SAVE FINAL IMAGE
========================= */
if (!is_dir("uploads_physical")) {
    mkdir("uploads_physical", 0777, true);
}

$image_b64 = $_POST['image'];

$image_b64 = str_replace(
    "data:image/jpeg;base64,",
    "",
    $image_b64
);

$image_b64 = str_replace(" ", "+", $image_b64);

$raw = base64_decode($image_b64);

$filename =
    $student_id . "_" .
    date("Ymd_His") .
    ".jpg";

$final_filename =
    "uploads_physical/" . $filename;

file_put_contents($final_filename, $raw);

/* =========================
   SUCCESS
========================= */

echo
    "Attendance Success<br>" .
    "Student ID: " . $student_id .
    "<br>Face Accuracy: " . round($face_accuracy, 2) . "%" .
    "<br>Distance: " . round($distance, 2) . " meters";

exit();
?>