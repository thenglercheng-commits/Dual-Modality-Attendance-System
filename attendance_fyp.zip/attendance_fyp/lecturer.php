<?php
session_start();
include "connection.php";

$user_id = $_SESSION['user_id'];

$lecturer_query = mysqli_query($conn,"
SELECT lecturer_id
FROM lecturers
WHERE id='$user_id'
");

$lecturer = mysqli_fetch_assoc($lecturer_query);

$lecturer_name = $_SESSION['name'];

$today = date("Y-m-d");

/* =========================
   TOTAL SUBJECTS
========================= */

$subject_query = mysqli_query($conn,"
SELECT COUNT(*) AS total_subject
FROM subjects
WHERE lecturer='$lecturer_name'
");

$subject_row = mysqli_fetch_assoc($subject_query);

$total_subject = $subject_row['total_subject'];


/* =========================
   TOTAL STUDENTS
========================= */

$student_query = mysqli_query($conn,"
SELECT COUNT(DISTINCT ss.student_id) AS total_students
FROM student_subject ss
INNER JOIN subjects s
ON ss.subject_id = s.subject_id
WHERE s.lecturer='$lecturer_name'
");

$student_row = mysqli_fetch_assoc($student_query);

$total_students = $student_row['total_students'];


/* =========================
   CLASSES TODAY
========================= */

$class_query = mysqli_query($conn,"
SELECT COUNT(*) AS total_class
FROM timetable t
INNER JOIN subjects s
ON t.subject_id = s.subject_id
WHERE s.lecturer='$lecturer_name'
AND t.class_date='$today'
");

$class_row = mysqli_fetch_assoc($class_query);

$total_class = $class_row['total_class'];


/* =========================
   UPCOMING CLASSES
========================= */

$upcoming_query = mysqli_query($conn,"
SELECT t.*, s.subject_name
FROM timetable t
INNER JOIN subjects s
ON t.subject_id = s.subject_id
WHERE s.lecturer='$lecturer_name'
AND t.class_date >= CURDATE()
ORDER BY t.class_date ASC, t.start_time ASC
LIMIT 5
");9
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Lecturer Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    background:#eaf6ff;
    display:flex;
}

/* Sidebar */
.sidebar{
    width:260px;
    min-height:100vh;
    background:white;
    padding:25px;
    position:fixed;
    left:0;
    top:0;
}

.brand{
    font-size:20px;
    font-weight:bold;
    margin-bottom:35px;
}

.logo-box{
    width:55px;
    height:55px;
    background:#2563eb;
    border-radius:18px;
    display:flex;
    align-items:center;
    justify-content:center;
    color:white;
    font-size:24px;
    margin-bottom:20px;
}

.menu{
    margin-top:20px;
}

.menu a{
    display:flex;
    align-items:center;
    gap:12px;
    padding:14px 16px;
    margin-bottom:10px;
    border-radius:12px;
    text-decoration:none;
    color:black;
    transition:0.2s;
    font-size:15px;
}

.menu a:hover{
    background:#f1f5ff;
}

.menu a.active{
    background:#2563eb;
    color:white;
}

/* Main */
.main{
    margin-left:260px;
    padding:35px;
    width:calc(100% - 260px);
}

/* Header */
.top{
    background:white;
    border-radius:18px;
    padding:25px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    box-shadow:0 6px 15px rgba(0,0,0,.06);
}

.top h1{
    font-size:24px;
    margin-bottom:10px;
}

.top p{
    color:#64748b;
}

.top-right{
    display:flex;
    gap:18px;
    align-items:center;
}

.logout-btn{
    background:#2563eb;
    color:white;
    text-decoration:none;
    padding:12px 22px;
    border-radius:12px;
    font-weight:600;
}

/* Stats */
.cards{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
    gap:20px;
    margin-top:25px;
}

.card{
    background:white;
    padding:25px;
    border-radius:18px;
    box-shadow:0 6px 15px rgba(0,0,0,.06);
}

.blue{
    background:#edf4ff;
    color:#2563eb;
}

.green{
    background:#ebfff0;
    color:#16a34a;
}

.purple{
    background:#f6edff;
    color:#9333ea;
}

.card h3{
    color:#64748b;
    margin-bottom:10px;
}

.card p{
    font-size:42px;
    font-weight:700;
}

/* Overview Section */
.section{
    margin-top:25px;
    background:white;
    border-radius:24px;
    padding:30px;
    box-shadow:0 10px 25px rgba(0,0,0,.04);
}

.section h2{
    color:#0f1f4a;
    margin-bottom:10px;
}

.section p{
    color:#64748b;
}
</style>
</head>

<body>

<div class="sidebar">
    <div class="brand">Lecturer Panel</div>

    <div class="menu">
        <a href="lecturer.php" class="active">Overview</a>
        <a href="subject_lecturer.php">Subject</a>
        <a href="attendance_lecturer.php">Attendance</a>
        <a href="timetable_lecturer.php">Timetable</a>
    </div>
</div>

<div class="main">

    <div class="top">
        <div>
            <h1>Welcome, <?php echo $_SESSION['name']; ?></h1>
            <p>Manage your lecturer dashboard here.</p>
        </div>

        <div class="top-right">
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>
    </div>

    <div class="cards">

    <div class="card">
        <div>
            <h3>Total Subjects</h3>
            <p><?php echo $total_subject; ?></p>
        </div>
    </div>

    <div class="card">
        <div>
            <h3>Total Students</h3>
            <p><?php echo $total_students; ?></p>
        </div>
    </div>

    <div class="card">
        <div>
            <h3>Classes Today</h3>
            <p><?php echo $total_class; ?></p>
        </div>
    </div>

</div>

    <div class="section">

    <h2>Upcoming Classes</h2>

    <br>

    <?php
    if(mysqli_num_rows($upcoming_query)>0){

        while($row=mysqli_fetch_assoc($upcoming_query)){
    ?>

        <div style="
            background:#f8fbff;
            padding:15px;
            border-radius:12px;
            margin-bottom:12px;
            border:1px solid #dbeafe;
        ">

            <strong>
                <?php echo $row['subject_name']; ?>
                (<?php echo $row['subject_id']; ?>)
            </strong>

            <br><br>

            Date:
            <?php echo $row['class_date']; ?>

            |

            Time:
            <?php echo date("h:i A",strtotime($row['start_time'])); ?>

            -
            <?php echo date("h:i A",strtotime($row['end_time'])); ?>

        </div>

    <?php
        }

    }else{
        echo "<p>No upcoming classes.</p>";
    }
    ?>

</div>
</div>

</div>

</body>
</html>