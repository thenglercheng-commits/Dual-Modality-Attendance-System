<?php
session_start();
include "connection.php";

if(!isset($_SESSION['name']) || $_SESSION['role'] != 'admin'){
    header("Location: login.php");
    exit();
}

$id = $_GET['id'];

if(isset($_POST['update'])){

    $date  = $_POST['class_date'];
    $start = $_POST['start_time'];
    $end   = $_POST['end_time'];

    $conn->query("
        UPDATE timetable
        SET class_date='$date',
            start_time='$start',
            end_time='$end'
        WHERE id='$id'
    ");

    header("Location: timetable_admin.php");
    exit();
}

$result = $conn->query("
SELECT timetable.*, subjects.subject_name
FROM timetable
LEFT JOIN subjects ON timetable.subject_id = subjects.subject_id
WHERE timetable.id='$id'
");

$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
<title>Edit Timetable</title>
<style>
body{
    font-family:Arial;
    background:#eaf6ff;
    padding:40px;
}
.box{
    max-width:600px;
    margin:auto;
    background:white;
    padding:30px;
    border-radius:18px;
}
input{
    width:100%;
    padding:10px;
    margin:10px 0;
    border:1px solid #ccc;
    border-radius:10px;
}
button{
    background:#2563eb;
    color:white;
    border:none;
    padding:10px 18px;
    border-radius:10px;
}
a{
    text-decoration:none;
}
</style>
</head>
<body>

<div class="box">

<h2>Edit Timetable</h2>

<p><b>Subject:</b> <?php echo $row['subject_name']; ?></p>

<form method="POST">

<label>Date</label>
<input type="date" name="class_date"
value="<?php echo $row['class_date']; ?>" required>

<label>Start Time</label>
<input type="time" name="start_time"
value="<?php echo $row['start_time']; ?>" required>

<label>End Time</label>
<input type="time" name="end_time"
value="<?php echo $row['end_time']; ?>" required>

<button type="submit" name="update">Update</button>
<a href="timetable_admin.php">Back</a>

</form>

</div>

</body>
</html>