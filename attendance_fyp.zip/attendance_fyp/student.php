<?php
session_start();
include "connection.php";

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}

// Correct student_id from session (set at login)
$student_id = $_SESSION['student_id'];
$today      = date("Y-m-d");

/* =========================
   OVERALL ATTENDANCE RATE
   Present / total sessions
   across all enrolled subjects
   from first class until today
========================= */

$total_query = mysqli_query($conn,
"SELECT COUNT(*) as total
 FROM timetable t
 JOIN student_subject ss
   ON t.subject_id = ss.subject_id
 WHERE ss.student_id = '$student_id'
 AND t.class_date <= CURDATE()");

$total_row = mysqli_fetch_assoc($total_query);
$total     = $total_row['total'];

$present_query = mysqli_query($conn,
"SELECT COUNT(*) as present
 FROM attendance
 WHERE student_id = '$student_id'
 AND status = 'Present'");

$present_row = mysqli_fetch_assoc($present_query);
$present     = $present_row['present'];

$attendance_rate = 0;
if($total > 0){
    $attendance_rate = round(($present / $total) * 100);
}

/* =========================
   TOTAL ENROLLED SUBJECTS
========================= */

$subject_query = mysqli_query($conn,
"SELECT COUNT(*) as total_subject
 FROM student_subject
 WHERE student_id = '$student_id'");

$subject_row   = mysqli_fetch_assoc($subject_query);
$total_subject = $subject_row['total_subject'];

/* =========================
   CLASSES TODAY
   Only enrolled subjects
========================= */

$class_query = mysqli_query($conn,
"SELECT COUNT(*) as total_class
 FROM timetable t
 JOIN student_subject ss
   ON t.subject_id = ss.subject_id
 WHERE ss.student_id = '$student_id'
 AND t.class_date = '$today'");

$class_row   = mysqli_fetch_assoc($class_query);
$total_class = $class_row['total_class'];

/* =========================
   TODAY SCHEDULE
   Only enrolled subjects
========================= */

$schedule_query = mysqli_query($conn,
"SELECT t.*, s.subject_name
 FROM timetable t
 JOIN subjects s
   ON t.subject_id = s.subject_id
 JOIN student_subject ss
   ON t.subject_id = ss.subject_id
 WHERE ss.student_id = '$student_id'
 AND t.class_date = '$today'
 ORDER BY t.start_time ASC");

/* =========================
   PER-SUBJECT ATTENDANCE
   For the modal popup
   All enrolled subjects with
   attendance stats from first
   class until today
========================= */

$subject_rate_query = mysqli_query($conn,
"SELECT
    s.subject_id,
    s.subject_name,
    COUNT(t.id)            AS total_classes,
    SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS attended
 FROM student_subject ss
 JOIN subjects s
   ON ss.subject_id = s.subject_id
 LEFT JOIN timetable t
   ON t.subject_id = s.subject_id
   AND t.class_date <= CURDATE()
 LEFT JOIN attendance a
   ON a.subject_id = s.subject_id
   AND a.student_id = '$student_id'
   AND a.attend_date = t.class_date
 WHERE ss.student_id = '$student_id'
 GROUP BY s.subject_id, s.subject_name
 ORDER BY s.subject_id ASC");

$subject_rates = [];
while($sr = mysqli_fetch_assoc($subject_rate_query)){
    $sr['rate'] = ($sr['total_classes'] > 0)
        ? round(($sr['attended'] / $sr['total_classes']) * 100)
        : 0;
    $subject_rates[] = $sr;
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
*{ margin:0; padding:0; box-sizing:border-box; }
body{ font-family:'Poppins',sans-serif; background:#f4f8ff; display:flex; }

/* SIDEBAR */
.sidebar{ width:260px; height:100vh; background:white; position:fixed; left:0; top:0; padding:30px 20px; border-right:1px solid #eee; }
.brand{ font-size:24px; font-weight:700; margin-bottom:40px; color:#2563eb; }
.menu a{ display:flex; align-items:center; gap:12px; padding:15px; margin-bottom:12px; border-radius:16px; text-decoration:none; color:#334155; font-weight:500; transition:.3s; }
.menu a:hover, .menu a.active{ background:#2563eb; color:white; }

/* MAIN */
.main{ margin-left:260px; width:100%; padding:30px; }

/* TOP */
.top{ background:white; padding:30px; border-radius:24px; display:flex; justify-content:space-between; align-items:center; box-shadow:0 8px 20px rgba(0,0,0,.05); }
.top h1{ font-size:28px; margin-bottom:8px; }
.top p{ color:#64748b; }
.right-top{ display:flex; align-items:center; gap:15px; }
.logout-btn{ background:#2563eb; color:white; padding:12px 20px; border-radius:12px; text-decoration:none; font-weight:600; }
.profile{ width:50px; height:50px; border-radius:50%; background:#2563eb; color:white; display:flex; align-items:center; justify-content:center; font-size:24px; text-decoration:none; }

/* CARDS */
.cards{ display:grid; grid-template-columns:repeat(auto-fit,minmax(260px,1fr)); gap:25px; margin-top:25px; }
.card{ background:white; border-radius:22px; padding:30px; box-shadow:0 8px 20px rgba(0,0,0,.05); }
.card h3{ color:#64748b; margin-bottom:12px; font-size:16px; }
.card p{ font-size:40px; font-weight:700; color:#2563eb; }
.card-clickable{ cursor:pointer; transition:.2s; border:2px solid transparent; }
.card-clickable:hover{ border-color:#2563eb; transform:translateY(-3px); box-shadow:0 12px 28px rgba(37,99,235,.15); }
.card-clickable .hint{ font-size:12px; color:#94a3b8; margin-top:8px; }

/* SECTION */
.section{ margin-top:25px; background:white; padding:30px; border-radius:24px; box-shadow:0 8px 20px rgba(0,0,0,.05); }
.section-title h2{ font-size:20px; margin-bottom:6px; }
.section-title p{ color:#64748b; font-size:14px; margin-bottom:20px; }

/* PROGRESS */
.progress{ width:100%; height:12px; background:#e2e8f0; border-radius:10px; overflow:hidden; margin-top:10px; }
.progress-fill{ height:100%; background:#2563eb; border-radius:10px; transition:width .4s; }

/* SCHEDULE */
.schedule-item{ background:#f8fbff; padding:20px; border-radius:18px; margin-bottom:15px; display:flex; justify-content:space-between; align-items:center; }
.schedule-item .time{ color:#2563eb; font-weight:700; font-size:18px; margin-bottom:4px; }
.schedule-item h3{ font-size:15px; margin-bottom:4px; }
.schedule-item p{ color:#64748b; font-size:13px; }
.badge{ background:#dbeafe; color:#2563eb; padding:8px 14px; border-radius:999px; font-size:13px; font-weight:600; }

/* ============================
   MODAL
============================ */
.modal-overlay{
    display:none;
    position:fixed;
    inset:0;
    background:rgba(0,0,0,.45);
    z-index:999;
    justify-content:center;
    align-items:center;
}
.modal-overlay.show{ display:flex; }
.modal{
    background:white;
    border-radius:24px;
    padding:36px;
    width:680px;
    max-width:95vw;
    max-height:85vh;
    overflow-y:auto;
    box-shadow:0 20px 60px rgba(0,0,0,.15);
    position:relative;
}
.modal h2{ font-size:22px; margin-bottom:6px; color:#0b1652; }
.modal .sub{ color:#64748b; font-size:14px; margin-bottom:28px; }
.modal-close{
    position:absolute;
    top:20px; right:24px;
    background:none;
    border:none;
    font-size:24px;
    cursor:pointer;
    color:#64748b;
    line-height:1;
}
.modal-close:hover{ color:#ef4444; }

/* Subject rate rows */
.sr-row{
    padding:18px 0;
    border-bottom:1px solid #eef2f7;
}
.sr-row:last-child{ border-bottom:none; }
.sr-top{ display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; }
.sr-name{ font-weight:600; font-size:15px; color:#0b1652; }
.sr-id{ font-size:12px; color:#94a3b8; margin-top:2px; }
.sr-pct{
    font-size:22px;
    font-weight:700;
}
.sr-meta{ font-size:13px; color:#64748b; margin-top:6px; }
.pct-high{ color:#16a34a; }
.pct-mid{ color:#f59e0b; }
.pct-low{ color:#ef4444; }
.bar{ width:100%; height:10px; background:#e2e8f0; border-radius:10px; overflow:hidden; }
.bar-fill{ height:100%; border-radius:10px; }
.fill-high{ background:#16a34a; }
.fill-mid{ background:#f59e0b; }
.fill-low{ background:#ef4444; }

@media(max-width:900px){
    .sidebar{ display:none; }
    .main{ margin-left:0; }
    .top{ flex-direction:column; align-items:flex-start; gap:20px; }
}
</style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <div class="brand">Student Panel</div>
    <div class="menu">
        <a href="student.php" class="active">Overview</a>
        <a href="attendance_student.php">Attendance</a>
        <a href="subject_student.php">Subject</a>
        <a href="timetable_student.php">Timetable</a>
    </div>
</div>

<!-- MAIN -->
<div class="main">

    <!-- TOP -->
    <div class="top">
        <div>
            <h1>Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?></h1>
            <p>Manage your student dashboard here.</p>
        </div>
        <div class="right-top">
            <a href="logout.php" class="logout-btn">Logout</a>
            <a href="profile_student.php" class="profile">👤</a>
        </div>
    </div>

    <!-- CARDS -->
    <div class="cards">

        <!-- ATTENDANCE RATE — clickable → modal -->
        <div class="card card-clickable" onclick="openModal()">
            <h3>Overall Attendance Rate</h3>
            <p><?php echo $attendance_rate; ?>%</p>
            <p class="hint">Click to see per-subject breakdown →</p>
        </div>

        <!-- TOTAL SUBJECTS — just a count, no click -->
        <div class="card">
            <h3>Total Enrolled Subjects</h3>
            <p><?php echo $total_subject; ?></p>
        </div>

        <!-- CLASSES TODAY — enrolled subjects only -->
        <div class="card">
            <h3>Classes Today</h3>
            <p><?php echo $total_class; ?></p>
        </div>

    </div>

    <!-- PROGRESS BAR -->
    <div class="section">
        <h3 style="margin-bottom:10px;">Attendance Progress</h3>
        <div class="progress">
            <div class="progress-fill" style="width:<?php echo $attendance_rate; ?>%"></div>
        </div>
        <p style="margin-top:12px;color:#64748b;font-size:14px;">
            Your overall attendance rate is
            <strong style="color:#2563eb;"><?php echo $attendance_rate; ?>%</strong>
            (<?php echo $present; ?> attended out of <?php echo $total; ?> sessions so far)
        </p>
    </div>

    <!-- TODAY SCHEDULE -->
    <div class="section">
        <div class="section-title">
            <h2>Today's Schedule</h2>
            <p>Your class timetable for today.</p>
        </div>
        <div class="schedule-box">
        <?php if(mysqli_num_rows($schedule_query) > 0): ?>
            <?php while($row = mysqli_fetch_assoc($schedule_query)): ?>
            <div class="schedule-item">
                <div>
                    <div class="time"><?php echo date("h:i A", strtotime($row['start_time'])); ?></div>
                    <h3><?php echo htmlspecialchars($row['subject_id']); ?>
                        — <?php echo htmlspecialchars($row['subject_name']); ?>
                    </h3>
                    <p>Ends at <?php echo date("h:i A", strtotime($row['end_time'])); ?></p>
                </div>
                <div class="badge">Upcoming</div>
            </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p style="color:#94a3b8;">No classes scheduled today.</p>
        <?php endif; ?>
        </div>
    </div>

</div>

<!-- ============================
     MODAL — per-subject rates
============================ -->
<div class="modal-overlay" id="rateModal" onclick="closeOnOverlay(event)">
    <div class="modal">

        <button class="modal-close" onclick="closeModal()">✕</button>

        <h2>Attendance by Subject</h2>
        <p class="sub">
            From the first class until today —
            <?php echo date("d M Y"); ?>
        </p>

        <?php if(count($subject_rates) > 0): ?>

            <?php foreach($subject_rates as $sr):
                $r = $sr['rate'];
                $pct_class  = $r >= 80 ? 'pct-high'  : ($r >= 60 ? 'pct-mid'  : 'pct-low');
                $fill_class = $r >= 80 ? 'fill-high'  : ($r >= 60 ? 'fill-mid' : 'fill-low');
                $absent_count = $sr['total_classes'] - $sr['attended'];
            ?>
            <div class="sr-row">
                <div class="sr-top">
                    <div>
                        <div class="sr-name"><?php echo htmlspecialchars($sr['subject_name']); ?></div>
                        <div class="sr-id"><?php echo htmlspecialchars($sr['subject_id']); ?></div>
                    </div>
                    <div class="sr-pct <?php echo $pct_class; ?>"><?php echo $r; ?>%</div>
                </div>
                <div class="bar">
                    <div class="bar-fill <?php echo $fill_class; ?>"
                         style="width:<?php echo $r; ?>%"></div>
                </div>
                <div class="sr-meta">
                    Attended <?php echo $sr['attended']; ?> /
                    <?php echo $sr['total_classes']; ?> classes
                    &nbsp;·&nbsp;
                    Absent <?php echo $absent_count; ?>
                </div>
            </div>
            <?php endforeach; ?>

        <?php else: ?>
            <p style="color:#94a3b8;text-align:center;padding:30px 0;">
                No subjects enrolled yet.
            </p>
        <?php endif; ?>

    </div>
</div>

<script>
function openModal(){
    document.getElementById('rateModal').classList.add('show');
}
function closeModal(){
    document.getElementById('rateModal').classList.remove('show');
}
function closeOnOverlay(e){
    if(e.target === document.getElementById('rateModal')){
        closeModal();
    }
}
</script>

</body>
</html>