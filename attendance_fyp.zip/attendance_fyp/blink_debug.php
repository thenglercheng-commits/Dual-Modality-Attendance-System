<?php
// Standalone blink debug page - put this in your attendance_fyp folder
// Open it on your phone to see live EAR values
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Blink Debug</title>
<style>
*{ box-sizing:border-box; margin:0; padding:0; }
body{ font-family:Arial; background:#111; color:#0f0; display:flex;
      flex-direction:column; align-items:center; padding:10px; }
.video-wrap{ position:relative; width:100%; max-width:420px; }
video{ width:100%; border-radius:8px; background:#000; display:block; }
#overlay{ position:absolute; top:0; left:0; width:100%; height:100%;
           border-radius:8px; pointer-events:none; }
#stats{
    width:100%; max-width:420px; margin-top:10px;
    background:#222; border-radius:10px; padding:14px;
    font-size:14px; line-height:2;
}
.val{ color:#0ff; font-weight:bold; font-size:18px; }
.blink-flash{
    width:100%; max-width:420px; margin-top:10px;
    padding:16px; border-radius:10px; text-align:center;
    font-size:20px; font-weight:bold;
    background:#333; color:#888;
    transition: background 0.1s;
}
.blink-flash.detected{ background:#16a34a; color:#fff; }
#log{
    width:100%; max-width:420px; margin-top:10px;
    background:#1a1a1a; border-radius:8px; padding:10px;
    font-size:11px; color:#aaa; height:120px; overflow-y:auto;
}
</style>
</head>
<body>

<div class="video-wrap">
  <video id="video" autoplay playsinline muted></video>
  <canvas id="overlay"></canvas>
</div>

<div id="stats">
  <div>Left EAR:  <span class="val" id="leftEAR">-</span></div>
  <div>Right EAR: <span class="val" id="rightEAR">-</span></div>
  <div>Avg EAR:   <span class="val" id="avgEAR">-</span></div>
  <div>Baseline:  <span class="val" id="baseline">calibrating...</span></div>
  <div>Close thr: <span class="val" id="closeThr">-</span></div>
  <div>Status:    <span class="val" id="status">waiting...</span></div>
  <div>Blink count: <span class="val" id="blinkCount">0</span></div>
</div>

<div class="blink-flash" id="blinkFlash">NO BLINK</div>

<div id="log"></div>

<script src="https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/face_mesh.js" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js" crossorigin="anonymous"></script>

<script>
const video = document.getElementById("video");
const overlayCanvas = document.getElementById("overlay");
const overlayCtx = overlayCanvas.getContext("2d");

// EAR landmark indices
const L_TOP=159, L_BOT=145, L_LEFT=33,  L_RIGHT=133;
const R_TOP=386, R_BOT=374, R_LEFT=362, R_RIGHT=263;

function dist(a,b){ return Math.hypot(a.x-b.x, a.y-b.y); }
function earCalc(top,bot,left,right){
    return dist(top,bot)/(dist(left,right)+1e-6);
}

// State
let earSamples = [];
let earBaseline = null;
let baselineReady = false;
let blinkFrameCount = 0;
let totalBlinks = 0;
let lastEARs = [];

function addLog(msg){
    const log = document.getElementById("log");
    const line = document.createElement("div");
    line.textContent = new Date().toLocaleTimeString() + " " + msg;
    log.insertBefore(line, log.firstChild);
    if(log.children.length > 30) log.removeChild(log.lastChild);
}

function flashBlink(){
    const el = document.getElementById("blinkFlash");
    totalBlinks++;
    document.getElementById("blinkCount").textContent = totalBlinks;
    el.textContent = "✅ BLINK #" + totalBlinks + " DETECTED!";
    el.classList.add("detected");
    setTimeout(()=>{
        el.textContent = "watching...";
        el.classList.remove("detected");
    }, 800);
    addLog(`BLINK detected! EAR history: ${lastEARs.map(v=>v.toFixed(3)).join(", ")}`);
}

function processFrame(lm){
    const lEAR = earCalc(lm[L_TOP],lm[L_BOT],lm[L_LEFT],lm[L_RIGHT]);
    const rEAR = earCalc(lm[R_TOP],lm[R_BOT],lm[R_LEFT],lm[R_RIGHT]);
    const avg  = (lEAR + rEAR) / 2;

    document.getElementById("leftEAR").textContent  = lEAR.toFixed(4);
    document.getElementById("rightEAR").textContent = rEAR.toFixed(4);
    document.getElementById("avgEAR").textContent   = avg.toFixed(4);

    // Keep rolling history of last 5 EAR values
    lastEARs.push(avg);
    if(lastEARs.length > 5) lastEARs.shift();

    // Baseline calibration
    if(!baselineReady){
        earSamples.push(avg);
        document.getElementById("status").textContent =
            "calibrating " + earSamples.length + "/" + 30;
        if(earSamples.length >= 30){
            const sorted = [...earSamples].sort((a,b)=>b-a);
            const top = sorted.slice(0, 18); // top 60%
            earBaseline = top.reduce((s,v)=>s+v,0)/top.length;
            baselineReady = true;
            document.getElementById("baseline").textContent = earBaseline.toFixed(4);
            document.getElementById("closeThr").textContent = (earBaseline*0.75).toFixed(4);
            addLog("Baseline set: " + earBaseline.toFixed(4) +
                   " | close=" + (earBaseline*0.75).toFixed(4) +
                   " | open=" + (earBaseline*0.85).toFixed(4));
        }
        return;
    }

    const EAR_CLOSE = earBaseline * 0.75;
    const EAR_OPEN  = earBaseline * 0.85;

    if(avg < EAR_CLOSE){
        blinkFrameCount++;
        document.getElementById("status").textContent =
            "CLOSING (frame " + blinkFrameCount + ")";
    } else if(avg > EAR_OPEN){
        if(blinkFrameCount >= 1 && blinkFrameCount <= 20){
            flashBlink();
        }
        if(blinkFrameCount > 20){
            addLog("Eyes closed too long (" + blinkFrameCount + " frames) - ignored");
        }
        blinkFrameCount = 0;
        document.getElementById("status").textContent = "OPEN";
    } else {
        // In between — transition zone
        document.getElementById("status").textContent =
            "transition (" + avg.toFixed(3) + ")";
    }
}

// Draw eye dots on overlay
function drawEyeDots(lm, w, h){
    overlayCanvas.width  = w;
    overlayCanvas.height = h;
    overlayCtx.clearRect(0,0,w,h);
    const pts = [L_TOP,L_BOT,L_LEFT,L_RIGHT,R_TOP,R_BOT,R_LEFT,R_RIGHT];
    pts.forEach(i => {
        const x = lm[i].x * w;
        const y = lm[i].y * h;
        overlayCtx.beginPath();
        overlayCtx.arc(x, y, 4, 0, 2*Math.PI);
        overlayCtx.fillStyle = "#0ff";
        overlayCtx.fill();
    });
}

// Init MediaPipe
async function init(){
    const stream = await navigator.mediaDevices.getUserMedia({
        video:{ facingMode:"user", width:{ideal:640}, height:{ideal:480} },
        audio:false
    });
    video.srcObject = stream;
    await video.play();

    const faceMesh = new FaceMesh({
        locateFile: f => `https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/${f}`
    });
    faceMesh.setOptions({
        maxNumFaces:1, refineLandmarks:true,
        minDetectionConfidence:0.4,
        minTrackingConfidence:0.4
    });
    faceMesh.onResults(results => {
        if(!results.multiFaceLandmarks || !results.multiFaceLandmarks.length){
            document.getElementById("status").textContent = "NO FACE";
            document.getElementById("avgEAR").textContent = "-";
            return;
        }
        const lm = results.multiFaceLandmarks[0];
        const vw = video.videoWidth  || video.clientWidth;
        const vh = video.videoHeight || video.clientHeight;
        drawEyeDots(lm, vw, vh);
        processFrame(lm);
    });

    const cam = new Camera(video, {
        onFrame: async () => { await faceMesh.send({image:video}); },
        width:640, height:480
    });
    cam.start();
    addLog("MediaPipe started");
}

init().catch(e => {
    document.getElementById("status").textContent = "ERROR: " + e.message;
    addLog("Init error: " + e.message);
});
</script>
</body>
</html>