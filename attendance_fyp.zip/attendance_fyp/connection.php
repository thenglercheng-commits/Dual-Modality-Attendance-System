<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "attendance_fyp";
$port = 3306;

$conn = new mysqli($host, $user, $pass, $db, $port);

if ($conn->connect_error) {
die("Connection Failed: " . $conn->connect_error);
}

$conn->set_charset("utf8");
?>
