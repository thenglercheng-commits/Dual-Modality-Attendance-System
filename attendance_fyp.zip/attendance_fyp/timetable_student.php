<?php
session_start();
include "connection.php";

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

/* =========================
   GET STUDENT ID
========================= */

$student_query = $conn->query("
    SELECT student_id
    FROM students
    WHERE id='$user_id'
    LIMIT 1
");

$student_row = $student_query->fetch_assoc();
$student_id  = $student_row['student_id'];

/* =========================
   DISPLAY DATA
   Only subjects the student
   is enrolled in via
   student_subject table
========================= */

if(isset($_GET['filter']) && $_GET['from'] != "" && $_GET['to'] != ""){

    $from = $_GET['from'];
    $to   = $_GET['to'];

    $result = $conn->query("
        SELECT
            t.*,
            s.subject_name
        FROM timetable t
        JOIN subjects s
            ON t.subject_id = s.subject_id
        JOIN student_subject ss
            ON s.subject_id = ss.subject_id
        WHERE ss.student_id = '$student_id'
        AND t.class_date BETWEEN '$from' AND '$to'
        ORDER BY t.class_date, t.start_time
    ");

}else{

    /* Default — show this week */
    $result = $conn->query("
        SELECT
            t.*,
            s.subject_name
        FROM timetable t
        JOIN subjects s
            ON t.subject_id = s.subject_id
        JOIN student_subject ss
            ON s.subject_id = ss.subject_id
        WHERE ss.student_id = '$student_id'
        AND YEARWEEK(t.class_date, 1) = YEARWEEK(CURDATE(), 1)
        ORDER BY t.class_date, t.start_time
    ");
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Timetable</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'Poppins', sans-serif;
    display:flex;
    background:#f4f8ff;
}

/* =========================
   SIDEBAR
========================= */

.sidebar{
    width:260px;
    min-height:100vh;
    background:white;
    padding:25px;
    position:fixed;
    left:0;
    top:0;
    border-right:1px solid #eee;
}

.brand{
    font-size:20px;
    font-weight:700;
    margin-bottom:35px;
    color:#2563eb;
}

.menu a{
    display:flex;
    align-items:center;
    gap:12px;
    padding:14px 16px;
    margin-bottom:10px;
    border-radius:14px;
    text-decoration:none;
    color:#334155;
    font-weight:500;
    transition:.3s;
    font-size:15px;
}

.menu a:hover,
.menu a.active{
    background:#2563eb;
    color:white;
}

/* =========================
   MAIN
========================= */

.main{
    margin-left:260px;
    width:calc(100% - 260px);
    padding:35px;
}

/* =========================
   TOP
========================= */

.top{
    background:white;
    border-radius:20px;
    padding:25px 30px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    box-shadow:0 6px 15px rgba(0,0,0,.06);
    margin-bottom:25px;
}

.top h1{
    font-size:26px;
    color:#0b1652;
    margin-bottom:6px;
}

.top p{
    color:#64748b;
    font-size:14px;
}

.logout-btn{
    background:#2563eb;
    color:white;
    text-decoration:none;
    padding:12px 22px;
    border-radius:12px;
    font-weight:600;
    font-size:14px;
}

/* =========================
   BOX
========================= */

.box{
    background:white;
    padding:28px;
    border-radius:20px;
    box-shadow:0 6px 15px rgba(0,0,0,.06);
}

.section-title{
    font-size:20px;
    font-weight:600;
    margin-bottom:20px;
    color:#0b1652;
}

/* =========================
   FILTER
========================= */

.search-row{
    display:flex;
    gap:15px;
    align-items:center;
    flex-wrap:wrap;
    margin-bottom:10px;
}

.search-row input[type="date"]{
    padding:12px 15px;
    border:1px solid #dbe2ea;
    border-radius:14px;
    background:#fff;
    font-size:14px;
    font-family:'Poppins', sans-serif;
    outline:none;
    min-width:170px;
}

.filter-btn{
    background:#2563eb;
    color:white;
    border:none;
    padding:12px 22px;
    border-radius:14px;
    font-size:14px;
    font-weight:600;
    cursor:pointer;
    font-family:'Poppins', sans-serif;
}

.filter-btn:hover{
    background:#1d4ed8;
}

.range-btn{
    background:#eef2f7;
    color:#111827;
    padding:12px 20px;
    border-radius:14px;
    text-decoration:none;
    font-size:14px;
    font-weight:600;
}

.range-btn:hover{
    background:#dbe4f0;
}

/* =========================
   TABLE
========================= */

table{
    width:100%;
    border-collapse:collapse;
    font-size:14px;
    margin-top:25px;
    border-radius:14px;
    overflow:hidden;
}

thead{
    background:#2563eb;
    color:white;
}

th{
    padding:15px 18px;
    text-align:left;
}

td{
    padding:14px 18px;
    border-bottom:1px solid #eef2f7;
    color:#334155;
}

tr:last-child td{
    border-bottom:none;
}

tr:hover td{
    background:#f8fbff;
}

/* Today highlight */
.today-row td{
    background:#eff6ff;
    font-weight:600;
    color:#1d4ed8;
}

.badge-today{
    display:inline-block;
    background:#2563eb;
    color:white;
    font-size:11px;
    padding:3px 10px;
    border-radius:999px;
    margin-left:8px;
    font-weight:600;
}

.empty-msg{
    text-align:center;
    color:#94a3b8;
    padding:40px;
    font-size:15px;
}

</style>
</head>
<body>

<!-- SIDEBAR -->
<div class="sidebar">

    <div class="brand">Student Panel</div>

    <div class="menu">
        <a href="student.php">Overview</a>
        <a href="attendance_student.php">Attendance</a>
        <a href="subject_student.php">Subject</a>
        <a href="timetable_student.php" class="active">Timetable</a>
    </div>

</div>

<!-- MAIN -->
<div class="main">

    <!-- TOP -->
    <div class="top">
        <div>
            <h1>My Timetable</h1>
            <p>View timetable for your enrolled subjects only.</p>
        </div>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>

    <!-- BOX -->
    <div class="box">

        <div class="section-title">Timetable Records</div>

        <!-- FILTER FORM -->
        <form method="GET">
            <div class="search-row">

                <input type="date" name="from"
                    value="<?php echo $_GET['from'] ?? ''; ?>">

                <input type="date" name="to"
                    value="<?php echo $_GET['to'] ?? ''; ?>">

                <button type="submit" name="filter" class="filter-btn">
                    View Range
                </button>

                <a href="timetable_student.php" class="range-btn">
                    This Week
                </a>

            </div>
        </form>

        <!-- TABLE -->
        <table>

            <thead>
                <tr>
                    <th>Subject ID</th>
                    <th>Subject Name</th>
                    <th>Date</th>
                    <th>Start Time</th>
                    <th>End Time</th>
                </tr>
            </thead>

            <tbody>

            <?php

            $today = date("Y-m-d");
            $has_rows = false;

            if($result && $result->num_rows > 0){

                while($row = $result->fetch_assoc()){

                    $has_rows   = true;
                    $is_today   = ($row['class_date'] === $today);
                    $row_class  = $is_today ? 'today-row' : '';

                    echo "<tr class='$row_class'>";
                    echo "<td>" . htmlspecialchars($row['subject_id'])   . "</td>";
                    echo "<td>" . htmlspecialchars($row['subject_name']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['class_date'])   .
                         ($is_today ? "<span class='badge-today'>Today</span>" : "") .
                         "</td>";
                    echo "<td>" . htmlspecialchars($row['start_time'])   . "</td>";
                    echo "<td>" . htmlspecialchars($row['end_time'])     . "</td>";
                    echo "</tr>";
                }

            }

            if(!$has_rows){
                echo "<tr><td colspan='5' class='empty-msg'>
                      No timetable found for this period.
                      </td></tr>";
            }

            ?>

            </tbody>

        </table>

    </div>

</div>

</body>
</html>