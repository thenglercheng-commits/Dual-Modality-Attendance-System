<?php
session_start();
include "connection.php";

if(!isset($_SESSION['name']) || $_SESSION['role'] != 'lecturer'){
    header("Location: login.php");
    exit();
}

/* =====================================
   GET CURRENT LECTURER SUBJECT ONLY
===================================== */

$lecturer_name = $_SESSION['name'];

/* =====================================
   DISPLAY DATA
===================================== */

if(isset($_GET['filter']) && $_GET['from'] != "" && $_GET['to'] != ""){

    $from = $_GET['from'];
    $to   = $_GET['to'];

    $result = $conn->query("
        SELECT timetable.*, subjects.subject_name
        FROM timetable
        LEFT JOIN subjects ON timetable.subject_id = subjects.subject_id
        WHERE subjects.lecturer = '$lecturer_name'
        AND class_date BETWEEN '$from' AND '$to'
        ORDER BY class_date, start_time
    ");

}else{

    // Default weekly timetable
    $result = $conn->query("
        SELECT timetable.*, subjects.subject_name
        FROM timetable
        LEFT JOIN subjects ON timetable.subject_id = subjects.subject_id
        WHERE subjects.lecturer = '$lecturer_name'
        AND YEARWEEK(class_date,1)=YEARWEEK(CURDATE(),1)
        ORDER BY class_date, start_time
    ");
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Lecturer Timetable</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}
body{
    font-family:'Poppins',sans-serif;
    display:flex;
    background:#f5f8fc;
}

/* Sidebar */
.sidebar{
    width:260px;
    min-height:100vh;
    background:white;
    padding:25px;
    position:fixed;
    left:0;
    top:0;
}
.brand{
    font-size:20px;
    font-weight:bold;
    margin-bottom:35px;
}
.menu a{
    display:flex;
    align-items:center;
    gap:12px;
    padding:14px 16px;
    margin-bottom:10px;
    border-radius:12px;
    text-decoration:none;
    color:black;
    transition:0.2s;
    font-size:15px;
}
.menu a:hover,
.menu a.active{
    background:#2563eb;
    color:white;
}

/* Main */
.main{
    margin-left:260px;
    width:calc(100% - 260px);
    padding:35px;
}

/* Boxes */
.top{
    background:white;
    border-radius:18px;
    padding:25px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    box-shadow:0 6px 15px rgba(0,0,0,.06);
    margin-bottom:25px;
}

.top h1{
    color:#0b1652;
    font-size:28px;
}

.top p{
    color:#475569;
    margin-top:8px;
}

.top-flex{
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.top-right{
    display:flex;
    gap:18px;
    align-items:center;
}

.logout-btn{
    background:#2563eb;
    color:white;
    text-decoration:none;
    padding:12px 22px;
    border-radius:12px;
    font-weight:600;
}

.box{
    background:white;
    padding:25px;
    border-radius:18px;
    box-shadow:0 6px 15px rgba(0,0,0,.06);
}
/* Form */
input{
    padding:10px;
    border:1px solid #ccc;
    border-radius:10px;
    margin:5px;
}
button{
    padding:10px 18px;
    background:#2563eb;
    color:white;
    border:none;
    border-radius:10px;
    cursor:pointer;
}
.search-row{
    display:flex;
    gap:20px;
    align-items:center;
    flex-wrap:wrap;
}

.search-row input{
     width:260px;
    padding:13px 15px;
    border:1px solid #dbe2ea;
    border-radius:16px;
    background:#fff;
    font-size:14px;
    outline:none;
}

button:hover{
    background:#1d4ed8;
}
.range-btn{
    background:#eef2f7;
    color:#111827;
    padding:13px 20px;
    border-radius:16px;
    text-decoration:none;
    font-size:14px;
    font-weight:bold;
}
.filter-btn{
    background:#2962ff;
    color:white;
    border:none;
    padding:13px 22px;
    border-radius:16px;
    font-size:14px;
    font-weight:bold;
    cursor:pointer;
}

/* Table */
table{
    width:100%;
    border-collapse:collapse;
    overflow:hidden;
    border-radius:18px;
    font-size:14px;
    margin-top:30px;
}
th{
    background:#2563eb;
    color:white;
    padding:12px;
}
td{
    padding:12px;
    border:1px solid #ddd;
    text-align:center;
}

.section-title{
    margin-bottom:15px;
}

</style>
</head>

<body>

<!-- Sidebar -->
<div class="sidebar">
    <div class="brand">Lecturer Panel</div>
    <div class="menu">
        <a href="lecturer.php">Overview</a>
        <a href="subject_lecturer.php">Subject</a>
        <a href="attendance_lecturer.php">Attendance</a>
        <a href="timetable_lecturer.php" class="active">Timetable</a>
    </div>
</div>

<!-- Main -->
<div class="main">

    <!-- Top -->
    <div class="top">
        <div>
            <h1>My Timetable</h1>
            <p>View the timetable for your subjects.</p>
        </div>

        <div class="right-top">
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>

    </div>

    <!-- Box -->
    <div class="box">
        <h2 class="section-title">Timetable Records</h2>

        <!-- Filter -->
        <form method="GET">
            <div class="search-row">
                <input type="date" name="from">
                <input type="date" name="to">
                <button type="submit" name="filter" class="filter-btn">View Range</button>
                <a href="timetable_lecturer.php" class="range-btn">This Week</a>
            </div>
        </form>

        <!-- Table -->
        <table>
            <tr>
                <th>Subject ID</th>
                <th>Subject Name</th>
                <th>Date</th>
                <th>Start</th>
                <th>End</th>
            </tr>

            <?php while($row = $result->fetch_assoc()){ ?>
            <tr>
                <td><?php echo $row['subject_id']; ?></td>
                <td><?php echo $row['subject_name']; ?></td>
                <td><?php echo $row['class_date']; ?></td>
                <td><?php echo $row['start_time']; ?></td>
                <td><?php echo $row['end_time']; ?></td>
            </tr>
            <?php } ?>

        </table>

    </div>

</div>

</body>
</html>